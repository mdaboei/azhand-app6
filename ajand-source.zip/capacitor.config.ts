import type { CapacitorConfig } from '@capacitor/cli'

/**
 * کانفیگ Capacitor — پوسته اندرویدی اپ «آژند اپ».
 *
 * اپ هوشمند است: موقع اولین اجرا، خودش آدرس سرور را از کاربر می‌پرسد
 * (صفحه splash در پوشه cap-web). پس لازم نیست آدرس را اینجا قفل کنی.
 *
 * نکته مهم: بدون allowNavigation، کاپسیتور آدرس سرور را در «مرورگر خارجی»
 * گوشی باز می‌کند! با allowNavigation: ['*'] هر آدرسی که کاربر وارد کند
 * داخل خود اپ (وب‌ویو) باز می‌شود — این کلیدِ اتصال به هر سروری است.
 *
 * ⚠️ نکته آپدیت: appId و package تغییر نکند! اگر شناسه عوض شود، نسخه جدید
 * دیگر روی نسخه قبلی «نصب به‌روزرسانی» نمی‌شود و کاربر باید اپ را حذف و
 * دوباره نصب کند. همه محتوای اپ از سرور لود می‌شود، پس با تغییر سرور،
 * اپ بدون نصب دوباره آپدیت می‌شود.
 */
const config: CapacitorConfig = {
  appId: 'com.karlist.app',
  appName: 'آژند اپ',
  webDir: 'cap-web',
  server: {
    allowNavigation: ['*'],
  },
  plugins: {
    // 🔧 رفع «رفتن محتوا زیر نوار اعلان» در اندروید ۱۵+:
    // در @capacitor/android@8.6.0 تشخیص viewport-fit=cover باگ تایپی دارد
    // (متغیر metaeta به‌جای meta[meta.length-1] در SystemBars.java) و همیشه شکست
    // می‌خورد. با این hint مقدار از ابتدا true در نظر گرفته می‌شود و SystemBars
    // مقادیر واقعی نوارها را در --safe-area-inset-* تزریق می‌کند؛ CSS اپ
    // (کلاس‌های safe-top / safe-bottom) همین مقادیر را مصرف می‌کند.
    SystemBars: {
      initialViewportFitValueHint: 'cover',
    },
  },
}

export default config
