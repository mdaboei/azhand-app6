'use client'

import { useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import { Building2, Loader2, LogIn, UserRound } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'ورود ناموفق بود')
        return
      }
      toast.success('خوش آمدید!')
      // ناوبری سخت: در WebView اندروید هم کوکی نشست حتماً با درخواست بعدی
      // ارسال می‌شود و وضعیت فرم/کش کلاینت کاملاً پاک می‌شود
      window.location.replace((data.redirect as string) || '/')
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="safe-top safe-bottom flex min-h-screen flex-col items-center justify-center gap-5 bg-gradient-to-b from-brand-50 to-background p-4 dark:from-brand-950/30">
      <div className="text-center">
        {/* لوگوی شرکت — حرف A */}
        <div className="mx-auto flex size-16 items-center justify-center rounded-2xl border border-brand-100 bg-white shadow-lg">
          { }
          <img src="/logo.png" alt="لوگوی آژند اپ" className="size-11 object-contain" />
        </div>
        <h1 className="mt-3 text-lg font-bold">ورود به آژند اپ</h1>
        <p className="mt-1 flex items-center justify-center gap-1 text-sm text-muted-foreground">
          <Building2 className="size-3.5" />
          سامانه داخلی شرکت آژند همت توس
        </p>
      </div>

      <Card className="w-full max-w-sm">
        <CardContent className="p-5">
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">نام کاربری</Label>
              <div className="relative">
                <UserRound className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="username"
                  dir="ltr"
                  className="pl-9 text-left"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  autoCapitalize="none"
                  spellCheck={false}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">رمز عبور</Label>
              <Input
                id="password"
                dir="ltr"
                className="text-left"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin" /> : <LogIn className="size-4" />}
              ورود
            </Button>
          </form>
        </CardContent>
      </Card>

      <p className="max-w-xs text-center text-[11px] leading-5 text-muted-foreground">
        برای دریافت نام کاربری و رمز عبور با مدیر سیستم شرکت تماس بگیرید.
      </p>

      <Link href="/" className="text-xs text-muted-foreground underline-offset-4 hover:underline">
        بازگشت به صفحه اصلی
      </Link>
    </div>
  )
}
