'use client'

// ─── صفحهٔ جزئیات حساب سوددار ───────────────────────────────────────
// خلاصهٔ کامل وضعیت، جدول تاریخچهٔ ماهانه، تاریخچهٔ پرداخت‌ها
// با ثبت/ویرایش/حذف و بایگانی تغییرات.

import { useCallback, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { toast } from 'sonner'
import {
  ArrowRight,
  Ban,
  CalendarClock,
  FileDown,
  History,
  Loader2,
  Pencil,
  Plus,
  Printer,
  RotateCcw,
  Trash2,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { AccountDialog } from '@/components/finance/profit-dashboard'
import type {
  ProfitAccountDetailDTO,
  ProfitPayType,
  ProfitPaymentDTO,
} from '@/lib/types'
import {
  PROFIT_METHOD_LABELS,
  PROFIT_PAYTYPE_LABELS,
  PROFIT_RULE_LABELS,
} from '@/lib/types'
import {
  faDigits,
  faMoney,
  faNum,
  formatJalaliDateInput,
  isValidJalaliDate,
  jalaliToday,
  padJalali,
} from '@/lib/persian'

// ─── کمک‌ها ─────────────────────────────────────────────────────────

async function sendJSON(url: string, method: string, body?: unknown): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
    const data = (await res.json().catch(() => ({}))) as { error?: string }
    if (!res.ok) return { ok: false, error: data.error || 'عملیات ناموفق بود' }
    return { ok: true }
  } catch {
    return { ok: false, error: 'ارتباط با سرور برقرار نشد' }
  }
}

function AmountHint({ value }: { value: string }) {
  const n = Number(value.replace(/[,\s]/g, ''))
  if (!value.trim() || !Number.isFinite(n) || n <= 0) return null
  return <p className="mt-1 text-xs text-muted-foreground">{faMoney(n)}</p>
}

function InfoRow({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-dashed py-1.5 last:border-0">
      <span className="shrink-0 text-xs text-muted-foreground">{label}</span>
      <span className={`text-left text-sm font-bold ${tone ?? ''}`}>{value}</span>
    </div>
  )
}

const LOG_ACTION_LABELS: Record<string, string> = {
  CREATE: 'ایجاد حساب',
  UPDATE: 'ویرایش',
  CLOSE: 'بستن حساب',
  REOPEN: 'بازگشایی',
  PAYMENT_ADD: 'ثبت پرداخت',
  PAYMENT_EDIT: 'ویرایش پرداخت',
  PAYMENT_DELETE: 'حذف پرداخت',
  RECALC: 'محاسبهٔ مجدد',
}

// ─── صفحه ───────────────────────────────────────────────────────────

export default function ProfitAccountDetailPage() {
  const params = useParams<{ id: string }>()
  const id = params?.id ?? ''

  const [detail, setDetail] = useState<ProfitAccountDetailDTO | null>(null)
  const [loading, setLoading] = useState(true)

  // فرم ویرایش حساب
  const [editOpen, setEditOpen] = useState(false)

  // فرم پرداخت
  const [payOpen, setPayOpen] = useState(false)
  const [payEditing, setPayEditing] = useState<ProfitPaymentDTO | null>(null)
  const [payType, setPayType] = useState<ProfitPayType>('INTEREST')
  const [payAmount, setPayAmount] = useState('')
  const [payInterestPart, setPayInterestPart] = useState('')
  const [payDate, setPayDate] = useState(jalaliToday())
  const [payNote, setPayNote] = useState('')
  const [savingPay, setSavingPay] = useState(false)

  // بستن حساب
  const [closeOpen, setCloseOpen] = useState(false)
  const [closeDate, setCloseDate] = useState(jalaliToday())
  const [closing, setClosing] = useState(false)

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/finance/profit-accounts/${id}`)
      setDetail(res.ok ? ((await res.json()) as ProfitAccountDetailDTO) : null)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => {
    if (id) load()
  }, [id, load])

  // پرداخت‌های هر دوره (کلاینت) — بر اساس بازهٔ شمسی هر دوره
  const perPeriodPayments = useMemo(() => {
    if (!detail) return new Map<number, { interest: number; principal: number }>()
    const map = new Map<number, { interest: number; principal: number }>()
    const bump = (idx: number, p: ProfitPaymentDTO) => {
      const cur = map.get(idx) ?? { interest: 0, principal: 0 }
      cur.interest += p.interestPart
      cur.principal += p.principalPart
      map.set(idx, cur)
    }
    const buckets: { idx: number; from: string; to: string }[] = detail.periods.map((p) => ({
      idx: p.idx,
      from: padJalali(p.startDate),
      to: padJalali(p.endDate),
    }))
    if (detail.stats.ongoing) {
      buckets.push({ idx: detail.stats.ongoing.idx, from: padJalali(detail.stats.ongoing.startDate), to: padJalali(jalaliToday()) })
    }
    for (const pay of detail.payments) {
      const d = padJalali(pay.date)
      const b = buckets.find((x) => d >= x.from && d <= x.to)
      if (b) bump(b.idx, pay)
    }
    return map
  }, [detail])

  function openPayDialog(p?: ProfitPaymentDTO) {
    setPayEditing(p ?? null)
    setPayType(p?.payType ?? 'INTEREST')
    setPayAmount(p ? String(p.amount) : '')
    setPayInterestPart(p && p.payType === 'MIXED' ? String(p.interestPart) : '')
    setPayDate(p?.date ?? jalaliToday())
    setPayNote(p?.note ?? '')
    setPayOpen(true)
  }

  async function submitPayment() {
    if (!isValidJalaliDate(payDate.trim())) {
      toast.error('تاریخ پرداخت باید شمسی و مثل 1405/08/15 باشد')
      return
    }
    const amount = Number(payAmount.replace(/[,\s]/g, ''))
    if (!Number.isFinite(amount) || amount <= 0) {
      toast.error('مبلغ پرداخت را درست وارد کنید')
      return
    }
    if (payType === 'MIXED') {
      const ip = Number(payInterestPart.replace(/[,\s]/g, ''))
      if (!Number.isFinite(ip) || ip <= 0 || ip >= amount) {
        toast.error('بخش سود باید بیشتر از صفر و کمتر از مبلغ کل باشد')
        return
      }
    }
    setSavingPay(true)
    const result = await sendJSON(
      payEditing
        ? `/api/finance/profit-accounts/${id}/payments/${payEditing.id}`
        : `/api/finance/profit-accounts/${id}/payments`,
      payEditing ? 'PATCH' : 'POST',
      {
        payType,
        date: payDate.trim(),
        amount,
        ...(payType === 'MIXED' ? { interestPart: Number(payInterestPart.replace(/[,\s]/g, '')) } : {}),
        note: payNote.trim() || null,
      },
    )
    setSavingPay(false)
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success(payEditing ? 'پرداخت ویرایش شد و محاسبات به‌روز شد' : 'پرداخت ثبت شد')
    setPayOpen(false)
    await load()
  }

  async function deletePayment(p: ProfitPaymentDTO) {
    const result = await sendJSON(`/api/finance/profit-accounts/${id}/payments/${p.id}`, 'DELETE')
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success('پرداخت حذف شد و محاسبات به‌روز شد')
    await load()
  }

  async function closeAccount() {
    if (!isValidJalaliDate(closeDate.trim())) {
      toast.error('تاریخ بستن باید شمسی باشد')
      return
    }
    setClosing(true)
    const result = await sendJSON(`/api/finance/profit-accounts/${id}/close`, 'POST', { date: closeDate.trim() })
    setClosing(false)
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success('حساب بسته شد')
    setCloseOpen(false)
    await load()
  }

  async function reopenAccount() {
    const result = await sendJSON(`/api/finance/profit-accounts/${id}/reopen`, 'POST')
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success('حساب بازگشایی شد')
    await load()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> در حال بارگذاری حساب…
      </div>
    )
  }
  if (!detail) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          <p className="text-sm text-muted-foreground">حساب پیدا نشد.</p>
          <Button asChild variant="outline" size="sm">
            <Link href="/finance">بازگشت به پنل مالی</Link>
          </Button>
        </CardContent>
      </Card>
    )
  }

  const s = detail.stats
  const isCompound = detail.calcMethod === 'COMPOUND'

  return (
    <div className="space-y-4">
      {/* ── سربرگ حساب ── */}
      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div className="min-w-0">
              <Link href="/finance" className="mb-1 flex items-center gap-1 text-xs text-muted-foreground hover:text-brand-600">
                <ArrowRight className="size-3" /> بازگشت به فهرست حساب‌های سوددار
              </Link>
              <h1 className="text-lg font-black leading-7">{detail.personName}</h1>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                {detail.status === 'ACTIVE' ? (
                  s.maturityReached ? (
                    <Badge variant="destructive">رسیده به سررسید</Badge>
                  ) : (
                    <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">فعال</Badge>
                  )
                ) : (
                  <Badge variant="secondary">بسته {detail.closedAt ? `— ${faDigits(detail.closedAt)}` : ''}</Badge>
                )}
                <Badge variant="outline">{PROFIT_METHOD_LABELS[detail.calcMethod]}</Badge>
                <Badge variant="outline" className="font-normal text-muted-foreground">
                  {PROFIT_RULE_LABELS[detail.partialRule]}
                </Badge>
                {detail.contractNo && <Badge variant="outline" className="font-normal">سند {detail.contractNo}</Badge>}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button asChild variant="outline" size="sm" className="gap-1">
                <Link href={`/print/profit/${detail.id}`}>
                  <Printer className="size-4" /> چاپ گزارش
                </Link>
              </Button>
              <Button asChild variant="outline" size="sm" className="gap-1">
                <a href={`/api/finance/profit-accounts/export?type=STATEMENT&id=${detail.id}`}>
                  <FileDown className="size-4" /> اکسل حساب
                </a>
              </Button>
              {detail.status === 'ACTIVE' ? (
                <Button variant="outline" size="sm" className="gap-1 text-destructive hover:text-destructive" onClick={() => setCloseOpen(true)}>
                  <Ban className="size-4" /> بستن حساب
                </Button>
              ) : (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-1">
                      <RotateCcw className="size-4" /> بازگشایی حساب
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>بازگشایی حساب؟</AlertDialogTitle>
                      <AlertDialogDescription>
                        با بازگشایی، دورهٔ بریده‌شدهٔ آخر حذف می‌شود و محاسبهٔ سود از همان‌جا ادامه می‌یابد.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>انصراف</AlertDialogCancel>
                      <AlertDialogAction onClick={reopenAccount}>بازگشایی</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
              <Button size="sm" className="gap-1" onClick={() => setEditOpen(true)}>
                <Pencil className="size-4" /> ویرایش حساب
              </Button>
            </div>
          </div>
          {detail.note && <p className="border-t pt-2 text-xs leading-6 text-muted-foreground">{detail.note}</p>}
        </CardContent>
      </Card>

      {/* ── خلاصهٔ وضعیت ── */}
      <div className="grid gap-3 lg:grid-cols-3">
        <Card>
          <CardContent className="space-y-0.5 p-4">
            <h2 className="mb-2 flex items-center gap-1.5 text-sm font-bold">
              <CalendarClock className="size-4 text-brand-600" /> مشخصات حساب
            </h2>
            <InfoRow label="نام شخص" value={detail.personName} />
            <InfoRow label="اصل سرمایه اولیه" value={faMoney(detail.principal)} />
            <InfoRow label="درصد سود ماهانه" value={`${faNum(detail.monthlyRate)}٪`} />
            <InfoRow label="تاریخ شروع" value={faDigits(detail.startDate)} />
            <InfoRow label="تاریخ سررسید" value={detail.maturityDate ? faDigits(detail.maturityDate) : 'ندارد'} />
            {detail.maturityDate && s.daysToMaturity !== null && (
              <InfoRow
                label="وضعیت سررسید"
                value={
                  s.maturityReached
                    ? 'رسیده به سررسید'
                    : `${faNum(s.daysToMaturity)} روز مانده`
                }
                tone={s.maturityReached ? 'text-red-600 dark:text-red-400' : ''}
              />
            )}
            <InfoRow label="تعداد ماه‌های سپری‌شده" value={`${faNum(s.monthsElapsed)} ماه`} />
            {detail.status === 'CLOSED' && <InfoRow label="تاریخ بستن" value={faDigits(detail.closedAt ?? '')} />}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="space-y-0.5 p-4">
            <h2 className="mb-2 text-sm font-bold">وضعیت اصل سرمایه</h2>
            <InfoRow label="اصل سرمایه اولیه" value={faMoney(detail.principal)} />
            <InfoRow label="مجموع اصل بازپرداخت‌شده" value={faMoney(s.paidPrincipal)} />
            <InfoRow label="مانده اصل سرمایه" value={faMoney(s.currentPrincipal)} tone="text-brand-600" />
            {isCompound && (
              <InfoRow label="سود مرکب‌شده در اصل" value={faMoney(s.capitalized)} tone="text-muted-foreground" />
            )}
            <InfoRow label="مجموع سود ایجادشده" value={faMoney(s.accrued)} tone="text-emerald-600 dark:text-emerald-400" />
            <InfoRow label="مجموع سود پرداخت‌شده" value={faMoney(s.paidInterest)} tone="text-emerald-600 dark:text-emerald-400" />
            <InfoRow
              label={isCompound ? 'سود پرداخت‌نشده (خارج از اصل)' : 'سود معوق و پرداخت‌نشده'}
              value={faMoney(s.unpaidInterest)}
              tone="text-amber-600 dark:text-amber-400"
            />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col justify-between space-y-3 p-4">
            <div className="space-y-0.5">
              <h2 className="mb-2 text-sm font-bold">مانده بدهی</h2>
              <InfoRow label="مانده اصل سرمایه" value={faMoney(s.currentPrincipal)} />
              <InfoRow
                label={isCompound ? 'سود پرداخت‌نشده (خارج از اصل)' : 'سود معوق و پرداخت‌نشده'}
                value={faMoney(s.unpaidInterest)}
              />
            </div>
            <div className="rounded-xl bg-red-50 p-3 text-center dark:bg-red-950/30">
              <p className="text-xs text-muted-foreground">مجموع کل بدهی شرکت به شخص</p>
              <p className="mt-1 text-lg font-black text-red-600 dark:text-red-400">{faMoney(s.totalDebt)}</p>
              <p className="mt-1 text-[11px] leading-5 text-muted-foreground">
                اصل اولیه − بازپرداخت اصل + سود ایجادشده − سود پرداخت‌شده
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── دورهٔ جاری ── */}
      {s.ongoing && (
        <Card className="border-dashed">
          <CardContent className="flex flex-wrap items-center justify-between gap-2 p-4">
            <div>
              <p className="text-sm font-bold">
                دورهٔ جاری ({faNum(s.ongoing.idx)}) — {faDigits(s.ongoing.startDate)} تا {faDigits(s.ongoing.endDate)}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {faNum(s.ongoing.daysElapsed)} روز از {faNum(s.ongoing.daysTotal)} روز سپری شده — {s.ongoing.note}
              </p>
            </div>
            <div className="text-left">
              <p className="text-xs text-muted-foreground">سود برآوردی تا امروز (قطعی نشده)</p>
              <p className="text-sm font-black text-amber-600 dark:text-amber-400">{faMoney(s.ongoing.accruedSoFar)}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── جدول تاریخچهٔ ماهانه ── */}
      <Card>
        <CardContent className="p-4">
          <h2 className="mb-3 text-sm font-bold">تاریخچهٔ ماهانهٔ محاسبات</h2>
          <div className="max-h-96 overflow-auto rounded-lg border">
            <Table>
              <TableHeader className="sticky top-0 bg-muted z-10">
                <TableRow>
                  <TableHead className="text-center">دوره</TableHead>
                  <TableHead className="text-center whitespace-nowrap">بازه</TableHead>
                  <TableHead className="text-center">اصل ابتدای دوره</TableHead>
                  <TableHead className="text-center">سود دوره</TableHead>
                  {isCompound && <TableHead className="text-center">مرکب‌شده</TableHead>}
                  <TableHead className="text-center">پرداخت‌ها</TableHead>
                  <TableHead className="text-center">اصل پایان دوره</TableHead>
                  <TableHead className="text-center">وضعیت</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {detail.periods.map((p) => {
                  const pp = perPeriodPayments.get(p.idx)
                  const paidTotal = (pp?.interest ?? 0) + (pp?.principal ?? 0)
                  return (
                    <TableRow key={p.id}>
                      <TableCell className="text-center">{faNum(p.idx)}</TableCell>
                      <TableCell dir="ltr" className="whitespace-nowrap text-center text-xs">
                        {faDigits(p.startDate)} — {faDigits(p.endDate)}
                        <span className="text-muted-foreground"> ({faNum(p.days)} روز)</span>
                      </TableCell>
                      <TableCell className="text-center text-xs">{faNum(p.opening)}</TableCell>
                      <TableCell className="text-center text-xs font-bold text-emerald-700 dark:text-emerald-400">
                        {faNum(p.interest)}
                      </TableCell>
                      {isCompound && (
                        <TableCell className="text-center text-xs">{p.capitalized > 0 ? faNum(p.capitalized) : '—'}</TableCell>
                      )}
                      <TableCell className="text-center text-xs">
                        {paidTotal > 0 ? (
                          <span dir="ltr">
                            {pp && pp.interest > 0 ? `سود: ${faNum(pp.interest)}` : ''}
                            {pp && pp.principal > 0 ? `${pp.interest > 0 ? ' | ' : ''}اصل: ${faNum(pp.principal)}` : ''}
                          </span>
                        ) : (
                          '—'
                        )}
                      </TableCell>
                      <TableCell className="text-center text-xs">{faNum(p.closing)}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-[10px]">قطعی</Badge>
                      </TableCell>
                    </TableRow>
                  )
                })}
                {s.ongoing && (
                  <TableRow className="bg-muted/40">
                    <TableCell className="text-center">{faNum(s.ongoing.idx)}</TableCell>
                    <TableCell dir="ltr" className="whitespace-nowrap text-center text-xs">
                      {faDigits(s.ongoing.startDate)} — {faDigits(s.ongoing.endDate)}
                      <span className="text-muted-foreground"> ({faNum(s.ongoing.daysElapsed)} روز)</span>
                    </TableCell>
                    <TableCell className="text-center text-xs">
                      {faNum(detail.periods.length > 0 ? detail.periods[detail.periods.length - 1].closing : detail.principal)}
                    </TableCell>
                    <TableCell className="text-center text-xs font-bold text-amber-700 dark:text-amber-400">
                      ~{faNum(s.ongoing.accruedSoFar)}
                    </TableCell>
                    {isCompound && <TableCell className="text-center text-xs text-muted-foreground">—</TableCell>}
                    <TableCell className="text-center text-xs">
                      {(() => {
                        const pp = perPeriodPayments.get(s.ongoing.idx)
                        const total = (pp?.interest ?? 0) + (pp?.principal ?? 0)
                        return total > 0 ? faNum(total) : '—'
                      })()}
                    </TableCell>
                    <TableCell className="text-center text-xs text-muted-foreground">—</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary" className="text-[10px]">در جریان</Badge>
                    </TableCell>
                  </TableRow>
                )}
                {detail.periods.length === 0 && !s.ongoing && (
                  <TableRow>
                    <TableCell colSpan={isCompound ? 8 : 7} className="py-6 text-center text-xs text-muted-foreground">
                      هنوز دوره‌ای قطعی نشده است — با سپری‌شدن ماه اول، محاسبات اینجا ثبت می‌شود
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ── تاریخچهٔ پرداخت‌ها ── */}
      <Card>
        <CardContent className="p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-bold">تاریخچهٔ پرداخت‌ها</h2>
            <div className="flex items-center gap-2">
              {detail.status === 'ACTIVE' ? (
                <Button size="sm" className="gap-1" onClick={() => openPayDialog()}>
                  <Plus className="size-4" /> ثبت پرداخت
                </Button>
              ) : (
                <p className="text-xs text-muted-foreground">حساب بسته است — ثبت پرداخت جدید ممکن نیست</p>
              )}
            </div>
          </div>
          <div className="mb-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-3">
            <div className="rounded-lg border bg-muted/30 p-2">
              <span className="text-muted-foreground">سود پرداخت‌نشده (قابل پرداخت):</span>
              <span className="font-bold"> {faMoney(s.unpaidInterest)}</span>
            </div>
            <div className="rounded-lg border bg-muted/30 p-2">
              <span className="text-muted-foreground">مانده اصل (قابل بازپرداخت):</span>
              <span className="font-bold"> {faMoney(s.currentPrincipal)}</span>
            </div>
          </div>
          {detail.payments.length === 0 ? (
            <p className="rounded-lg border border-dashed p-6 text-center text-xs text-muted-foreground">
              هنوز پرداختی ثبت نشده است
            </p>
          ) : (
            <div className="max-h-96 overflow-auto rounded-lg border">
              <Table>
                <TableHeader className="sticky top-0 bg-muted z-10">
                  <TableRow>
                    <TableHead className="text-center">تاریخ</TableHead>
                    <TableHead className="text-center">بابت</TableHead>
                    <TableHead className="text-center">بخش سود</TableHead>
                    <TableHead className="text-center">بخش اصل</TableHead>
                    <TableHead className="text-center">مبلغ کل</TableHead>
                    <TableHead className="text-center">توضیحات</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detail.payments.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell dir="ltr" className="whitespace-nowrap text-center">{faDigits(p.date)}</TableCell>
                      <TableCell className="text-center text-xs">{PROFIT_PAYTYPE_LABELS[p.payType]}</TableCell>
                      <TableCell className="text-center text-xs">{p.interestPart > 0 ? faNum(p.interestPart) : '—'}</TableCell>
                      <TableCell className="text-center text-xs">{p.principalPart > 0 ? faNum(p.principalPart) : '—'}</TableCell>
                      <TableCell className="text-center text-xs font-bold">{faNum(p.amount)}</TableCell>
                      <TableCell className="max-w-40 truncate text-center text-xs text-muted-foreground" title={p.note ?? ''}>
                        {p.note || '—'}
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-7"
                            aria-label={`ویرایش پرداخت ${p.date}`}
                            onClick={() => openPayDialog(p)}
                          >
                            <Pencil className="size-3.5" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-7 text-destructive"
                                aria-label={`حذف پرداخت ${p.date}`}
                              >
                                <Trash2 className="size-3.5" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>حذف پرداخت؟</AlertDialogTitle>
                                <AlertDialogDescription>
                                  پرداخت {faMoney(p.amount)} در تاریخ {faDigits(p.date)} حذف و همهٔ محاسبات از نو انجام می‌شود.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>انصراف</AlertDialogCancel>
                                <AlertDialogAction className="bg-destructive text-white hover:bg-destructive/90" onClick={() => deletePayment(p)}>
                                  حذف
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── تاریخچهٔ تغییرات ── */}
      <Card>
        <CardContent className="p-4">
          <h2 className="mb-3 flex items-center gap-1.5 text-sm font-bold">
            <History className="size-4 text-brand-600" /> بایگانی تغییرات
          </h2>
          {detail.logs.length === 0 ? (
            <p className="text-xs text-muted-foreground">رخدادی ثبت نشده است.</p>
          ) : (
            <ul className="max-h-72 space-y-1.5 overflow-y-auto pe-1">
              {detail.logs.map((l) => (
                <li key={l.id} className="rounded-lg bg-muted/40 px-3 py-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-1">
                    <span className="font-bold">{LOG_ACTION_LABELS[l.action] ?? l.action}</span>
                    <span dir="ltr" className="text-[10px] text-muted-foreground">
                      {new Date(l.createdAt).toLocaleString('fa-IR')}
                    </span>
                  </div>
                  <p className="mt-1 leading-6 text-muted-foreground">{l.detail}</p>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* ── دیالوگ ویرایش حساب ── */}
      <AccountDialog open={editOpen} onOpenChange={setEditOpen} editing={detail} onDone={load} />

      {/* ── دیالوگ پرداخت ── */}
      <Dialog open={payOpen} onOpenChange={setPayOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{payEditing ? 'ویرایش پرداخت' : 'ثبت پرداخت جدید'}</DialogTitle>
            <DialogDescription>
              پرداخت به شخص (بابت سود، اصل سرمایه یا ترکیبی) را ثبت کنید؛ مانده‌ها خودکار به‌روز می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>بابت</Label>
                <Select value={payType} onValueChange={(v) => setPayType(v as ProfitPayType)}>
                  <SelectTrigger aria-label="نوع پرداخت">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INTEREST">بابت سود</SelectItem>
                    <SelectItem value="PRINCIPAL">بابت اصل سرمایه</SelectItem>
                    <SelectItem value="MIXED">ترکیبی (اصل و سود)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="pay-date">تاریخ پرداخت (شمسی)</Label>
                <Input
                  id="pay-date"
                  dir="ltr"
                  className="text-right"
                  value={payDate}
                  onChange={(e) => setPayDate(formatJalaliDateInput(e.target.value))}
                  placeholder="1405/08/16"
                  inputMode="numeric"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="pay-amount">مبلغ کل (تومان)</Label>
              <Input
                id="pay-amount"
                dir="ltr"
                className="text-right"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="0"
                inputMode="decimal"
              />
              <AmountHint value={payAmount} />
            </div>
            {payType === 'MIXED' && (
              <div className="space-y-1">
                <Label htmlFor="pay-interest">بخش سود (تومان)</Label>
                <Input
                  id="pay-interest"
                  dir="ltr"
                  className="text-right"
                  value={payInterestPart}
                  onChange={(e) => setPayInterestPart(e.target.value)}
                  placeholder="مابه‌التفاوت به‌عنوان اصل سرمایه ثبت می‌شود"
                  inputMode="decimal"
                />
              </div>
            )}
            <div className="rounded-lg bg-muted/50 p-2 text-xs leading-6 text-muted-foreground">
              سود پرداخت‌نشدهٔ فعلی: <b>{faMoney(s.unpaidInterest)}</b> — ماندهٔ اصل سرمایه:{' '}
              <b>{faMoney(s.currentPrincipal)}</b>
              {isCompound && ' — در حساب مرکب، برداشت سود قطعی‌شده را «بابت اصل سرمایه» ثبت کنید.'}
            </div>
            <div className="space-y-1">
              <Label htmlFor="pay-note">توضیحات</Label>
              <Textarea
                id="pay-note"
                rows={2}
                value={payNote}
                onChange={(e) => setPayNote(e.target.value)}
                placeholder="اختیاری — مثل: شماره فیش واریزی"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={submitPayment} disabled={savingPay} className="gap-1">
              {savingPay && <Loader2 className="size-4 animate-spin" />}
              {payEditing ? 'ذخیره تغییرات' : 'ثبت پرداخت'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── دیالوگ بستن حساب ── */}
      <Dialog open={closeOpen} onOpenChange={setCloseOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>بستن حساب «{detail.personName}»</DialogTitle>
            <DialogDescription>
              با بستن حساب، محاسبهٔ سود متوقف و دورهٔ ناقص آخر طبق قاعدهٔ «{PROFIT_RULE_LABELS[detail.partialRule]}» قطعی می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            <Label htmlFor="close-date">تاریخ بستن (شمسی)</Label>
            <Input
              id="close-date"
              dir="ltr"
              className="text-right"
              value={closeDate}
              onChange={(e) => setCloseDate(formatJalaliDateInput(e.target.value))}
              inputMode="numeric"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCloseOpen(false)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={closeAccount} disabled={closing} className="gap-1">
              {closing && <Loader2 className="size-4 animate-spin" />}
              بستن حساب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
