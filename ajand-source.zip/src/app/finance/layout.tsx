import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function FinanceLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('FINANCE')
  return (
    <PanelShell
      fullName={user.fullName}
      roleLabel={roleLabel}
      role={session.role as 'FINANCE' | 'ADMIN'}
      panels={panels}
      unitLabel={session.role === 'ADMIN' ? 'واحد مالی' : null}
    >
      {children}
    </PanelShell>
  )
}
