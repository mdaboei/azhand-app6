'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  ArrowDownLeft,
  ArrowLeftRight,
  ArrowUpRight,
  FileDown,
  Landmark,
  Loader2,
  Pencil,
  PiggyBank,
  Plus,
  Printer,
  Trash2,
  Upload,
} from 'lucide-react'
import { ExportButton } from '@/components/export-button'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import type {
  BankAccountDTO,
  TransactionDTO,
  TransactionKind,
} from '@/lib/types'
import { faDigits, faMoney, faNum, formatJalaliDateInput, formatJalaliPeriodInput, jalaliMonthNow, jalaliToday } from '@/lib/persian'
import { ProfitDashboard } from '@/components/finance/profit-dashboard'

// ─── کمک‌ها ─────────────────────────────────────────────────────────

/** درخواست JSON به API؛ پیام خطای فارسی برمی‌گرداند */
async function sendJSON(url: string, method: string, body?: unknown): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
    const data = (await res.json().catch(() => ({}))) as { error?: string }
    if (!res.ok) return { ok: false, error: data.error || 'عملیات ناموفق بود' }
    return { ok: true }
  } catch {
    return { ok: false, error: 'ارتباط با سرور برقرار نشد' }
  }
}

/** تبدیل رشته مبلغ به عدد؛ نامعتبر بودن را با خطا اعلام می‌کند */
function toAmount(value: string, label: string): number | null {
  const n = Number(value.replace(/[,\s]/g, ''))
  if (!Number.isFinite(n) || n < 0) {
    toast.error(`${label} را درست وارد کنید`)
    return null
  }
  return n
}

const Spinner = ({ text }: { text: string }) => (
  <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
    <Loader2 className="size-4 animate-spin" />
    {text}
  </div>
)

const EmptyState = ({ icon, text }: { icon: React.ReactNode; text: string }) => (
  <Card>
    <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
      {icon}
      <p className="text-sm text-muted-foreground">{text}</p>
    </CardContent>
  </Card>
)

// ─── صفحه واحد مالی ─────────────────────────────────────────────────

export default function FinancePage() {
  // داده‌ها
  const [banks, setBanks] = useState<BankAccountDTO[]>([])
  const [txs, setTxs] = useState<TransactionDTO[]>([])
  const [banksLoading, setBanksLoading] = useState(true)
  const [txsLoading, setTxsLoading] = useState(true)
  const [txRefresh, setTxRefresh] = useState(0)

  // فیلترهای تراکنش
  const [month, setMonth] = useState(jalaliMonthNow())
  const [kindFilter, setKindFilter] = useState<'all' | TransactionKind>('all')

  // ── بارگذاری داده‌ها ──

  const loadBanks = useCallback(async () => {
    try {
      const res = await fetch('/api/finance/banks')
      setBanks(res.ok ? ((await res.json()) as BankAccountDTO[]) : [])
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setBanksLoading(false)
    }
  }, [])

  useEffect(() => {
    loadBanks()
  }, [loadBanks])

  useEffect(() => {
    const ctrl = new AbortController()
    ;(async () => {
      try {
        const qs = month.trim() ? `?month=${encodeURIComponent(month.trim())}` : ''
        const res = await fetch(`/api/finance/transactions${qs}`, { signal: ctrl.signal })
        setTxs(res.ok ? ((await res.json()) as TransactionDTO[]) : [])
      } catch (e) {
        if ((e as Error)?.name !== 'AbortError') toast.error('خطا در دریافت تراکنش‌ها')
      } finally {
        setTxsLoading(false)
      }
    })()
    return () => ctrl.abort()
  }, [month, txRefresh])

  // ── فرم حساب بانکی ──
  const [bankOpen, setBankOpen] = useState(false)
  const [bankEditing, setBankEditing] = useState<BankAccountDTO | null>(null)
  const [bankName, setBankName] = useState('')
  const [bankNumber, setBankNumber] = useState('')
  const [bankBalance, setBankBalance] = useState('')
  const [bankNote, setBankNote] = useState('')
  const [savingBank, setSavingBank] = useState(false)

  function openBankDialog(acc?: BankAccountDTO) {
    setBankEditing(acc ?? null)
    setBankName(acc?.name ?? '')
    setBankNumber(acc?.accountNumber ?? '')
    setBankBalance(acc ? String(acc.balance) : '')
    setBankNote(acc?.note ?? '')
    setBankOpen(true)
  }

  async function submitBank() {
    if (bankName.trim().length < 2) {
      toast.error('نام بانک/حساب را وارد کنید')
      return
    }
    const balance = toAmount(bankBalance || '0', 'موجودی')
    if (balance === null) return
    setSavingBank(true)
    const result = await sendJSON(
      bankEditing ? `/api/finance/banks/${bankEditing.id}` : '/api/finance/banks',
      bankEditing ? 'PATCH' : 'POST',
      {
        name: bankName.trim(),
        accountNumber: bankNumber.trim() || null,
        balance,
        note: bankNote.trim() || null,
      },
    )
    setSavingBank(false)
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success(bankEditing ? 'حساب بانکی ویرایش شد' : 'حساب بانکی ثبت شد')
    setBankOpen(false)
    await loadBanks()
  }

  async function deleteBank(acc: BankAccountDTO) {
    const result = await sendJSON(`/api/finance/banks/${acc.id}`, 'DELETE')
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success('حساب بانکی حذف شد')
    await loadBanks()
  }

  // ── فرم تراکنش ──
  const [txImportOpen, setTxImportOpen] = useState(false)
  const [txOpen, setTxOpen] = useState(false)
  const [txEditing, setTxEditing] = useState<TransactionDTO | null>(null)
  const [txKind, setTxKind] = useState<TransactionKind>('RECEIVE')
  const [txAmount, setTxAmount] = useState('')
  const [txDate, setTxDate] = useState(jalaliToday())
  const [txTitle, setTxTitle] = useState('')
  const [txBankId, setTxBankId] = useState('none')
  const [txNote, setTxNote] = useState('')
  const [savingTx, setSavingTx] = useState(false)

  function openTxDialog(t?: TransactionDTO) {
    setTxEditing(t ?? null)
    setTxKind(t?.kind ?? 'RECEIVE')
    setTxAmount(t ? String(t.amount) : '')
    setTxDate(t?.date || jalaliToday())
    setTxTitle(t?.title ?? '')
    setTxBankId(t?.bankAccountId ?? 'none')
    setTxNote(t?.note ?? '')
    setTxOpen(true)
  }

  async function submitTx() {
    if (!isValidJalaliDate(txDate.trim())) {
      toast.error('تاریخ باید شمسی و مثل 1405/08/15 باشد')
      return
    }
    if (txTitle.trim().length < 2) {
      toast.error('بابت تراکنش را بنویسید')
      return
    }
    const amount = toAmount(txAmount, 'مبلغ')
    if (amount === null || amount <= 0) {
      toast.error('مبلغ باید بیشتر از صفر باشد')
      return
    }
    setSavingTx(true)
    const result = await sendJSON(
      txEditing ? `/api/finance/transactions/${txEditing.id}` : '/api/finance/transactions',
      txEditing ? 'PATCH' : 'POST',
      {
        kind: txKind,
        amount,
        date: txDate.trim(),
        title: txTitle.trim(),
        bankAccountId: txBankId === 'none' ? null : txBankId,
        note: txNote.trim() || null,
      },
    )
    setSavingTx(false)
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success(txEditing ? 'تراکنش ویرایش شد' : 'تراکنش ثبت شد')
    setTxOpen(false)
    setTxRefresh((n) => n + 1)
  }

  async function deleteTx(t: TransactionDTO) {
    const result = await sendJSON(`/api/finance/transactions/${t.id}`, 'DELETE')
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success('تراکنش حذف شد')
    setTxRefresh((n) => n + 1)
  }

  // ── محاسبه‌های نمایشی ──
  const totalReceive = txs.reduce((s, t) => (t.kind === 'RECEIVE' ? s + t.amount : s), 0)
  const totalPay = txs.reduce((s, t) => (t.kind === 'PAY' ? s + t.amount : s), 0)
  const netTotal = totalReceive - totalPay
  const visibleTxs = kindFilter === 'all' ? txs : txs.filter((t) => t.kind === kindFilter)
  const totalBalance = banks.reduce((s, b) => s + b.balance, 0)

  return (
    <div className="space-y-4">
      <Tabs defaultValue="banks">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="banks" className="gap-1">
            <Landmark className="size-4" /> بانک‌ها
          </TabsTrigger>
          <TabsTrigger value="transactions" className="gap-1">
            <ArrowLeftRight className="size-4" /> دریافت و پرداخت
          </TabsTrigger>
          <TabsTrigger value="profits" className="gap-1">
            <PiggyBank className="size-4" /> حساب‌های سوددار
          </TabsTrigger>
        </TabsList>

        {/* ─── بانک‌ها ─── */}
        <TabsContent value="banks" className="mt-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-bold">حساب‌های بانکی شرکت</h2>
            <div className="flex flex-wrap gap-2">
              <ExportButton url="/api/finance/banks/export" filename="banks.xlsx" />
              <Button size="sm" className="gap-1" onClick={() => openBankDialog()}>
                <Plus className="size-4" /> حساب جدید
              </Button>
            </div>
          </div>

          {banksLoading ? (
            <Spinner text="در حال بارگذاری حساب‌ها…" />
          ) : banks.length === 0 ? (
            <EmptyState
              icon={<Landmark className="size-10 text-muted-foreground/40" />}
              text="هنوز حساب بانکی ثبت نشده است — با دکمه «حساب جدید» اولین حساب را اضافه کنید"
            />
          ) : (
            <>
              <div className="grid gap-3 sm:grid-cols-2">
                {banks.map((b) => (
                  <Card key={b.id}>
                    <CardContent className="space-y-2 p-4">
                      <div className="flex items-start gap-2">
                        <Landmark className="mt-0.5 size-5 shrink-0 text-brand-600" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-bold leading-6">{b.name}</p>
                          {b.accountNumber && (
                            <p dir="ltr" className="text-right font-mono text-xs text-muted-foreground">
                              {b.accountNumber}
                            </p>
                          )}
                        </div>
                        <div className="flex shrink-0 gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8"
                            aria-label={`ویرایش ${b.name}`}
                            onClick={() => openBankDialog(b)}
                          >
                            <Pencil className="size-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-destructive"
                                aria-label={`حذف ${b.name}`}
                              >
                                <Trash2 className="size-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>حذف {b.name}؟</AlertDialogTitle>
                                <AlertDialogDescription>
                                  اگر تراکنشی به این حساب وصل باشد، حذف انجام نمی‌شود.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>انصراف</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteBank(b)}>حذف</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                      <p className="text-sm font-bold text-brand-600">{faMoney(b.balance)}</p>
                      {b.note && <p className="text-xs leading-6 text-muted-foreground">{b.note}</p>}
                    </CardContent>
                  </Card>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                مجموع موجودی حساب‌ها: <span className="font-bold text-brand-600">{faMoney(totalBalance)}</span>
              </p>
            </>
          )}
        </TabsContent>

        {/* ─── دریافت و پرداخت ─── */}
        <TabsContent value="transactions" className="mt-4 space-y-3">
          {/* نوار جمع‌بندی */}
          <section className="grid grid-cols-3 gap-2" aria-label="جمع دریافت و پرداخت">
            <Card>
              <CardContent className="space-y-1 p-3 text-center">
                <p className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                  <ArrowDownLeft className="size-3.5 text-emerald-600" /> دریافت‌ها
                </p>
                <p className="truncate text-xs font-bold text-brand-600 sm:text-sm">{faMoney(totalReceive)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="space-y-1 p-3 text-center">
                <p className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                  <ArrowUpRight className="size-3.5 text-red-600" /> پرداخت‌ها
                </p>
                <p className="truncate text-xs font-bold text-red-600 sm:text-sm">{faMoney(totalPay)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="space-y-1 p-3 text-center">
                <p className="text-xs text-muted-foreground">خالص</p>
                <p
                  className={`truncate text-xs font-bold sm:text-sm ${
                    netTotal >= 0 ? 'text-emerald-600' : 'text-red-600'
                  }`}
                >
                  {faMoney(netTotal)}
                </p>
              </CardContent>
            </Card>
          </section>

          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-bold">تراکنش‌ها</h2>
            <div className="flex flex-wrap gap-2">
              <ExportButton url="/api/finance/transactions/export" filename="transactions.xlsx" />
              <Button asChild variant="outline" size="sm" className="gap-1" aria-label="چاپ فهرست تراکنش‌ها">
                <Link href={month.trim() ? `/print/transactions?month=${encodeURIComponent(month.trim())}` : '/print/transactions'}>
                  <Printer className="size-4" aria-hidden /> چاپ
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="gap-1" onClick={() => setTxImportOpen(true)} aria-label="ورود تراکنش‌ها از اکسل">
                <Upload className="size-4" aria-hidden /> ورود از اکسل
              </Button>
              <Button size="sm" className="gap-1" onClick={() => openTxDialog()}>
                <Plus className="size-4" /> ثبت تراکنش
              </Button>
            </div>
          </div>

          {/* فیلترها */}
          <Card>
            <CardContent className="flex flex-wrap items-end gap-3 p-4">
              <div className="space-y-1">
                <Label htmlFor="tx-month">ماه (خالی = همه)</Label>
                <Input
                  id="tx-month"
                  dir="ltr"
                  className="w-32 text-right"
                  value={month}
                  onChange={(e) => setMonth(formatJalaliPeriodInput(e.target.value))}
                  placeholder="1405/08"
                  inputMode="numeric"
                />
              </div>
              <div className="space-y-1">
                <Label>نوع</Label>
                <Select value={kindFilter} onValueChange={(v) => setKindFilter(v as 'all' | TransactionKind)}>
                  <SelectTrigger className="w-32" aria-label="فیلتر نوع تراکنش">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">همه</SelectItem>
                    <SelectItem value="RECEIVE">دریافت</SelectItem>
                    <SelectItem value="PAY">پرداخت</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {txsLoading ? (
            <Spinner text="در حال بارگذاری تراکنش‌ها…" />
          ) : visibleTxs.length === 0 ? (
            <EmptyState
              icon={<ArrowLeftRight className="size-10 text-muted-foreground/40" />}
              text={txs.length === 0 ? 'هنوز تراکنشی ثبت نشده است' : 'تراکنشی با این فیلترها پیدا نشد'}
            />
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-auto">
                  <Table className="min-w-[560px]">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">تاریخ</TableHead>
                        <TableHead className="text-right">بابت</TableHead>
                        <TableHead className="text-right">نوع</TableHead>
                        <TableHead className="text-right">مبلغ</TableHead>
                        <TableHead className="text-right">بانک</TableHead>
                        <TableHead className="w-20" />
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {visibleTxs.map((t) => (
                        <TableRow key={t.id}>
                          <TableCell dir="ltr" className="whitespace-nowrap text-right text-xs text-muted-foreground">
                            {faDigits(t.date)}
                          </TableCell>
                          <TableCell className="max-w-40 text-right">
                            <p className="truncate text-sm font-medium">{t.title}</p>
                            {t.note && <p className="truncate text-xs text-muted-foreground">{t.note}</p>}
                          </TableCell>
                          <TableCell>
                            {t.kind === 'RECEIVE' ? (
                              <Badge className="bg-emerald-600 text-white hover:bg-emerald-600">دریافت</Badge>
                            ) : (
                              <Badge className="bg-red-600 text-white hover:bg-red-600">پرداخت</Badge>
                            )}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right text-sm font-bold">
                            {faMoney(t.amount)}
                          </TableCell>
                          <TableCell className="max-w-32 truncate text-right text-xs text-muted-foreground">
                            {t.bankAccountName ?? '—'}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8"
                                aria-label={`ویرایش تراکنش ${t.title}`}
                                onClick={() => openTxDialog(t)}
                              >
                                <Pencil className="size-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="size-8 text-destructive"
                                    aria-label={`حذف تراکنش ${t.title}`}
                                  >
                                    <Trash2 className="size-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>حذف تراکنش؟</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      «{t.title}» به مبلغ {faMoney(t.amount)} حذف می‌شود.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>انصراف</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => deleteTx(t)}>حذف</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
          <p className="text-xs text-muted-foreground">
            💡 برای دیدن همه ماه‌ها، کادر «ماه» را خالی بگذارید.
          </p>
        </TabsContent>

        {/* ─── حساب‌های سوددار اشخاص ─── */}
        <TabsContent value="profits" className="mt-4">
          <ProfitDashboard />
        </TabsContent>

      </Tabs>

      {/* ─── دیالوگ حساب بانکی ─── */}
      <Dialog open={bankOpen} onOpenChange={setBankOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{bankEditing ? 'ویرایش حساب بانکی' : 'حساب بانکی جدید'}</DialogTitle>
            <DialogDescription>نام بانک و شعبه را کامل بنویسید؛ موجودی فعلی حساب را هم وارد کنید.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="bank-name">نام بانک / شعبه</Label>
              <Input
                id="bank-name"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="مثلاً: بانک ملت — شعبه مرکزی"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="bank-number">شماره حساب / کارت</Label>
              <Input
                id="bank-number"
                dir="ltr"
                className="text-right"
                value={bankNumber}
                onChange={(e) => setBankNumber(e.target.value)}
                placeholder="6104-…"
                inputMode="numeric"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="bank-balance">موجودی (تومان)</Label>
              <Input
                id="bank-balance"
                dir="ltr"
                className="text-right"
                value={bankBalance}
                onChange={(e) => setBankBalance(e.target.value)}
                placeholder="0"
                inputMode="decimal"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="bank-note">یادداشت</Label>
              <Textarea
                id="bank-note"
                rows={2}
                value={bankNote}
                onChange={(e) => setBankNote(e.target.value)}
                placeholder="اختیاری"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={submitBank} disabled={savingBank} className="gap-1">
              {savingBank && <Loader2 className="size-4 animate-spin" />}
              {bankEditing ? 'ذخیره تغییرات' : 'ثبت حساب'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── دیالوگ تراکنش ─── */}
      <Dialog open={txOpen} onOpenChange={setTxOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{txEditing ? 'ویرایش تراکنش' : 'ثبت تراکنش جدید'}</DialogTitle>
            <DialogDescription>دریافت یا پرداخت شرکت را با تاریخ شمسی ثبت کنید.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>نوع</Label>
                <Select value={txKind} onValueChange={(v) => setTxKind(v as TransactionKind)}>
                  <SelectTrigger aria-label="نوع تراکنش">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="RECEIVE">دریافت</SelectItem>
                    <SelectItem value="PAY">پرداخت</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="tx-amount">مبلغ (تومان)</Label>
                <Input
                  id="tx-amount"
                  dir="ltr"
                  className="text-right"
                  value={txAmount}
                  onChange={(e) => setTxAmount(e.target.value)}
                  placeholder="0"
                  inputMode="decimal"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="tx-date">تاریخ (شمسی)</Label>
                <Input
                  id="tx-date"
                  dir="ltr"
                  className="text-right"
                  value={txDate}
                  onChange={(e) => setTxDate(formatJalaliDateInput(e.target.value))}
                  placeholder="1405/08/15"
                  inputMode="numeric"
                />
              </div>
              <div className="space-y-1">
                <Label>حساب بانکی</Label>
                <Select value={txBankId} onValueChange={setTxBankId}>
                  <SelectTrigger aria-label="حساب بانکی مرتبط">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— بدون حساب —</SelectItem>
                    {banks.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="tx-title">بابت</Label>
              <Input
                id="tx-title"
                value={txTitle}
                onChange={(e) => setTxTitle(e.target.value)}
                placeholder="مثلاً: دریافت از پروژه پل"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="tx-note">یادداشت</Label>
              <Textarea
                id="tx-note"
                rows={2}
                value={txNote}
                onChange={(e) => setTxNote(e.target.value)}
                placeholder="اختیاری"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={submitTx} disabled={savingTx} className="gap-1">
              {savingTx && <Loader2 className="size-4 animate-spin" />}
              {txEditing ? 'ذخیره تغییرات' : 'ثبت تراکنش'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── دیالوگ ورود اکسل تراکنش‌ها ─── */}
      <ImportTransactionsDialog
        open={txImportOpen}
        onOpenChange={setTxImportOpen}
        onDone={async () => setTxRefresh((x) => x + 1)}
      />
    </div>
  )
}

/** دیالوگ بارگذاری اکسل دریافت و پرداخت‌ها */
function ImportTransactionsDialog({
  open, onOpenChange, onDone,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  onDone: () => Promise<void> | void
}) {
  const [file, setFile] = useState<File | null>(null)
  const [importing, setImporting] = useState(false)
  const [result, setResult] = useState<{
    imported: number
    failed: number
    problems: { row: number; title: string; reason: string }[]
  } | null>(null)

  useEffect(() => {
    if (open) { setFile(null); setResult(null) }
  }, [open])

  async function submit() {
    if (!file) { toast.error('فایل اکسل را انتخاب کنید'); return }
    setImporting(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const r = await fetch('/api/finance/transactions/import', { method: 'POST', body: fd })
      const data = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(data.error || 'بارگذاری ناموفق بود'); return }
      setResult(data)
      toast.success(`${faNum(data.imported)} تراکنش ثبت شد`)
      await onDone()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setImporting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader><DialogTitle>ورود دریافت و پرداخت‌ها از اکسل</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Button asChild variant="outline" size="sm" className="gap-1">
              <a href="/api/finance/transactions/template">
                <FileDown className="size-4" /> دانلود قالب نمونه
              </a>
            </Button>
          </div>
          <p className="rounded-lg bg-muted/50 p-3 text-xs leading-6 text-muted-foreground">
            ستون‌های فایل: <b>تاریخ</b> (شمسی مثل 1405/08/15 یا پیوسته مثل 14050816)، <b>نوع</b> (دریافت یا پرداخت)، <b>بابت</b>، <b>مبلغ</b> و اختیاری <b>حساب بانکی</b> و <b>یادداشت</b>.
            نام حساب بانکی باید با یکی از حساب‌های ثبت‌شده مطابقت داشته باشد؛ اگر مطابقت نداشت تراکنش بدون حساب ثبت می‌شود.
          </p>
          <Input
            type="file"
            accept=".xlsx,.xls"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            aria-label="انتخاب فایل اکسل تراکنش‌ها"
          />
          <Button onClick={submit} disabled={importing || !file} size="sm" className="gap-1">
            {importing ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" />}
            بارگذاری و ثبت تراکنش‌ها
          </Button>

          {result && (
            <div className="space-y-2 rounded-lg border p-3">
              <p className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-bold">
                <span className="text-emerald-700 dark:text-emerald-400">ثبت‌شده: {faNum(result.imported)}</span>
                <span className="text-red-600">ناموفق: {faNum(result.failed)}</span>
              </p>
              {result.problems.length > 0 && (
                <div>
                  <p className="mb-1 text-xs font-bold text-red-600">ردیف‌های دارای مشکل:</p>
                  <ul className="max-h-40 space-y-1 overflow-y-auto pe-1 text-xs text-muted-foreground">
                    {result.problems.map((p, i) => (
                      <li key={i} className="rounded bg-muted/50 px-2 py-1">
                        ردیف {faNum(p.row)} ({p.title || '—'}): {p.reason}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
