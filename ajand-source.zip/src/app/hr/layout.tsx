import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function HrLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('HR')
  return (
    <PanelShell
      fullName={user.fullName}
      role={session.role as 'HR' | 'ADMIN'}
      roleLabel={roleLabel}
      unitLabel={session.role === 'ADMIN' ? 'منابع انسانی' : null}
      panels={panels}
    >
      {children}
    </PanelShell>
  )
}
