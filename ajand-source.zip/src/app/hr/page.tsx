'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  BadgeCheck,
  CalendarClock,
  Coins,
  FileDown,
  Loader2,
  Pencil,
  Plus,
  Printer,
  Settings2,
  Star,
  Trash2,
  Upload,
  UsersRound,
  X,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { ExportButton } from '@/components/export-button'
import { UserDTO, ProjectDTO, WorkLogDTO, ScoreEntryDTO } from '@/lib/types'
import {
  faDigits, faMoney, faNum, formatJalaliDateInput, formatJalaliPeriodInput, jalaliMonthNow, jalaliToday, periodLabel,
} from '@/lib/persian'

type TabKey = 'staff' | 'worklog' | 'payslip' | 'score'

/** آیتم داخل فیش صادرشده (اسنپ‌شات هنگام صدور) */
interface SlipItemDTO {
  title: string
  kind: 'BENEFIT' | 'DEDUCTION'
  amount: number
}

/** فیش حقوقی — ساختار آیتمی جدید (مزایا و کسورات) */
interface SlipDTO {
  id: string
  userId: string
  userName: string
  period: string
  baseSalary: number
  items: SlipItemDTO[]
  netPay: number
  note: string | null
  issuedByName: string
  createdAt: string
}

/** آیتم قابل تعریف فیش (مزایا/کسورات) */
interface PayItemDTO {
  id: string
  title: string
  kind: 'BENEFIT' | 'DEDUCTION'
  order: number
  isActive: boolean
  createdAt: string
}

export default function HrPage() {
  const [staff, setStaff] = useState<UserDTO[] | null>(null)
  const [projects, setProjects] = useState<ProjectDTO[] | null>(null)

  const loadStaff = useCallback(async () => {
    const r = await fetch('/api/users')
    if (r.ok) setStaff(await r.json())
    else toast.error('دریافت فهرست پرسنل ناموفق بود')
  }, [])
  const loadProjects = useCallback(async () => {
    const r = await fetch('/api/projects')
    if (r.ok) setProjects(await r.json())
  }, [])

  useEffect(() => {
    ;(async () => {
      await loadStaff()
      await loadProjects()
    })()
  }, [loadStaff, loadProjects])

  return (
    <div className="space-y-4">
      <Tabs defaultValue="staff">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="staff" className="gap-1"><UsersRound className="size-4" /> پرسنل</TabsTrigger>
          <TabsTrigger value="worklog" className="gap-1"><CalendarClock className="size-4" /> کارکرد</TabsTrigger>
          <TabsTrigger value="payslip" className="gap-1"><Coins className="size-4" /> فیش</TabsTrigger>
          <TabsTrigger value="score" className="gap-1"><Star className="size-4" /> امتیاز</TabsTrigger>
        </TabsList>

        <TabsContent value="staff" className="mt-4">
          <StaffTab staff={staff} projects={projects ?? []} reload={loadStaff} />
        </TabsContent>
        <TabsContent value="worklog" className="mt-4">
          <WorklogTab staff={staff ?? []} />
        </TabsContent>
        <TabsContent value="payslip" className="mt-4">
          <PayslipTab staff={staff ?? []} />
        </TabsContent>
        <TabsContent value="score" className="mt-4">
          <ScoreTab staff={staff ?? []} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// ─── تب پرسنل ──────────────────────────────────────────────────────

function StaffTab({
  staff, projects, reload,
}: {
  staff: UserDTO[] | null
  projects: ProjectDTO[]
  reload: () => Promise<void>
}) {
  const [openAdd, setOpenAdd] = useState(false)
  const [importOpen, setImportOpen] = useState(false)
  const [editing, setEditing] = useState<UserDTO | null>(null)

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {staff ? `${faDigits(staff.length)} نفر پرسنل فعال و غیرفعال` : 'در حال بارگذاری…'}
        </p>
        <div className="flex items-center gap-2">
          <ExportButton url="/api/users/export" filename="staff.xlsx" label="خروجی اکسل" />
          <Button variant="outline" size="sm" className="gap-1" onClick={() => setImportOpen(true)} aria-label="ورود پرسنل از اکسل">
            <Upload className="size-4" /> ورود از اکسل
          </Button>
          <Button size="sm" className="gap-1" onClick={() => setOpenAdd(true)}>
            <Plus className="size-4" /> کارمند جدید
          </Button>
        </div>
      </div>

      {!staff ? (
        <Skeleton className="h-40 w-full" />
      ) : staff.length === 0 ? (
        <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">هنوز کارمندی ثبت نشده است</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="max-h-[28rem] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نام</TableHead>
                    <TableHead className="text-right">سمت</TableHead>
                    <TableHead className="text-right">پروژه</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">ویرایش</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {staff.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="text-right">
                        <p className="font-medium">{u.fullName}</p>
                        <p className="dir-ltr text-xs text-muted-foreground">{u.username}</p>
                      </TableCell>
                      <TableCell className="text-right text-xs">{u.position || '—'}</TableCell>
                      <TableCell className="text-right text-xs">{u.projectName || '—'}</TableCell>
                      <TableCell className="text-center">
                        {u.isActive
                          ? <Badge className="bg-emerald-600 hover:bg-emerald-600">فعال</Badge>
                          : <Badge variant="secondary">غیرفعال</Badge>}
                      </TableCell>
                      <TableCell className="text-center">
                        <Button variant="outline" size="sm" onClick={() => setEditing(u)}>اطلاعات</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <AddStaffDialog open={openAdd} onOpenChange={setOpenAdd} projects={projects} reload={reload} />
      <EditStaffDialog staff={editing} onClose={() => setEditing(null)} projects={projects} reload={reload} />
      <StaffImportDialog open={importOpen} onOpenChange={setImportOpen} onDone={reload} />
    </div>
  )
}

/** دیالوگ بارگذاری اکسل پرسنل — ساخت گروهی کارمندها */
function StaffImportDialog({
  open, onOpenChange, onDone,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  onDone: () => Promise<void> | void
}) {
  const [file, setFile] = useState<File | null>(null)
  const [importing, setImporting] = useState(false)
  const [result, setResult] = useState<{
    imported: number
    failed: number
    problems: { row: number; username: string; reason: string }[]
  } | null>(null)

  useEffect(() => {
    if (open) { setFile(null); setResult(null) }
  }, [open])

  async function submit() {
    if (!file) { toast.error('فایل اکسل را انتخاب کنید'); return }
    setImporting(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const r = await fetch('/api/users/import', { method: 'POST', body: fd })
      const data = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(data.error || 'بارگذاری ناموفق بود'); return }
      setResult(data)
      toast.success(`${faNum(data.imported)} کارمند ثبت شد`)
      await onDone()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setImporting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader><DialogTitle>ورود پرسنل از اکسل</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Button asChild variant="outline" size="sm" className="gap-1">
              <a href="/api/users/template">
                <FileDown className="size-4" /> دانلود قالب نمونه
              </a>
            </Button>
          </div>
          <p className="rounded-lg bg-muted/50 p-3 text-xs leading-6 text-muted-foreground">
            ستون‌های فایل: <b>نام کاربری</b> و <b>نام و نام خانوادگی</b> الزامی است؛ سمت، کد ملی، شماره تماس،
            تاریخ استخدام (شمسی مثل 1404/05/01)، حقوق پایه (تومان)، پروژه (باید از قبل در ادمین تعریف شده باشد)
            و رمز عبور اختیاری‌اند — اگر رمز ندهید، رمز پیش‌فرض <b dir="ltr">12345678</b> می‌شود.
            همه ردیف‌ها به‌عنوان کارمند ثبت می‌شوند؛ نام کاربری تکراری رد می‌شود.
          </p>
          <Input
            type="file"
            accept=".xlsx,.xls"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            aria-label="انتخاب فایل اکسل پرسنل"
          />
          <Button onClick={submit} disabled={importing || !file} size="sm" className="gap-1">
            {importing ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" />}
            بارگذاری و ثبت پرسنل
          </Button>

          {result && (
            <div className="space-y-2 rounded-lg border p-3">
              <p className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-bold">
                <span className="text-emerald-700 dark:text-emerald-400">ثبت‌شده: {faNum(result.imported)}</span>
                <span className="text-red-600">ناموفق: {faNum(result.failed)}</span>
              </p>
              {result.problems.length > 0 && (
                <div>
                  <p className="mb-1 text-xs font-bold text-red-600">ردیف‌های دارای مشکل:</p>
                  <ul className="max-h-40 space-y-1 overflow-y-auto pe-1 text-xs text-muted-foreground">
                    {result.problems.map((p, i) => (
                      <li key={i} className="rounded bg-muted/50 px-2 py-1">
                        ردیف {faNum(p.row)} ({p.username || '—'}): {p.reason}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

function AddStaffDialog({
  open, onOpenChange, projects, reload,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  projects: ProjectDTO[]
  reload: () => Promise<void>
}) {
  const [form, setForm] = useState({
    username: '', fullName: '', password: '', position: '',
    nationalId: '', phone: '', hireDate: '', baseSalary: '', projectId: '',
  })
  const [saving, setSaving] = useState(false)

  async function submit() {
    setSaving(true)
    try {
      const r = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: form.username.trim(),
          fullName: form.fullName.trim(),
          role: 'EMPLOYEE',
          password: form.password || undefined,
          position: form.position || null,
          nationalId: form.nationalId || null,
          phone: form.phone || null,
          hireDate: form.hireDate || null,
          baseSalary: form.baseSalary ? Number(form.baseSalary) : null,
          projectId: form.projectId || null,
        }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success('کارمند ثبت شد' + (form.password ? '' : ' — رمز اولیه: 12345678'))
      onOpenChange(false)
      setForm({ username: '', fullName: '', password: '', position: '', nationalId: '', phone: '', hireDate: '', baseSalary: '', projectId: '' })
      await reload()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>ثبت کارمند جدید</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <F label="نام کاربری (لاتین) *"><Input dir="ltr" className="text-left" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="a.karimi" /></F>
          <F label="نام و نام خانوادگی *"><Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></F>
          <F label="رمز عبور (خالی = 12345678)"><Input dir="ltr" className="text-left" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></F>
          <F label="سمت"><Input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} /></F>
          <F label="کد ملی"><Input dir="ltr" className="text-left" value={form.nationalId} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} /></F>
          <F label="تلفن"><Input dir="ltr" className="text-left" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></F>
          <F label="تاریخ استخدام (شمسی)"><Input dir="ltr" className="text-left" inputMode="numeric" value={form.hireDate} onChange={(e) => setForm({ ...form, hireDate: formatJalaliDateInput(e.target.value) })} placeholder="1404/05/01" /></F>
          <F label="حقوق پایه (تومان)"><Input dir="ltr" type="number" inputMode="numeric" className="text-left" value={form.baseSalary} onChange={(e) => setForm({ ...form, baseSalary: e.target.value })} /></F>
          <F label="پروژه">
            <select
              className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={form.projectId}
              onChange={(e) => setForm({ ...form, projectId: e.target.value })}
              aria-label="پروژه"
            >
              <option value="">— بدون پروژه —</option>
              {projects.filter((p) => p.isActive).map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </F>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving} className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} ثبت
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function EditStaffDialog({
  staff, onClose, projects, reload,
}: {
  staff: UserDTO | null
  onClose: () => void
  projects: ProjectDTO[]
  reload: () => Promise<void>
}) {
  const [form, setForm] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  useEffect(() => {
    if (staff) {
      setForm({
        fullName: staff.fullName, position: staff.position ?? '',
        nationalId: staff.nationalId ?? '', phone: staff.phone ?? '',
        hireDate: staff.hireDate ?? '',
        baseSalary: staff.baseSalary != null ? String(staff.baseSalary) : '',
        projectId: staff.projectId ?? '',
      })
    }
  }, [staff])

  async function submit() {
    if (!staff) return
    setSaving(true)
    try {
      const r = await fetch(`/api/users/${staff.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: form.fullName,
          position: form.position || null,
          nationalId: form.nationalId || null,
          phone: form.phone || null,
          hireDate: form.hireDate || null,
          baseSalary: form.baseSalary ? Number(form.baseSalary) : null,
          projectId: form.projectId || null,
        }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ذخیره ناموفق بود'); return }
      toast.success('اطلاعات ذخیره شد')
      onClose()
      await reload()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={!!staff} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>اطلاعات پرسنلی — {staff?.fullName}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <F label="نام و نام خانوادگی"><Input value={form.fullName ?? ''} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></F>
          <F label="سمت"><Input value={form.position ?? ''} onChange={(e) => setForm({ ...form, position: e.target.value })} /></F>
          <F label="کد ملی"><Input dir="ltr" className="text-left" value={form.nationalId ?? ''} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} /></F>
          <F label="تلفن"><Input dir="ltr" className="text-left" value={form.phone ?? ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></F>
          <F label="تاریخ استخدام (شمسی)"><Input dir="ltr" className="text-left" inputMode="numeric" value={form.hireDate ?? ''} onChange={(e) => setForm({ ...form, hireDate: formatJalaliDateInput(e.target.value) })} placeholder="1404/05/01" /></F>
          <F label="حقوق پایه (تومان)"><Input dir="ltr" type="number" className="text-left" value={form.baseSalary ?? ''} onChange={(e) => setForm({ ...form, baseSalary: e.target.value })} /></F>
          <F label="پروژه">
            <select
              className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={form.projectId ?? ''}
              onChange={(e) => setForm({ ...form, projectId: e.target.value })}
              aria-label="پروژه"
            >
              <option value="">— بدون پروژه —</option>
              {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </F>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving} className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <BadgeCheck className="size-4" />} ذخیره
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ─── تب کارکرد ─────────────────────────────────────────────────────

function WorklogTab({ staff }: { staff: UserDTO[] }) {
  const [userId, setUserId] = useState('')
  const [month, setMonth] = useState(jalaliMonthNow())
  const [rows, setRows] = useState<WorkLogDTO[] | null>(null)
  const [form, setForm] = useState({ date: jalaliToday(), hours: '8', overtime: '0', note: '' })
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    if (!userId) { setRows([]); return }
    const q = new URLSearchParams({ userId, month })
    const r = await fetch(`/api/worklogs?${q}`)
    if (r.ok) setRows(await r.json())
  }, [userId, month])

  useEffect(() => {
    ;(async () => { await load() })()
  }, [load])

  /** آدرس خروجی اکسل با فیلترهای همین تب (کارمند + بازهٔ ماه) */
  const wlExportUrl = useMemo(() => {
    const q = new URLSearchParams()
    if (userId) q.set('userId', userId)
    if (month) {
      q.set('from', `${month}/01`)
      q.set('to', `${month}/31`)
    }
    const s = q.toString()
    return s ? `/api/worklogs/export?${s}` : '/api/worklogs/export'
  }, [userId, month])

  async function submit() {
    if (!userId) { toast.error('اول کارمند را انتخاب کنید'); return }
    setSaving(true)
    try {
      const r = await fetch('/api/worklogs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId, date: form.date.trim(),
          hours: Number(form.hours), overtime: Number(form.overtime) || 0,
          note: form.note || null,
        }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success('کارکرد ثبت شد')
      setForm({ ...form, note: '' })
      await load()
    } finally {
      setSaving(false)
    }
  }

  async function remove(id: string) {
    const r = await fetch(`/api/worklogs/${id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('حذف شد'); await load() }
    else toast.error('حذف ناموفق بود')
  }

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="space-y-3 p-4">
          <p className="text-sm font-bold">ثبت کارکرد</p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <F label="کارمند">
              <EmployeeSelect value={userId} onChange={setUserId} staff={staff} />
            </F>
            <F label="تاریخ (شمسی)"><Input dir="ltr" className="text-left" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></F>
            <F label="ساعت کارکرد"><Input dir="ltr" type="number" step="0.5" className="text-left" value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })} /></F>
            <F label="اضافه‌کاری"><Input dir="ltr" type="number" step="0.5" className="text-left" value={form.overtime} onChange={(e) => setForm({ ...form, overtime: e.target.value })} /></F>
          </div>
          <F label="توضیح (اختیاری)"><Input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></F>
          <Button onClick={submit} disabled={saving} size="sm" className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} ثبت کارکرد
          </Button>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center gap-2">
        <Input dir="ltr" className="w-32 text-left" inputMode="numeric" value={month} onChange={(e) => setMonth(formatJalaliPeriodInput(e.target.value))} placeholder="1405/08" aria-label="فیلتر ماه" />
        <p className="text-xs text-muted-foreground">نمایش {faDigits(rows?.length ?? 0)} رکورد</p>
        <ExportButton url={wlExportUrl} filename="worklogs.xlsx" label="خروجی اکسل" className="ms-auto" />
      </div>

      <Card>
        <CardContent className="p-0">
          {!rows ? (
            <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> در حال بارگذاری…</div>
          ) : rows.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">رکوردی نیست — کارمند را انتخاب کنید یا فیلتر ماه را عوض کنید</p>
          ) : (
            <div className="max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">تاریخ</TableHead>
                    <TableHead className="text-center">کارکرد</TableHead>
                    <TableHead className="text-center">اضافه‌کاری</TableHead>
                    <TableHead className="text-right">توضیح</TableHead>
                    <TableHead className="text-center">حذف</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell className="text-right font-medium">{faDigits(l.date)}</TableCell>
                      <TableCell className="text-center">{faNum(l.hours)}</TableCell>
                      <TableCell className="text-center">{l.overtime > 0 ? <Badge variant="secondary">{faNum(l.overtime)}</Badge> : '—'}</TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">{l.note || '—'}</TableCell>
                      <TableCell className="text-center">
                        <Button variant="ghost" size="icon" className="size-8" aria-label="حذف" onClick={() => remove(l.id)}>
                          <Trash2 className="size-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ─── تب فیش ────────────────────────────────────────────────────────

function PayslipTab({ staff }: { staff: UserDTO[] }) {
  const [userId, setUserId] = useState('')
  const [slips, setSlips] = useState<SlipDTO[] | null>(null)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ period: jalaliMonthNow(), baseSalary: '', note: '' })

  // آیتم‌های فعال تعریف‌شدهٔ فیش برای فرم صدور
  const [payItems, setPayItems] = useState<PayItemDTO[] | null>(null)
  const [amounts, setAmounts] = useState<Record<string, string>>({})
  const [customItems, setCustomItems] = useState<{ title: string; kind: 'BENEFIT' | 'DEDUCTION'; amount: string }[]>([])
  const [custom, setCustom] = useState<{ title: string; kind: 'BENEFIT' | 'DEDUCTION'; amount: string }>({ title: '', kind: 'BENEFIT', amount: '' })

  // ابزارهای تب: فیلتر دوره، حذف، بارگذاری اکسل و مدیریت آیتم‌ها
  const [periodInput, setPeriodInput] = useState('')
  const [slipPeriodFilter, setSlipPeriodFilter] = useState('')
  const [slipTarget, setSlipTarget] = useState<SlipDTO | null>(null)
  const [importOpen, setImportOpen] = useState(false)
  const [itemsOpen, setItemsOpen] = useState(false)

  const load = useCallback(async () => {
    const q = userId ? `?userId=${encodeURIComponent(userId)}` : ''
    const r = await fetch(`/api/payslips${q}`)
    if (r.ok) setSlips(await r.json())
  }, [userId])

  const loadItems = useCallback(async () => {
    const r = await fetch('/api/pay-items?active=1')
    if (r.ok) setPayItems(await r.json())
  }, [])

  useEffect(() => {
    ;(async () => { await load() })()
  }, [load])

  useEffect(() => {
    ;(async () => { await loadItems() })()
  }, [loadItems])

  const benefits = useMemo(() => (payItems ?? []).filter((i) => i.kind === 'BENEFIT'), [payItems])
  const deductions = useMemo(() => (payItems ?? []).filter((i) => i.kind === 'DEDUCTION'), [payItems])

  const visibleSlips = useMemo(
    () => (slips ?? []).filter((s) => !slipPeriodFilter || s.period === slipPeriodFilter),
    [slips, slipPeriodFilter]
  )

  function pickEmployee(id: string) {
    setUserId(id)
    const u = staff.find((s) => s.id === id)
    setForm((f) => ({ ...f, baseSalary: u?.baseSalary != null ? String(u.baseSalary) : '' }))
  }

  function addCustom() {
    const title = custom.title.trim()
    if (!title) { toast.error('عنوان آیتم را وارد کنید'); return }
    if ((Number(custom.amount) || 0) <= 0) { toast.error('مبلغ آیتم را وارد کنید'); return }
    setCustomItems((list) => [...list, { title, kind: custom.kind, amount: custom.amount }])
    setCustom((c) => ({ ...c, title: '', amount: '' }))
  }

  function sumKind(kind: 'BENEFIT' | 'DEDUCTION') {
    let total = 0
    for (const it of payItems ?? []) {
      if (it.kind !== kind) continue
      total += Number(amounts[it.title]) || 0
    }
    for (const c of customItems) {
      if (c.kind !== kind) continue
      total += Number(c.amount) || 0
    }
    return total
  }
  const net = (Number(form.baseSalary) || 0) + sumKind('BENEFIT') - sumKind('DEDUCTION')

  async function submit() {
    if (!userId) { toast.error('اول کارمند را انتخاب کنید'); return }
    const items: SlipItemDTO[] = []
    for (const it of payItems ?? []) {
      const amount = Number(amounts[it.title]) || 0
      if (amount > 0) items.push({ title: it.title, kind: it.kind, amount })
    }
    for (const c of customItems) {
      const amount = Number(c.amount) || 0
      if (amount > 0) items.push({ title: c.title, kind: c.kind, amount })
    }
    setSaving(true)
    try {
      const r = await fetch('/api/payslips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId, period: form.period.trim(),
          baseSalary: Number(form.baseSalary) || 0,
          items, note: form.note || null,
        }),
      })
      const data = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(data.error || 'صدور فیش ناموفق بود'); return }
      toast.success(`فیش صادر شد — خالص: ${faMoney(data.netPay)}`)
      setAmounts({})
      setCustomItems([])
      setForm((f) => ({ ...f, note: '' }))
      await load()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSaving(false)
    }
  }

  async function remove(id: string) {
    try {
      const r = await fetch(`/api/payslips/${id}`, { method: 'DELETE' })
      const data = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(data.error || 'حذف ناموفق بود'); return }
      toast.success('فیش حذف شد')
      setSlipTarget(null)
      await load()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  return (
    <div className="space-y-3">
      {/* ─── ابزارهای فیش ─── */}
      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" variant="outline" className="gap-1" onClick={() => setItemsOpen(true)}>
          <Settings2 className="size-4" /> آیتم‌های فیش (مزایا و کسورات)
        </Button>
        <Button size="sm" variant="outline" className="gap-1" onClick={() => setImportOpen(true)}>
          <Upload className="size-4" /> بارگذاری اکسل
        </Button>
        <ExportButton
          url={`/api/payslips/export${slipPeriodFilter ? `?period=${encodeURIComponent(slipPeriodFilter)}` : ''}`}
          filename="payslips.xlsx"
          label="خروجی اکسل"
        />
        <Button asChild size="sm" variant="outline" className="gap-1">
          <Link href={`/print/payslips${slipPeriodFilter ? `?period=${encodeURIComponent(slipPeriodFilter)}` : ''}`}>
            <Printer className="size-4" /> چاپ دوره
          </Link>
        </Button>

        <div className="ms-auto flex items-center gap-2">
          <Input
            dir="ltr"
            className="w-28 text-left"
            value={periodInput}
            onChange={(e) => setPeriodInput(formatJalaliPeriodInput(e.target.value))}
            onKeyDown={(e) => e.key === 'Enter' && setSlipPeriodFilter(periodInput.trim())}
            placeholder="1404/08"
            inputMode="numeric"
            aria-label="فیلتر دوره فیش‌ها"
          />
          <Button size="sm" variant="outline" onClick={() => setSlipPeriodFilter(periodInput.trim())}>
            نمایش
          </Button>
          {slipPeriodFilter && (
            <Button
              size="sm"
              variant="ghost"
              className="gap-1 px-2 text-muted-foreground"
              onClick={() => { setSlipPeriodFilter(''); setPeriodInput('') }}
            >
              <X className="size-4" /> همه
            </Button>
          )}
        </div>
      </div>

      {/* ─── فرم صدور فیش ─── */}
      <Card>
        <CardContent className="space-y-3 p-4">
          <p className="text-sm font-bold">صدور فیش حقوقی</p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <F label="کارمند"><EmployeeSelect value={userId} onChange={pickEmployee} staff={staff} /></F>
            <F label="دوره (ماه شمسی)"><Input dir="ltr" className="text-left" inputMode="numeric" value={form.period} onChange={(e) => setForm({ ...form, period: formatJalaliPeriodInput(e.target.value) })} placeholder="1405/08" /></F>
            <F label="حقوق پایه"><Input dir="ltr" type="number" inputMode="numeric" className="text-left" value={form.baseSalary} onChange={(e) => setForm({ ...form, baseSalary: e.target.value })} /></F>
          </div>
          <F label="یادداشت (اختیاری)"><Input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></F>

          {payItems === null ? (
            <p className="flex items-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="size-4 animate-spin" aria-hidden /> در حال بارگذاری آیتم‌های فیش…
            </p>
          ) : (
            <>
              {/* مزایا */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400">مزایا</p>
                {benefits.length === 0 ? (
                  <p className="text-xs text-muted-foreground">آیتمی تعریف نشده — از «آیتم‌های فیش» اضافه کنید</p>
                ) : (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                    {benefits.map((it) => (
                      <F key={it.id} label={it.title}>
                        <Input
                          dir="ltr"
                          type="number"
                          inputMode="numeric"
                          className="text-left"
                          placeholder="۰"
                          value={amounts[it.title] ?? ''}
                          onChange={(e) => setAmounts((a) => ({ ...a, [it.title]: e.target.value }))}
                          aria-label={`مبلغ ${it.title}`}
                        />
                      </F>
                    ))}
                  </div>
                )}
              </div>

              {/* کسورات */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-red-600">کسورات</p>
                {deductions.length === 0 ? (
                  <p className="text-xs text-muted-foreground">آیتمی تعریف نشده — از «آیتم‌های فیش» اضافه کنید</p>
                ) : (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                    {deductions.map((it) => (
                      <F key={it.id} label={it.title}>
                        <Input
                          dir="ltr"
                          type="number"
                          inputMode="numeric"
                          className="text-left"
                          placeholder="۰"
                          value={amounts[it.title] ?? ''}
                          onChange={(e) => setAmounts((a) => ({ ...a, [it.title]: e.target.value }))}
                          aria-label={`مبلغ ${it.title}`}
                        />
                      </F>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}

          {/* آیتم موردی (خارج از تعاریف) */}
          <div className="space-y-2 rounded-lg border border-dashed p-3">
            <p className="text-xs text-muted-foreground">آیتم موردی (یک‌بار مصرف، خارج از تعاریف):</p>
            <div className="flex flex-wrap items-center gap-2">
              <Input
                className="h-9 w-44"
                placeholder="عنوان آیتم"
                value={custom.title}
                onChange={(e) => setCustom({ ...custom, title: e.target.value })}
                aria-label="عنوان آیتم موردی"
              />
              <select
                className="h-9 rounded-md border bg-background px-3 text-sm"
                value={custom.kind}
                onChange={(e) => setCustom({ ...custom, kind: e.target.value as 'BENEFIT' | 'DEDUCTION' })}
                aria-label="نوع آیتم موردی"
              >
                <option value="BENEFIT">مزایا</option>
                <option value="DEDUCTION">کسورات</option>
              </select>
              <Input
                dir="ltr"
                type="number"
                inputMode="numeric"
                className="h-9 w-36 text-left"
                placeholder="۰"
                value={custom.amount}
                onChange={(e) => setCustom({ ...custom, amount: e.target.value })}
                aria-label="مبلغ آیتم موردی"
              />
              <Button type="button" size="sm" variant="outline" className="gap-1" onClick={addCustom}>
                <Plus className="size-4" /> افزودن
              </Button>
            </div>
            {customItems.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {customItems.map((c, i) => (
                  <span
                    key={`${c.title}-${i}`}
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
                      c.kind === 'BENEFIT'
                        ? 'bg-emerald-600/10 text-emerald-700 dark:text-emerald-400'
                        : 'bg-red-600/10 text-red-600'
                    }`}
                  >
                    {c.title}: {faNum(c.amount)}
                    <button
                      type="button"
                      aria-label={`حذف ${c.title}`}
                      className="rounded-full opacity-70 transition hover:opacity-100"
                      onClick={() => setCustomItems((list) => list.filter((_, j) => j !== i))}
                    >
                      <X className="size-3.5" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between rounded-lg bg-emerald-600/10 px-3 py-2 text-sm font-bold text-emerald-700 dark:text-emerald-400">
            <span>خالص پرداختی (محاسبه خودکار)</span>
            <span>{faMoney(net)}</span>
          </div>
          <Button onClick={submit} disabled={saving} size="sm" className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Plus className="size-4" />} صدور فیش
          </Button>
        </CardContent>
      </Card>

      {/* ─── فهرست فیش‌ها ─── */}
      {!slips ? (
        <Skeleton className="h-32 w-full" />
      ) : visibleSlips.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            {slipPeriodFilter
              ? 'فیشی برای این دوره پیدا نشد'
              : userId
                ? 'برای این کارمند فیشی صادر نشده است'
                : 'هنوز فیشی صادر نشده است'}
          </CardContent>
        </Card>
      ) : (
        <div className="max-h-96 space-y-3 overflow-y-auto pl-1">
          {visibleSlips.map((s) => (
            <Card key={s.id}>
              <CardContent className="p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Coins className="size-5 shrink-0 text-emerald-600" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold">{s.userName} — {periodLabel(s.period)}</p>
                    <p className="text-xs text-muted-foreground">
                      پایه {faMoney(s.baseSalary)} — خالص پرداختی: <b>{faMoney(s.netPay)}</b>
                    </p>
                  </div>
                  <Button asChild variant="outline" size="sm" className="gap-1">
                    <Link href={`/print/payslips?period=${encodeURIComponent(s.period)}&userId=${encodeURIComponent(s.userId)}`}>
                      <Printer className="size-4" /> چاپ
                    </Link>
                  </Button>
                  <Button variant="ghost" size="icon" className="size-8" aria-label="حذف فیش" onClick={() => setSlipTarget(s)}>
                    <Trash2 className="size-4 text-red-500" />
                  </Button>
                </div>
                {s.items.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t pt-3 text-xs">
                    {s.items.map((it, i) => (
                      <span
                        key={`${it.title}-${i}`}
                        className={it.kind === 'BENEFIT' ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600'}
                      >
                        {it.title}: {faMoney(it.amount)}
                      </span>
                    ))}
                  </div>
                )}
                {s.note && <p className="mt-2 text-xs text-muted-foreground">یادداشت: {s.note}</p>}
                <p className="mt-1 text-xs text-muted-foreground">صادرکننده: {s.issuedByName}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* تأیید حذف فیش */}
      <AlertDialog open={!!slipTarget} onOpenChange={(v) => !v && setSlipTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف فیش؟</AlertDialogTitle>
            <AlertDialogDescription>
              فیش {slipTarget?.userName} برای دوره {slipTarget ? periodLabel(slipTarget.period) : ''} حذف می‌شود و قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              onClick={(e) => { e.preventDefault(); if (slipTarget) void remove(slipTarget.id) }}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <ImportPayslipsDialog open={importOpen} onOpenChange={setImportOpen} onDone={load} />
      <PayItemsDialog open={itemsOpen} onOpenChange={setItemsOpen} onItemsChanged={loadItems} />
    </div>
  )
}

/** دیالوگ بارگذاری اکسل فیش‌ها */
function ImportPayslipsDialog({
  open, onOpenChange, onDone,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  onDone: () => Promise<void> | void
}) {
  const [file, setFile] = useState<File | null>(null)
  const [importing, setImporting] = useState(false)
  const [result, setResult] = useState<{
    imported: number
    updated: number
    failed: number
    problems: { row: number; username: string; reason: string }[]
    createdItems: string[]
  } | null>(null)

  useEffect(() => {
    if (open) { setFile(null); setResult(null) }
  }, [open])

  async function submit() {
    if (!file) { toast.error('فایل اکسل را انتخاب کنید'); return }
    setImporting(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const r = await fetch('/api/payslips/import', { method: 'POST', body: fd })
      const data = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(data.error || 'بارگذاری ناموفق بود'); return }
      setResult(data)
      toast.success(
        `${faNum(data.imported)} فیش ثبت شد${data.updated ? ` و ${faNum(data.updated)} فیش به‌روزرسانی شد` : ''}`
      )
      await onDone()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setImporting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader><DialogTitle>بارگذاری فیش‌ها از اکسل</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Button asChild variant="outline" size="sm" className="gap-1">
              <a href="/api/payslips/template">
                <FileDown className="size-4" /> دانلود قالب نمونه
              </a>
            </Button>
          </div>
          <p className="rounded-lg bg-muted/50 p-3 text-xs leading-6 text-muted-foreground">
            ستون‌های فایل: <b>نام کاربری، سال، ماه، حقوق پایه</b> و سپس یک ستون برای هر آیتم (مزایا یا کسورات).
            ستون‌های ناشناخته خودکار ساخته می‌شوند؛ عنوان‌های حاوی کسر/کسور/مالیات به‌عنوان کسورات شناخته می‌شوند.
            برای هر کارمند در هر دوره حداکثر یک فیش ثبت می‌شود و فیش تکراری به‌روزرسانی می‌شود.
          </p>
          <Input
            type="file"
            accept=".xlsx,.xls"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            aria-label="انتخاب فایل اکسل"
          />
          <Button onClick={submit} disabled={importing || !file} size="sm" className="gap-1">
            {importing ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" />}
            بارگذاری و ثبت فیش‌ها
          </Button>

          {result && (
            <div className="space-y-2 rounded-lg border p-3">
              <p className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-bold">
                <span className="text-emerald-700 dark:text-emerald-400">جدید: {faNum(result.imported)}</span>
                <span className="text-amber-600">به‌روزرسانی: {faNum(result.updated)}</span>
                <span className="text-red-600">ناموفق: {faNum(result.failed)}</span>
              </p>
              {result.createdItems.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  آیتم‌های تازه ساخته‌شده: {result.createdItems.join('، ')}
                </p>
              )}
              {result.problems.length > 0 && (
                <div>
                  <p className="mb-1 text-xs font-bold text-red-600">ردیف‌های دارای مشکل:</p>
                  <ul className="max-h-40 space-y-1 overflow-y-auto pl-1 text-xs text-muted-foreground">
                    {result.problems.map((p, i) => (
                      <li key={i} className="rounded bg-muted/50 px-2 py-1">
                        ردیف {faNum(p.row)} ({p.username || '—'}): {p.reason}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

/** دیالوگ مدیریت آیتم‌های فیش (مزایا و کسورات قابل تعریف) */
function PayItemsDialog({
  open, onOpenChange, onItemsChanged,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  onItemsChanged: () => Promise<void> | void
}) {
  const [items, setItems] = useState<PayItemDTO[] | null>(null)
  const [saving, setSaving] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editTitle, setEditTitle] = useState('')
  const [newTitle, setNewTitle] = useState<{ BENEFIT: string; DEDUCTION: string }>({ BENEFIT: '', DEDUCTION: '' })
  const [delTarget, setDelTarget] = useState<PayItemDTO | null>(null)

  const load = useCallback(async () => {
    const r = await fetch('/api/pay-items')
    if (r.ok) setItems(await r.json())
  }, [])

  useEffect(() => {
    if (open) {
      setItems(null)
      setEditingId(null)
      ;(async () => { await load() })()
    }
  }, [open, load])

  /** اجرای یک تغییر + بارگذاری مجدد آیتم‌های دیالوگ و فرم صدور */
  async function mutate(run: () => Promise<Response>, okMsg: string, afterOk?: () => void) {
    if (saving) return
    setSaving(true)
    try {
      const r = await run()
      const data = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(data.error || 'عملیات ناموفق بود'); return }
      toast.success(okMsg)
      afterOk?.()
      await load()
      await onItemsChanged()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSaving(false)
    }
  }

  function toggle(it: PayItemDTO) {
    void mutate(
      () => fetch(`/api/pay-items/${it.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !it.isActive }),
      }),
      it.isActive ? 'آیتم غیرفعال شد' : 'آیتم فعال شد'
    )
  }

  function saveEdit(it: PayItemDTO) {
    if (editingId !== it.id) return
    const title = editTitle.trim()
    if (!title || title === it.title) { setEditingId(null); return }
    setEditingId(null)
    void mutate(
      () => fetch(`/api/pay-items/${it.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title }),
      }),
      'عنوان آیتم ذخیره شد'
    )
  }

  function add(kind: 'BENEFIT' | 'DEDUCTION') {
    const title = newTitle[kind].trim()
    if (!title) { toast.error('عنوان آیتم را وارد کنید'); return }
    void mutate(
      () => fetch('/api/pay-items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, kind }),
      }),
      'آیتم اضافه شد',
      () => setNewTitle((n) => ({ ...n, [kind]: '' }))
    )
  }

  function removeItem() {
    if (!delTarget) return
    const target = delTarget
    setDelTarget(null)
    void mutate(
      () => fetch(`/api/pay-items/${target.id}`, { method: 'DELETE' }),
      'آیتم حذف شد'
    )
  }

  const benefits = (items ?? []).filter((i) => i.kind === 'BENEFIT')
  const deductions = (items ?? []).filter((i) => i.kind === 'DEDUCTION')

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader><DialogTitle>آیتم‌های فیش (مزایا و کسورات)</DialogTitle></DialogHeader>
          {items === null ? (
            <div className="flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" aria-hidden /> در حال بارگذاری…
            </div>
          ) : (
            <div className="space-y-4">
              <PayItemSection
                heading="مزایا"
                headingClass="text-emerald-700 dark:text-emerald-400"
                items={benefits}
                saving={saving}
                newTitle={newTitle.BENEFIT}
                onNewTitleChange={(v) => setNewTitle((n) => ({ ...n, BENEFIT: v }))}
                onAdd={() => add('BENEFIT')}
                onToggle={toggle}
                editingId={editingId}
                editTitle={editTitle}
                onEditTitleChange={setEditTitle}
                onStartEdit={(it) => { setEditingId(it.id); setEditTitle(it.title) }}
                onSaveEdit={saveEdit}
                onCancelEdit={() => setEditingId(null)}
                onDelete={setDelTarget}
              />
              <PayItemSection
                heading="کسورات"
                headingClass="text-red-600"
                items={deductions}
                saving={saving}
                newTitle={newTitle.DEDUCTION}
                onNewTitleChange={(v) => setNewTitle((n) => ({ ...n, DEDUCTION: v }))}
                onAdd={() => add('DEDUCTION')}
                onToggle={toggle}
                editingId={editingId}
                editTitle={editTitle}
                onEditTitleChange={setEditTitle}
                onStartEdit={(it) => { setEditingId(it.id); setEditTitle(it.title) }}
                onSaveEdit={saveEdit}
                onCancelEdit={() => setEditingId(null)}
                onDelete={setDelTarget}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* تأیید حذف آیتم */}
      <AlertDialog open={!!delTarget} onOpenChange={(v) => !v && setDelTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف «{delTarget?.title}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              این آیتم از تعاریف حذف می‌شود؛ فیش‌های صادرشدهٔ قبلی تغییری نمی‌کنند.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              onClick={(e) => { e.preventDefault(); removeItem() }}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

/** یک بخش از دیالوگ آیتم‌ها (مزایا یا کسورات) */
function PayItemSection({
  heading, headingClass, items, saving,
  newTitle, onNewTitleChange, onAdd,
  onToggle, editingId, editTitle, onEditTitleChange, onStartEdit, onSaveEdit, onCancelEdit, onDelete,
}: {
  heading: string
  headingClass: string
  items: PayItemDTO[]
  saving: boolean
  newTitle: string
  onNewTitleChange: (v: string) => void
  onAdd: () => void
  onToggle: (it: PayItemDTO) => void
  editingId: string | null
  editTitle: string
  onEditTitleChange: (v: string) => void
  onStartEdit: (it: PayItemDTO) => void
  onSaveEdit: (it: PayItemDTO) => void
  onCancelEdit: () => void
  onDelete: (it: PayItemDTO) => void
}) {
  return (
    <section className="space-y-2">
      <p className={`text-xs font-bold ${headingClass}`}>{heading}</p>
      {items.length === 0 ? (
        <p className="text-xs text-muted-foreground">آیتمی تعریف نشده است</p>
      ) : (
        <div className="space-y-2">
          {items.map((it) => (
            <div key={it.id} className="flex items-center gap-2 rounded-lg border px-3 py-2">
              {editingId === it.id ? (
                <Input
                  autoFocus
                  className="h-8 flex-1"
                  value={editTitle}
                  onChange={(e) => onEditTitleChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') onSaveEdit(it)
                    if (e.key === 'Escape') onCancelEdit()
                  }}
                  onBlur={() => onSaveEdit(it)}
                  aria-label="عنوان جدید آیتم"
                />
              ) : (
                <span className="min-w-0 flex-1 truncate text-sm">
                  {it.title}
                  {!it.isActive && <span className="text-xs text-muted-foreground"> (غیرفعال)</span>}
                </span>
              )}
              <Switch
                checked={it.isActive}
                onCheckedChange={() => onToggle(it)}
                disabled={saving}
                aria-label={`${it.isActive ? 'غیرفعال کردن' : 'فعال کردن'} ${it.title}`}
              />
              <Button variant="ghost" size="icon" className="size-8" aria-label={`ویرایش ${it.title}`} onClick={() => onStartEdit(it)} disabled={saving}>
                <Pencil className="size-4" />
              </Button>
              <Button variant="ghost" size="icon" className="size-8" aria-label={`حذف ${it.title}`} onClick={() => onDelete(it)} disabled={saving}>
                <Trash2 className="size-4 text-red-500" />
              </Button>
            </div>
          ))}
        </div>
      )}
      <div className="flex items-center gap-2">
        <Input
          className="h-9 flex-1"
          placeholder={`عنوان ${heading} جدید`}
          value={newTitle}
          onChange={(e) => onNewTitleChange(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && onAdd()}
          aria-label={`عنوان ${heading} جدید`}
        />
        <Button size="sm" className="gap-1" onClick={onAdd} disabled={saving}>
          <Plus className="size-4" /> افزودن
        </Button>
      </div>
    </section>
  )
}

// ─── تب امتیاز ─────────────────────────────────────────────────────

function ScoreTab({ staff }: { staff: UserDTO[] }) {
  const [userId, setUserId] = useState('')
  const [rows, setRows] = useState<ScoreEntryDTO[] | null>(null)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ period: jalaliMonthNow(), score: '85', note: '' })

  const load = useCallback(async () => {
    if (!userId) { setRows([]); return }
    const r = await fetch(`/api/scores?userId=${userId}`)
    if (r.ok) setRows(await r.json())
  }, [userId])

  useEffect(() => {
    ;(async () => { await load() })()
  }, [load])

  async function submit() {
    if (!userId) { toast.error('اول کارمند را انتخاب کنید'); return }
    setSaving(true)
    try {
      const r = await fetch('/api/scores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId, period: form.period.trim(),
          score: Number(form.score), note: form.note || null,
        }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success('امتیاز ثبت شد (برای تکرار دوره، به‌روزرسانی می‌شود)')
      setForm({ ...form, note: '' })
      await load()
    } finally {
      setSaving(false)
    }
  }

  async function remove(id: string) {
    const r = await fetch(`/api/scores/${id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('حذف شد'); await load() }
  }

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="space-y-3 p-4">
          <p className="text-sm font-bold">ثبت امتیاز کارمند</p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <F label="کارمند"><EmployeeSelect value={userId} onChange={setUserId} staff={staff} /></F>
            <F label="دوره (ماه شمسی)"><Input dir="ltr" className="text-left" inputMode="numeric" value={form.period} onChange={(e) => setForm({ ...form, period: formatJalaliPeriodInput(e.target.value) })} placeholder="1405/08" /></F>
            <F label="امتیاز (۰ تا ۱۰۰)"><Input dir="ltr" type="number" min={0} max={100} className="text-left" value={form.score} onChange={(e) => setForm({ ...form, score: e.target.value })} /></F>
          </div>
          <F label="توضیح (اختیاری)"><Textarea rows={2} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></F>
          <Button onClick={submit} disabled={saving} size="sm" className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} ثبت امتیاز
          </Button>
        </CardContent>
      </Card>

      {!rows ? (
        <Skeleton className="h-24 w-full" />
      ) : rows.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">امتیازی ثبت نشده است</CardContent></Card>
      ) : (
        rows.map((s) => (
          <Card key={s.id}>
            <CardContent className="flex items-center gap-3 p-4">
              <Star className="size-5 text-amber-500" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold">{periodLabel(s.period)} — امتیاز {faNum(s.score)}</p>
                <p className="text-xs text-muted-foreground">{s.note || '—'}</p>
              </div>
              <Badge variant="secondary">{faNum(s.score)} از ۱۰۰</Badge>
              <Button variant="ghost" size="icon" className="size-8" aria-label="حذف امتیاز" onClick={() => remove(s.id)}>
                <Trash2 className="size-4 text-red-500" />
              </Button>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )
}

// ─── اجزای کوچک ────────────────────────────────────────────────────

function F({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  )
}

function EmployeeSelect({
  value, onChange, staff,
}: {
  value: string
  onChange: (v: string) => void
  staff: UserDTO[]
}) {
  return (
    <select
      className="h-9 w-full rounded-md border bg-background px-3 text-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      aria-label="انتخاب کارمند"
    >
      <option value="">— انتخاب کارمند —</option>
      {staff.map((u) => (
        <option key={u.id} value={u.id}>
          {u.fullName}{u.isActive ? '' : ' (غیرفعال)'}
        </option>
      ))}
    </select>
  )
}
