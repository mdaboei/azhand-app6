import type { Metadata, Viewport } from 'next'
import 'vazirmatn/Vazirmatn-font-face.css'
import './globals.css'
import { Toaster } from '@/components/ui/sonner'
import { ThemeProvider } from '@/components/theme-provider'
import { PwaRegister } from '@/components/pwa-register'
import { CapacitorBack } from '@/components/capacitor-back'

export const metadata: Metadata = {
  title: 'آژند اپ — شرکت آژند همت توس',
  description: 'سامانه داخلی شرکت آژند همت توس — اطلاع‌رسانی، کارکرد و فیش حقوقی کارکنان',
  applicationName: 'آژند اپ',
  manifest: '/manifest.webmanifest',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'آژند اپ',
  },
  icons: {
    icon: '/icon-192.png',
    apple: '/apple-touch-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#efe6de',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground">
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          themes={['light', 'dark', 'emerald', 'violet']}
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <PwaRegister />
          <CapacitorBack />
          <Toaster
            position="top-center"
            richColors
            offset="var(--safe-top, 0px)"
          />
        </ThemeProvider>
      </body>
    </html>
  )
}
