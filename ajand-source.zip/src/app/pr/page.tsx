'use client'

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Loader2, Megaphone, Pencil, Plus, ShieldCheck, Trash2, ImagePlus, X } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { NewsPostDTO } from '@/lib/types'
import { useRoles } from '@/hooks/use-roles'
import { faDate, faDigits, isRecent } from '@/lib/persian'

/** گزینه‌های مدت اعتبار اطلاعیه */
const EXPIRY_OPTIONS = [
  { value: '0', label: 'بدون انقضا (می‌ماند تا حذف)' },
  { value: '7', label: 'یک هفته' },
  { value: '30', label: 'یک ماه' },
  { value: '90', label: 'سه ماه' },
]

export default function PrPage() {
  const [posts, setPosts] = useState<NewsPostDTO[] | null>(null)
  const [editing, setEditing] = useState<NewsPostDTO | null>(null)
  const [openAdd, setOpenAdd] = useState(false)

  const load = useCallback(async () => {
    const r = await fetch('/api/news?scope=manage')
    if (r.ok) setPosts(await r.json())
    else toast.error('دریافت اطلاعیه‌ها ناموفق بود')
  }, [])

  useEffect(() => {
    ;(async () => { await load() })()
  }, [load])

  async function remove(id: string) {
    const r = await fetch(`/api/news/${id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('اطلاعیه حذف شد'); await load() }
    else toast.error('حذف ناموفق بود')
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          این‌ها همان چیزی است که در صفحه اصلی شرکت نمایش داده می‌شود
        </p>
        <Button size="sm" className="gap-1" onClick={() => setOpenAdd(true)}>
          <Plus className="size-4" /> اطلاعیه جدید
        </Button>
      </div>

      {!posts ? (
        <Skeleton className="h-40 w-full" />
      ) : posts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
            <Megaphone className="size-10 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">هنوز اطلاعیه‌ای منتشر نکرده‌اید</p>
          </CardContent>
        </Card>
      ) : (
        posts.map((n) => (
          <Card key={n.id} className={n.isUrgent ? 'border-red-300 dark:border-red-900' : ''}>
            <CardContent className="space-y-2 p-4">
              <div className="flex flex-wrap items-center gap-2">
                {n.isUrgent && (
                  <Badge variant="destructive" className="gap-1">
                    <ShieldCheck className="size-3" /> فوری
                  </Badge>
                )}
                {isRecent(n.createdAt) && <Badge className="bg-brand-600 hover:bg-brand-600">جدید</Badge>}
                <h3 className="text-sm font-bold leading-6">{n.title}</h3>
              </div>
              <p className="line-clamp-2 whitespace-pre-line text-sm leading-7 text-foreground/80">{n.body}</p>
              <div className="flex flex-wrap items-center gap-3 border-t pt-2 text-xs text-muted-foreground">
                {n.targetRoleLabel && <Badge variant="outline">مخصوص: {n.targetRoleLabel}</Badge>}
                <span>{faDate(n.createdAt)}</span>
                <span>اعتبار: {n.expiresAt ? faDate(n.expiresAt) : 'نامحدود'}</span>
                <div className="flex-1" />
                <Button variant="outline" size="sm" className="gap-1" onClick={() => setEditing(n)}>
                  <Pencil className="size-3.5" /> ویرایش
                </Button>
                <Button variant="ghost" size="icon" className="size-8" aria-label="حذف اطلاعیه" onClick={() => remove(n.id)}>
                  <Trash2 className="size-4 text-red-500" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))
      )}

      <NewsDialog
        open={openAdd}
        onOpenChange={setOpenAdd}
        reload={load}
      />
      <NewsDialog
        open={!!editing}
        onOpenChange={(v) => !v && setEditing(null)}
        post={editing}
        reload={load}
      />
    </div>
  )
}

function NewsDialog({
  open, onOpenChange, post, reload,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  post?: NewsPostDTO | null
  reload: () => Promise<void>
}) {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [isUrgent, setIsUrgent] = useState(false)
  const [targetRole, setTargetRole] = useState('')
  const [expiryDays, setExpiryDays] = useState('0')
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const { roles } = useRoles()

  useEffect(() => {
    if (open) {
      setTitle(post?.title ?? '')
      setBody(post?.body ?? '')
      setIsUrgent(post?.isUrgent ?? false)
      setTargetRole(post?.targetRole ?? '')
      setExpiryDays('0')
      setFile(null)
      setPreview(null)
    }
  }, [open, post])

  function pickImage(f: File | null) {
    setFile(f)
    if (preview) URL.revokeObjectURL(preview)
    setPreview(f ? URL.createObjectURL(f) : null)
  }

  async function submit() {
    setSaving(true)
    try {
      let r: Response
      if (post) {
        // ویرایش — JSON (تغییر عکس در ویرایش پشتیبانی نمی‌شود)
        r = await fetch(`/api/news/${post.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: title.trim(),
            body: body.trim(),
            isUrgent,
            targetRole: targetRole || null,
          }),
        })
      } else {
        // انتشار — multipart با عکس اختیاری
        const form = new FormData()
        form.set('title', title.trim())
        form.set('body', body.trim())
        form.set('isUrgent', String(isUrgent))
        form.set('expiresInDays', expiryDays)
        form.set('targetRole', targetRole || 'ALL')
        if (file) form.set('image', file)
        r = await fetch('/api/news', { method: 'POST', body: form })
      }
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ذخیره ناموفق بود'); return }
      toast.success(post ? 'اطلاعیه ویرایش شد' : 'اطلاعیه منتشر شد')
      if (preview) URL.revokeObjectURL(preview)
      onOpenChange(false)
      await reload()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{post ? 'ویرایش اطلاعیه' : 'اطلاعیه جدید'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان *</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">متن اطلاعیه *</Label>
            <Textarea rows={5} value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
          {!post && (
            <div className="space-y-1.5">
              <Label className="text-xs">عکس پست (اختیاری — حداکثر ۵ مگابایت)</Label>
              {preview ? (
                <div className="relative overflow-hidden rounded-lg border">
                  <img src={preview} alt="پیش‌نمایش عکس" className="max-h-56 w-full object-cover" />
                  <button
                    type="button"
                    onClick={() => pickImage(null)}
                    aria-label="حذف عکس"
                    className="absolute left-2 top-2 rounded-full bg-black/60 p-1.5 text-white"
                  >
                    <X className="size-4" />
                  </button>
                </div>
              ) : (
                <label className="flex h-20 cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border border-dashed text-xs text-muted-foreground transition-colors hover:bg-muted/50">
                  <ImagePlus className="size-5" />
                  انتخاب عکس
                  <input
                    type="file"
                    accept="image/*"
                    className="sr-only"
                    onChange={(e) => pickImage(e.target.files?.[0] ?? null)}
                  />
                </label>
              )}
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">نمایش برای</Label>
              <select
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                aria-label="مخاطب اطلاعیه"
              >
                <option value="">همه (صفحه اصلی عمومی)</option>
                {(roles ?? []).filter((r) => r.key !== 'ADMIN').map((r) => (
                  <option key={r.key} value={r.key}>{r.label}</option>
                ))}
              </select>
            </div>
            {!post && (
              <div className="space-y-1.5">
                <Label className="text-xs">مدت اعتبار</Label>
                <select
                  className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                  value={expiryDays}
                  onChange={(e) => setExpiryDays(e.target.value)}
                  aria-label="مدت اعتبار"
                >
                  {EXPIRY_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
          <label className="flex cursor-pointer items-center gap-2 text-sm">
            <input
              type="checkbox"
              className="size-4 accent-brand-600"
              checked={isUrgent}
              onChange={(e) => setIsUrgent(e.target.checked)}
            />
            فوری و مهم (با رنگ قرمز بالا نمایش داده می‌شود)
          </label>
          {!post && expiryDays !== '0' && (
            <p className="text-xs text-muted-foreground">
              این اطلاعیه تا {faDigits(expiryDays)} روز در صفحه اصلی می‌ماند و بعد خودکار مخفی می‌شود.
            </p>
          )}
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving} className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Megaphone className="size-4" />}
            {post ? 'ذخیره تغییرات' : 'انتشار'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
