import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function PrLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('PR')
  return (
    <PanelShell fullName={user.fullName}
      roleLabel={roleLabel}
      role={session.role as 'PR' | 'ADMIN'} unitLabel={session.role === 'ADMIN' ? 'روابط عمومی' : null} panels={panels}>
      {children}
    </PanelShell>
  )
}
