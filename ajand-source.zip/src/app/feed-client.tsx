'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  Clock, Heart, ImagePlus, Loader2, MessageCircle, Megaphone,
  Send, ShieldCheck, Trash2, X,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { NewsPostDTO, type Role } from '@/lib/types'
import { useRoles } from '@/hooks/use-roles'
import { faDate, faDigits } from '@/lib/persian'

interface CommentDTO {
  id: string
  body: string
  authorName: string
  authorRole: string
  isMine: boolean
  createdAt: string
}

interface Viewer {
  role: Role
  fullName: string
}

const ROLE_AVATAR_COLORS: Record<string, string> = {
  ADMIN: 'bg-red-600',
  PR: 'bg-brand-600',
  HR: 'bg-emerald-600',
  FINANCE: 'bg-amber-600',
  INSURANCE: 'bg-teal-600',
  MACHINERY: 'bg-stone-600',
  MANAGEMENT: 'bg-violet-600',
  EMPLOYEE: 'bg-sky-700',
}

/** زمان نسبی فارسی — مثل اینستاگرام */
function relTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60_000)
  if (m < 1) return 'همین حالا'
  if (m < 60) return `${faDigits(m)} دقیقه پیش`
  const h = Math.floor(m / 60)
  if (h < 24) return `${faDigits(h)} ساعت پیش`
  const d = Math.floor(h / 24)
  if (d < 7) return `${faDigits(d)} روز پیش`
  return faDate(iso)
}

export function Feed({
  initialPosts,
  viewer,
}: {
  initialPosts: NewsPostDTO[]
  viewer: Viewer | null
}) {
  const [posts, setPosts] = useState(initialPosts)
  const [openComments, setOpenComments] = useState<Record<string, boolean>>({})
  const [openPost, setOpenPost] = useState(false)

  const reload = useCallback(async () => {
    const r = await fetch('/api/news')
    if (r.ok) setPosts(await r.json())
  }, [])

  async function toggleLike(post: NewsPostDTO) {
    if (!viewer) { toast.error('برای پسندیدن، اول وارد شوید'); return }
    // آپدیت خوش‌بینانه
    setPosts((prev) => prev.map((p) => p.id === post.id
      ? {
          ...p,
          likedByMe: !p.likedByMe,
          likeCount: p.likeCount + (p.likedByMe ? -1 : 1),
        }
      : p))
    const r = await fetch(`/api/news/${post.id}/like`, { method: 'POST' })
    if (!r.ok) {
      toast.error('خطا در ثبت پسند')
      setPosts((prev) => prev.map((p) => p.id === post.id
        ? { ...p, likedByMe: post.likedByMe, likeCount: post.likeCount }
        : p))
    }
  }

  const canPost = viewer?.role === 'PR' || viewer?.role === 'ADMIN'

  return (
    <>
      {canPost && (
        <Button onClick={() => setOpenPost(true)} className="mb-4 w-full gap-2 rounded-xl">
          <ImagePlus className="size-4" /> پست جدید با عکس
        </Button>
      )}

      <section aria-label="فید اطلاعیه‌ها" className="space-y-5">
        {posts.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
              <Megaphone className="size-10 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">هنوز پستی منتشر نشده است</p>
            </CardContent>
          </Card>
        )}
        {posts.map((post) => (
          <PostCard
            key={post.id}
            post={post}
            viewer={viewer}
            commentsOpen={!!openComments[post.id]}
            onToggleComments={() =>
              setOpenComments((prev) => ({ ...prev, [post.id]: !prev[post.id] }))}
            onToggleLike={() => toggleLike(post)}
          />
        ))}
      </section>

      {canPost && (
        <CreatePostDialog
          open={openPost}
          onOpenChange={setOpenPost}
          onCreated={() => { setOpenPost(false); void reload() }}
        />
      )}
    </>
  )
}

// ─── کارت پست ──────────────────────────────────────────────────────

function PostCard({
  post, viewer, commentsOpen, onToggleComments, onToggleLike,
}: {
  post: NewsPostDTO
  viewer: Viewer | null
  commentsOpen: boolean
  onToggleComments: () => void
  onToggleLike: () => void
}) {
  const initial = post.authorName.trim().charAt(0) || '؟'
  return (
    <article className="overflow-hidden rounded-2xl border bg-card shadow-sm">
      {/* هدر پست */}
      <div className="flex items-center gap-3 p-4 pb-3">
        <div
          aria-hidden
          className={`flex size-10 shrink-0 items-center justify-center rounded-full text-base font-bold text-white ${ROLE_AVATAR_COLORS[post.targetRole ?? ''] ?? 'bg-stone-500'}`}
        >
          {initial}
        </div>
        <div className="min-w-0 flex-1">
          <p className="flex flex-wrap items-center gap-x-2 text-sm font-bold leading-5">
            {post.authorName}
            {post.isUrgent && (
              <Badge variant="destructive" className="gap-0.5 px-1.5 py-0 text-[10px]">
                <ShieldCheck className="size-2.5" /> فوری
              </Badge>
            )}
          </p>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Clock className="size-3" /> {relTime(post.createdAt)}
            {post.targetRoleLabel && <span>· {post.targetRoleLabel}</span>}
          </p>
        </div>
      </div>

      {/* عکس پست */}
      {post.hasImage && (
        <img
          src={`/api/news/${post.id}/image`}
          alt={post.title}
          loading="lazy"
          className="max-h-[28rem] w-full border-y bg-muted object-cover"
        />
      )}

      <CardContent className="space-y-2 p-4">
        {/* ردیف اقدامات */}
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={onToggleLike}
            aria-pressed={post.likedByMe}
            aria-label={post.likedByMe ? 'برداشتن پسند' : 'پسندیدن'}
            className={`flex items-center gap-1.5 text-sm transition-colors ${post.likedByMe ? 'text-red-500' : 'text-muted-foreground hover:text-red-500'}`}
          >
            <Heart className={`size-5 ${post.likedByMe ? 'fill-current' : ''}`} />
            {post.likeCount > 0 && faDigits(post.likeCount)}
          </button>
          <button
            type="button"
            onClick={onToggleComments}
            aria-expanded={commentsOpen}
            aria-label="نمایش کامنت‌ها"
            className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <MessageCircle className="size-5" />
            {post.commentCount > 0 && faDigits(post.commentCount)}
          </button>
          {post.expiresAt && (
            <span className="ms-auto text-xs text-muted-foreground">
              اعتبار تا {faDate(post.expiresAt)}
            </span>
          )}
        </div>

        {/* متن پست */}
        <p className="text-sm font-bold leading-6">{post.title}</p>
        <p className="whitespace-pre-line text-sm leading-7 text-foreground/80">{post.body}</p>

        {/* کامنت‌ها */}
        {commentsOpen && (
          <Comments postId={post.id} viewer={viewer} />
        )}
      </CardContent>
    </article>
  )
}

// ─── کامنت‌ها ───────────────────────────────────────────────────────

function Comments({ postId, viewer }: { postId: string; viewer: Viewer | null }) {
  const [comments, setComments] = useState<CommentDTO[] | null>(null)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)

  const load = useCallback(async () => {
    const r = await fetch(`/api/news/${postId}/comments`)
    if (r.ok) setComments(await r.json())
  }, [postId])

  useEffect(() => { (async () => { await load() })() }, [load])

  async function send() {
    const body = text.trim()
    if (!body) return
    setSending(true)
    try {
      const r = await fetch(`/api/news/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ثبت کامنت ناموفق بود'); return }
      setComments((prev) => [...(prev ?? []), data])
      setText('')
    } finally {
      setSending(false)
    }
  }

  async function remove(cid: string) {
    const r = await fetch(`/api/news/${postId}/comments/${cid}`, { method: 'DELETE' })
    if (r.ok) setComments((prev) => (prev ?? []).filter((c) => c.id !== cid))
    else toast.error('حذف ناموفق بود')
  }

  return (
    <div className="space-y-3 rounded-xl bg-muted/50 p-3">
      <p className="text-xs font-bold text-muted-foreground">
        کامنت‌ها {comments && comments.length > 0 && `(${faDigits(comments.length)})`}
      </p>

      <div ref={listRef} className="max-h-72 space-y-2.5 overflow-y-auto">
        {comments === null && <p className="text-xs text-muted-foreground">در حال بارگذاری…</p>}
        {comments?.length === 0 && (
          <p className="text-xs text-muted-foreground">اولین کامنت را شما بنویسید</p>
        )}
        {comments?.map((c) => (
          <div key={c.id} className="flex items-start gap-2 text-sm">
            <div
              aria-hidden
              className={`mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white ${ROLE_AVATAR_COLORS[c.authorRole] ?? 'bg-stone-500'}`}
            >
              {c.authorName.trim().charAt(0)}
            </div>
            <div className="min-w-0 flex-1 rounded-lg bg-background px-3 py-2">
              <p className="flex items-baseline gap-2">
                <span className="text-xs font-bold">{c.authorName}</span>
                <span className="text-[10px] text-muted-foreground">{relTime(c.createdAt)}</span>
              </p>
              <p className="whitespace-pre-line text-sm leading-6">{c.body}</p>
            </div>
            {(c.isMine || viewer?.role === 'ADMIN' || viewer?.role === 'PR') && (
              <button
                type="button"
                onClick={() => remove(c.id)}
                aria-label="حذف کامنت"
                className="mt-1 text-muted-foreground transition-colors hover:text-red-500"
              >
                <Trash2 className="size-3.5" />
              </button>
            )}
          </div>
        ))}
      </div>

      {viewer ? (
        <div className="flex items-center gap-2">
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send() } }}
            placeholder="کامنت خود را بنویسید…"
            className="h-9 bg-background"
            aria-label="متن کامنت"
          />
          <Button size="icon" className="size-9 shrink-0" onClick={send} disabled={sending || !text.trim()} aria-label="ارسال کامنت">
            {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          </Button>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">
          <Link href="/login" className="text-brand-600 underline underline-offset-2">وارد شوید</Link>
          {' '}تا بتوانید کامنت بگذارید.
        </p>
      )}
    </div>
  )
}

// ─── دیالوگ پست جدید ────────────────────────────────────────────────

const EXPIRY_OPTIONS = [
  { value: '0', label: 'بدون انقضا' },
  { value: '7', label: 'یک هفته' },
  { value: '30', label: 'یک ماه' },
  { value: '90', label: 'سه ماه' },
]

export function CreatePostDialog({
  open, onOpenChange, onCreated,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  onCreated: () => void
}) {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [isUrgent, setIsUrgent] = useState(false)
  const [expiry, setExpiry] = useState('0')
  const [targetRole, setTargetRole] = useState('ALL')
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const { roles } = useRoles()

  useEffect(() => {
    if (!open) {
      setTitle(''); setBody(''); setIsUrgent(false); setExpiry('0')
      setTargetRole('ALL'); setFile(null); setPreview(null)
    }
  }, [open])

  function pickImage(f: File | null) {
    setFile(f)
    if (preview) URL.revokeObjectURL(preview)
    setPreview(f ? URL.createObjectURL(f) : null)
  }

  async function submit() {
    setSaving(true)
    try {
      const form = new FormData()
      form.set('title', title.trim())
      form.set('body', body.trim())
      form.set('isUrgent', String(isUrgent))
      form.set('expiresInDays', expiry)
      form.set('targetRole', targetRole)
      if (file) form.set('image', file)
      const r = await fetch('/api/news', { method: 'POST', body: form })
      const data = await r.json().catch(() => null)
      if (!r.ok) { toast.error(data?.error || 'انتشار ناموفق بود'); return }
      toast.success('پست منتشر شد')
      onCreated()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>پست جدید</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان *</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: اطلاعیه تعطیلات" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">متن پست *</Label>
            <Textarea rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">عکس پست (اختیاری — حداکثر ۵ مگابایت)</Label>
            {preview ? (
              <div className="relative overflow-hidden rounded-lg border">
                <img src={preview} alt="پیش‌نمایش عکس" className="max-h-56 w-full object-cover" />
                <button
                  type="button"
                  onClick={() => pickImage(null)}
                  aria-label="حذف عکس"
                  className="absolute left-2 top-2 rounded-full bg-black/60 p-1.5 text-white"
                >
                  <X className="size-4" />
                </button>
              </div>
            ) : (
              <label className="flex h-24 cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border border-dashed text-xs text-muted-foreground transition-colors hover:bg-muted/50">
                <ImagePlus className="size-5" />
                انتخاب عکس
                <input
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={(e) => pickImage(e.target.files?.[0] ?? null)}
                />
              </label>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">اعتبار</Label>
              <select
                className="h-9 w-full rounded-md border bg-background px-2 text-sm"
                value={expiry}
                onChange={(e) => setExpiry(e.target.value)}
                aria-label="مدت اعتبار"
              >
                {EXPIRY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">نمایش برای</Label>
              <select
                className="h-9 w-full rounded-md border bg-background px-2 text-sm"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                aria-label="نقش هدف"
              >
                <option value="ALL">همه</option>
                {(roles ?? []).map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}
              </select>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <Label className="text-xs">فوری (با نشان قرمز)</Label>
            <Switch checked={isUrgent} onCheckedChange={setIsUrgent} aria-label="فوری" />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving || title.trim().length < 3 || body.trim().length < 3} className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />} انتشار
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
