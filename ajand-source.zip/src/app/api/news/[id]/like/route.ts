import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, requireSession, serverError } from '@/lib/api-helpers'

/** لایک/برداشتن لایک پست — همهٔ کاربران واردشده (toggle) */
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireSession()
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const post = await db.newsPost.findUnique({ where: { id }, select: { id: true } })
    if (!post) return ok({ liked: false, count: 0 }, 404)

    const existing = await db.newsLike.findUnique({
      where: { postId_userId: { postId: id, userId: g.session.userId } },
    })

    if (existing) {
      await db.newsLike.delete({ where: { id: existing.id } })
    } else {
      await db.newsLike.create({
        data: { postId: id, userId: g.session.userId },
      })
    }

    const count = await db.newsLike.count({ where: { postId: id } })
    return ok({ liked: !existing, count })
  } catch (e) {
    return serverError(e)
  }
}
