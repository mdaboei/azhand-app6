import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, serverError } from '@/lib/api-helpers'

/** کامنت‌های پست — خواندن برای همهٔ کاربران واردشده، ثبت برای همهٔ کاربران واردشده */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireSession()
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const rows = await db.newsComment.findMany({
      where: { postId: id },
      orderBy: { createdAt: 'asc' },
      include: { user: { select: { fullName: true, role: true } } },
      take: 200,
    })
    return ok(rows.map((c) => ({
      id: c.id,
      body: c.body,
      authorName: c.user.fullName,
      authorRole: c.user.role,
      isMine: c.userId === g.session.userId,
      createdAt: c.createdAt.toISOString(),
    })))
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireSession()
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const body = String((await req.json().catch(() => null))?.body ?? '').trim()
    if (body.length < 1) return fail('متن کامنت خالی است', 422)
    if (body.length > 1000) return fail('کامنت خیلی بلند است (حداکثر ۱۰۰۰ نویسه)', 422)

    const post = await db.newsPost.findUnique({ where: { id }, select: { id: true } })
    if (!post) return fail('پست پیدا نشد', 404)

    const c = await db.newsComment.create({
      data: { postId: id, userId: g.session.userId, body },
      include: { user: { select: { fullName: true, role: true } } },
    })
    return ok({
      id: c.id,
      body: c.body,
      authorName: c.user.fullName,
      authorRole: c.user.role,
      isMine: true,
      createdAt: c.createdAt.toISOString(),
    }, 201)
  } catch (e) {
    return serverError(e)
  }
}
