import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, serverError } from '@/lib/api-helpers'

/** حذف کامنت — نویسندهٔ کامنت یا روابط عمومی/ادمین */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; cid: string }> },
) {
  const g = await requireSession()
  if ('res' in g) return g.res
  try {
    const { cid } = await params
    const c = await db.newsComment.findUnique({ where: { id: cid } })
    if (!c) return fail('کامنت پیدا نشد', 404)

    const canModerate = g.session.role === 'ADMIN' || g.session.role === 'PR'
    if (c.userId !== g.session.userId && !canModerate) {
      return fail('فقط نویسنده یا مدیر روابط عمومی می‌تواند کامنت را حذف کند', 403)
    }

    await db.newsComment.delete({ where: { id: cid } })
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
}
