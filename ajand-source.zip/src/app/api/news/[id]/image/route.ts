import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { serverError } from '@/lib/api-helpers'

/** سرو عکس پست — هم‌مبدا و با کوکی؛ کش مرورگر یک ساعت */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const post = await db.newsPost.findUnique({
      where: { id },
      select: { imageMime: true, imageData: true },
    })
    if (!post?.imageData) {
      return new Response('Not found', { status: 404 })
    }
    return new Response(new Uint8Array(post.imageData), {
      headers: {
        'Content-Type': post.imageMime || 'application/octet-stream',
        'Cache-Control': 'public, max-age=3600',
      },
    })
  } catch (e) {
    return serverError(e)
  }
}
