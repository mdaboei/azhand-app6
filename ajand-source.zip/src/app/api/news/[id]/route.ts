import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { newsPostUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { isValidRole } from '@/lib/roles'

/** ویرایش اطلاعیه — روابط عمومی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('PR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = newsPostUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    if (input.targetRole && !(await isValidRole(input.targetRole))) {
      return fail('نقش هدف معتبر نیست', 422)
    }

    const exists = await db.newsPost.findUnique({ where: { id } })
    if (!exists) return fail('اطلاعیه پیدا نشد', 404)

    const post = await db.newsPost.update({
      where: { id },
      data: {
        ...(input.title !== undefined ? { title: input.title } : {}),
        ...(input.body !== undefined ? { body: input.body } : {}),
        ...(input.isUrgent !== undefined ? { isUrgent: input.isUrgent } : {}),
        ...(input.expiresAt !== undefined ? { expiresAt: input.expiresAt ? new Date(input.expiresAt) : null } : {}),
        ...(input.targetRole !== undefined ? { targetRole: input.targetRole || null } : {}),
      },
    })
    return ok({ id: post.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف اطلاعیه — روابط عمومی و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('PR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.newsPost.findUnique({ where: { id } })
    if (!exists) return fail('اطلاعیه پیدا نشد', 404)
    await db.newsPost.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
