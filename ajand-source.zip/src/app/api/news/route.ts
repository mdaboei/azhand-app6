import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession } from '@/lib/session'
import {ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { getRoleLabelMap, isValidRole } from '@/lib/roles'

const MAX_IMAGE = 5 * 1024 * 1024 // ۵ مگابایت

/**
 * اخبار — فید صفحهٔ اصلی:
 *  GET  → اطلاعیه‌های قابل نمایش + تعداد لایک/کامنت + وضعیت لایک خود کاربر
 *         (?scope=manage فقط روابط عمومی و ادمین → همهٔ اطلاعیه‌ها)
 *  POST → انتشار پست (multipart/form-data با عکس اختیاری) — روابط عمومی و ادمین
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSession()
    const scope = req.nextUrl.searchParams.get('scope')
    const labels = await getRoleLabelMap()

    if (scope === 'manage') {
      const g = await requireAnyPanel('PR')
      if ('res' in g) return g.res
      const rows = await db.newsPost.findMany({
        orderBy: [{ createdAt: 'desc' }],
        include: {
          author: { select: { fullName: true } },
          _count: { select: { likes: true, comments: true } },
        },
        take: 200,
      })
      return ok(rows.map((n) => toDTO(n, false, labels)))
    }

    const now = new Date()
    const rows = await db.newsPost.findMany({
      where: {
        OR: [
          { targetRole: null },
          ...(session?.role ? [{ targetRole: session.role }] : []),
        ],
        AND: [{ OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] }],
      },
      orderBy: [{ isUrgent: 'desc' }, { createdAt: 'desc' }],
      include: {
        author: { select: { fullName: true } },
        _count: { select: { likes: true, comments: true } },
        ...(session?.userId
          ? { likes: { where: { userId: session.userId }, select: { id: true } } }
          : {}),
      },
      take: 50,
    })
    return ok(rows.map((n) => toDTO(
      n,
      Array.isArray((n as { likes?: { id: string }[] }).likes) &&
        ((n as { likes?: { id: string }[] }).likes?.length ?? 0) > 0,
      labels,
    )))
  } catch (e) {
    return serverError(e)
  }
}

type PostRow = {
  id: string
  title: string
  body: string
  isUrgent: boolean
  expiresAt: Date | null
  targetRole: string | null
  imageName: string | null
  author: { fullName: string }
  createdAt: Date
  _count: { likes: number; comments: number }
}

function toDTO(n: PostRow, likedByMe: boolean, labels: Record<string, string>) {
  return {
    id: n.id,
    title: n.title,
    body: n.body,
    isUrgent: n.isUrgent,
    expiresAt: n.expiresAt?.toISOString() ?? null,
    targetRole: n.targetRole,
    targetRoleLabel: n.targetRole ? (labels[n.targetRole] ?? n.targetRole) : null,
    authorName: n.author.fullName,
    createdAt: n.createdAt.toISOString(),
    hasImage: !!n.imageName,
    likeCount: n._count.likes,
    commentCount: n._count.comments,
    likedByMe,
  }
}

/** انتشار اطلاعیه با عکس — روابط عمومی و ادمین (multipart/form-data) */
export async function POST(req: Request) {
  const g = await requireAnyPanel('PR')
  if ('res' in g) return g.res
  try {
    const form = await req.formData().catch(() => null)
    if (!form) return fail('داده‌ها ناقص است', 422)

    const title = String(form.get('title') ?? '').trim()
    const body = String(form.get('body') ?? '').trim()
    const isUrgent = String(form.get('isUrgent') ?? '') === 'true'
    const expiresInDays = Number(form.get('expiresInDays') ?? '0')
    const targetRoleRaw = String(form.get('targetRole') ?? '')
    const targetRole = targetRoleRaw && targetRoleRaw !== 'ALL' ? targetRoleRaw : null
    if (targetRole && !(await isValidRole(targetRole))) {
      return fail('نقش هدف معتبر نیست', 422)
    }

    if (title.length < 3 || title.length > 150) return fail('عنوان باید ۳ تا ۱۵۰ نویسه باشد', 422)
    if (body.length < 3 || body.length > 5000) return fail('متن اطلاعیه را کامل بنویسید', 422)

    // عکس اختیاری
    let imageName: string | undefined
    let imageMime: string | undefined
    let imageData: Buffer | undefined
    const file = form.get('image')
    if (file instanceof File && file.size > 0) {
      if (file.size > MAX_IMAGE) return fail('حجم عکس بیشتر از ۵ مگابایت است', 413)
      const mime = file.type || 'application/octet-stream'
      if (!mime.startsWith('image/')) return fail('فقط فایل عکس (JPG/PNG/...) مجاز است', 422)
      imageName = file.name || 'image'
      imageMime = mime
      imageData = Buffer.from(await file.arrayBuffer())
    }

    const expiresAt = expiresInDays > 0
      ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
      : null

    const post = await db.newsPost.create({
      data: {
        title,
        body,
        isUrgent,
        expiresAt,
        targetRole,
        authorId: g.session.userId,
        ...(imageData ? { imageName, imageMime, imageData } : {}),
      },
    })
    return ok({ id: post.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
