import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, zodMessage, serverError } from '@/lib/api-helpers'
import { getRoleDefs, addCustomRole } from '@/lib/roles'
import { roleLabelSchema } from '@/lib/schemas'

/**
 * مدیریت نقش‌ها:
 *  GET  → فهرست نقش‌ها (پایه + سفارشی) + تعداد کاربران هر نقش — همهٔ واردشده‌ها
 *  POST → افزودن نقش سفارشی { label } — فقط ادمین
 */
export async function GET() {
  const g = await requireSession()
  if ('res' in g) return g.res
  try {
    const [defs, counts] = await Promise.all([
      getRoleDefs(),
      db.user.groupBy({ by: ['role'], _count: { _all: true } }),
    ])
    const countMap: Record<string, number> = {}
    for (const c of counts) countMap[c.role] = c._count._all
    return ok({
      roles: defs.map((d) => ({ ...d, userCount: countMap[d.key] ?? 0 })),
    })
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(req: NextRequest) {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const parsed = roleLabelSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const role = await addCustomRole(parsed.data.label)
    return ok(role, 201)
  } catch (e) {
    return serverError(e)
  }
}
