import type { NextRequest } from 'next/server'
import { ok, fail, requireSession, zodMessage, serverError } from '@/lib/api-helpers'
import { renameRole, deleteRole } from '@/lib/roles'
import { roleLabelSchema } from '@/lib/schemas'

/**
 * ویرایش/حذف یک نقش — فقط ادمین:
 *  PATCH  → تغییر نام نمایشی { label } (کلید ثابت می‌ماند)
 *  DELETE → حذف نقش سفارشی (فقط بدون کاربر؛ نقش‌های پایه حذف نمی‌شوند)
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = roleLabelSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    await renameRole(id, parsed.data.label)
    return ok({ saved: true })
  } catch (e) {
    if (e instanceof Error && e.message === 'نقش پیدا نشد') {
      return fail('نقش پیدا نشد', 404)
    }
    return serverError(e)
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const r = await deleteRole(id)
    if (!r.ok) return fail(r.error, 409)
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
}
