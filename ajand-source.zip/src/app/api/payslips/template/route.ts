import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'
import { jalaliMonthNow } from '@/lib/persian'

/**
 * قالب نمونهٔ اکسل فیش حقوقی — منابع انسانی و ادمین
 * ستون‌های آیتم از همان «آیتم‌های فیش» تعریف‌شده ساخته می‌شود.
 */
export async function GET() {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const items = await db.payItem.findMany({
      where: { isActive: true },
      orderBy: [{ kind: 'asc' }, { order: 'asc' }],
    })
    const benefits = items.filter((i) => i.kind === 'BENEFIT')
    const deductions = items.filter((i) => i.kind === 'DEDUCTION')

    const [y, m] = jalaliMonthNow().split('/')
    const example: Record<string, string | number> = {
      'نام کاربری': 'a.karimi',
      'نام و نام خانوادگی (اختیاری)': 'علی کریمی',
      سال: Number(y),
      ماه: Number(m),
      'حقوق پایه': 32000000,
    }
    for (const b of benefits) example[b.title] = 0
    for (const d of deductions) example[d.title] = 0

    return excelResponse([example], `قالب-فیش-حقوقی-${jalaliMonthNow().replace('/', '-')}.xlsx`, 'فیش حقوقی')
  } catch (e) {
    return serverError(e)
  }
}
