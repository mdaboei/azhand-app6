import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'
import { parseItems } from '@/lib/payslip'

/**
 * خروجی اکسل فیش‌ها — منابع انسانی، مدیریت و ادمین
 * ?period=1404/08 (اختیاری) — هر آیتم یک ستون می‌شود.
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('HR', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const period = req.nextUrl.searchParams.get('period')
    const rows = await db.payslip.findMany({
      where: period ? { period } : undefined,
      orderBy: [{ period: 'desc' }, { createdAt: 'desc' }],
      include: { user: { select: { fullName: true, username: true } } },
      take: 1000,
    })

    // همهٔ عنوان‌های آیتمی که در این فیش‌ها آمده (مزایا اول، بعد کسورات)
    const titles: string[] = []
    const parsedRows = rows.map((p) => {
      const items = parseItems(p.items)
      for (const it of items) if (!titles.includes(it.title)) titles.push(it.title)
      return { p, items }
    })
    const sortedTitles = [
      ...parsedRows.flatMap((r) => r.items).filter((i) => i.kind === 'BENEFIT').map((i) => i.title),
      ...parsedRows.flatMap((r) => r.items).filter((i) => i.kind === 'DEDUCTION').map((i) => i.title),
    ].filter((t, i, arr) => arr.indexOf(t) === i)

    const data = parsedRows.map(({ p, items }) => {
      const row: Record<string, string | number> = {
        'نام کاربری': p.user.username,
        'نام و نام خانوادگی': p.user.fullName,
        دوره: p.period,
        'حقوق پایه': p.baseSalary,
      }
      for (const t of sortedTitles) row[t] = 0
      for (const it of items) row[it.title] = it.amount
      row['خالص پرداختی'] = p.netPay
      return row
    })

    const fname = period ? `فیش-حقوقی-${period.replace('/', '-')}.xlsx` : 'فیش-حقوقی-همه-دوره‌ها.xlsx'
    return excelResponse(data, fname, 'فیش حقوقی')
  } catch (e) {
    return serverError(e)
  }
}
