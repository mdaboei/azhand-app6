import type { NextRequest } from 'next/server'
import * as XLSX from 'xlsx'
import { db } from '@/lib/db'
import {ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { netOf, normalizeTitle } from '@/lib/payslip'
import { toEnDigits, guessKind } from '@/lib/excel'
import type { PayslipItem } from '@/lib/schemas'

/**
 * بارگذاری اکسل فیش حقوقی — منابع انسانی و ادمین
 *
 * قالب فایل (هدرها در ردیف اول):
 *   نام کاربری | سال | ماه | حقوق پایه | <آیتم‌های مزایا...> | <آیتم‌های کسورات...>
 *
 * ستون‌های ثابت با عنوان «نام کاربری»، «سال»، «ماه» و «حقوق پایه» شناخته می‌شوند
 * (کد پرسنلی هم قبول است). هر ستون دیگر یک آیتم فیش است؛ اگر قبلاً در
 * «آیتم‌های فیش» تعریف شده از نوع همان استفاده می‌شود، وگرنه خودکار ساخته می‌شود
 * (عنوان‌های حاوی کسر/کسور/مالیات/سهم → کسورات، بقیه → مزایا).
 *
 * برای هر کارمند در هر دوره حداکثر یک فیش: اگر قبلاً فیش باشد، به‌روزرسانی می‌شود.
 */

const MAX_ROWS = 500

interface RowProblem {
  row: number
  username: string
  reason: string
}

export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const form = await req.formData().catch(() => null)
    const file = form?.get('file')
    if (!file || !(file instanceof File)) return fail('فایل اکسل را انتخاب کنید', 422)
    if (file.size > 5 * 1024 * 1024) return fail('حجم فایل باید کمتر از ۵ مگابایت باشد', 413)

    let rows: unknown[][]
    try {
      const buf = Buffer.from(await file.arrayBuffer())
      const wb = XLSX.read(buf, { type: 'buffer' })
      const sheet = wb.Sheets[wb.SheetNames[0]]
      if (!sheet) return fail('فایل اکسل هیچ شیتی ندارد', 422)
      rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: '', blankrows: false })
    } catch {
      return fail('خواندن فایل اکسل ناموفق بود — فایل معتبر xlsx/xls بدهید', 422)
    }
    if (rows.length < 2) return fail('فایل خالی است — بعد از هدر، حداقل یک ردیف لازم است', 422)

    // ── پیدا کردن ردیف هدر (اولین ردیفی که «نام کاربری» یا «کد پرسنلی» دارد)
    let headerRow = -1
    for (let i = 0; i < Math.min(rows.length, 5); i++) {
      const cells = (rows[i] ?? []).map((c) => normalizeTitle(String(c ?? '')))
      if (cells.some((c) => /نام کاربری|کد پرسنلی|username/i.test(c))) {
        headerRow = i
        break
      }
    }
    if (headerRow === -1) {
      return fail('ستون «نام کاربری» در فایل پیدا نشد — از قالب نمونه استفاده کنید', 422)
    }

    const headers = (rows[headerRow] ?? []).map((c) => normalizeTitle(String(c ?? '')))
    const findCol = (patterns: RegExp[]) =>
      headers.findIndex((h) => h.length > 0 && patterns.some((p) => p.test(h)))

    const usernameIdx = findCol([/نام کاربری/, /کد پرسنلی/, /username/i])
    const nameIdx = findCol([/نام و نام خانوادگی/, /نام کارمند/, /^نام$/, /full ?name/i])
    const yearIdx = findCol([/^سال$/])
    const monthIdx = findCol([/^ماه$/])
    const baseIdx = findCol([/حقوق پایه/, /^حقوق$/])
    if (usernameIdx === -1 || yearIdx === -1 || monthIdx === -1) {
      return fail('ستون‌های «نام کاربری»، «سال» و «ماه» در فایل لازم است', 422)
    }

    // بقیهٔ ستون‌ها = آیتم‌های فیش
    const FIXED = new Set([
      usernameIdx,
      yearIdx,
      monthIdx,
      ...(baseIdx !== -1 ? [baseIdx] : []),
      ...(nameIdx !== -1 ? [nameIdx] : []),
    ])
    const itemCols: { idx: number; title: string }[] = []
    headers.forEach((h, idx) => {
      if (h && !FIXED.has(idx)) itemCols.push({ idx, title: h })
    })

    // ── تطبیق/ساخت آیتم‌ها
    const existingItems = await db.payItem.findMany()
    const byTitle = new Map(existingItems.map((it) => [normalizeTitle(it.title), it]))
    const createdItems: string[] = []

    async function resolveItem(title: string): Promise<{ title: string; kind: string } | null> {
      const key = normalizeTitle(title)
      if (!key) return null
      const found = byTitle.get(key)
      if (found) return { title: found.title, kind: found.kind }
      const kind = guessKind(title)
      const created = await db.payItem
        .create({ data: { title: title.slice(0, 80), kind, order: 99, isActive: true } })
        .catch(() => null)
      if (!created) {
        // همزمانی؛ دوباره بخوان
        const again = await db.payItem.findUnique({ where: { title: title.slice(0, 80) } })
        if (!again) return null
        byTitle.set(key, again)
        return { title: again.title, kind: again.kind }
      }
      byTitle.set(key, created)
      createdItems.push(created.title)
      return { title: created.title, kind: created.kind }
    }

    const resolvedCols: ({ idx: number; title: string; kind: string } | null)[] = []
    for (const col of itemCols) {
      const resolved = await resolveItem(col.title)
      resolvedCols.push(resolved ? { ...col, kind: resolved.kind } : null)
    }

    // ── کاربران
    const users = await db.user.findMany({ select: { id: true, username: true, role: true, isActive: true } })
    const byUsername = new Map(users.map((u) => [u.username.toLowerCase(), u]))

    // ── ردیف‌ها
    const meId = g.session.userId
    let imported = 0
    let updated = 0
    const problems: RowProblem[] = []

    const dataRows = rows.slice(headerRow + 1)
    for (let i = 0; i < dataRows.length; i++) {
      if (imported + updated >= MAX_ROWS) {
        problems.push({ row: i + headerRow + 2, username: '-', reason: `بیش از ${MAX_ROWS} ردیف پردازش نشد` })
        break
      }
      const raw = dataRows[i] ?? []
      const rowNo = i + headerRow + 2 // شماره ردیف در اکسل (۱-ایندکس + هدر)
      const username = toEnDigits(String(raw[usernameIdx] ?? '')).trim().toLowerCase()
      if (!username) continue // ردیف کاملاً خالی

      const user = byUsername.get(username)
      if (!user) {
        problems.push({ row: rowNo, username, reason: 'کاربری با این نام کاربری پیدا نشد' })
        continue
      }
      if (user.role !== 'EMPLOYEE') {
        problems.push({ row: rowNo, username, reason: 'این کاربر کارمند نیست' })
        continue
      }
      if (!user.isActive) {
        problems.push({ row: rowNo, username, reason: 'حساب کارمند غیرفعال است' })
        continue
      }

      const year = toEnDigits(String(raw[yearIdx] ?? '')).replace(/\D/g, '')
      const monthRaw = toEnDigits(String(raw[monthIdx] ?? '')).replace(/\D/g, '')
      if (!year || !monthRaw) {
        problems.push({ row: rowNo, username, reason: 'سال یا ماه خالی است' })
        continue
      }
      const month = monthRaw.length === 1 ? `0${monthRaw}` : monthRaw.slice(0, 2)
      const period = `${year}/${month}`
      if (!/^\d{4}\/\d{2}$/.test(period)) {
        problems.push({ row: rowNo, username, reason: `سال/ماه نامعتبر: ${period}` })
        continue
      }

      const baseNum = baseIdx !== -1 ? Number(toEnDigits(String(raw[baseIdx] ?? '0')).replace(/[^\d.-]/g, '')) : 0
      const baseSalary = Number.isFinite(baseNum) && baseNum > 0 ? baseNum : 0

      const items: PayslipItem[] = []
      for (const col of resolvedCols) {
        if (!col) continue
        const valStr = toEnDigits(String(raw[col.idx] ?? '')).replace(/[,،]/g, '')
        const num = Number(valStr.replace(/[^\d.-]/g, ''))
        if (!Number.isFinite(num) || num <= 0) continue
        items.push({ title: col.title, kind: col.kind as PayslipItem['kind'], amount: num })
      }

      const netPay = netOf(baseSalary, items)
      const existed = await db.payslip.findUnique({
        where: { userId_period: { userId: user.id, period } },
      })

      if (existed) {
        await db.payslip.update({
          where: { id: existed.id },
          data: { baseSalary, items, netPay, issuedById: meId },
        })
        updated++
      } else {
        await db.payslip.create({
          data: { userId: user.id, period, baseSalary, items, netPay, issuedById: meId },
        })
        imported++
      }
    }

    return ok({
      imported,
      updated,
      failed: problems.length,
      problems: problems.slice(0, 20),
      createdItems,
    })
  } catch (e) {
    return serverError(e)
  }
}
