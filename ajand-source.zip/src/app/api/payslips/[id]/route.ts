import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { payslipUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { netOf, parseItems } from '@/lib/payslip'

/** ویرایش فیش — منابع انسانی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = payslipUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.payslip.findUnique({ where: { id } })
    if (!exists) return fail('فیش پیدا نشد', 404)

    const base = input.baseSalary ?? exists.baseSalary
    const items = input.items !== undefined ? input.items : parseItems(exists.items)

    const slip = await db.payslip.update({
      where: { id },
      data: {
        ...(input.period !== undefined ? { period: input.period } : {}),
        ...(input.baseSalary !== undefined ? { baseSalary: input.baseSalary } : {}),
        ...(input.items !== undefined ? { items: input.items } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
        netPay: netOf(base, items),
      },
    })
    return ok({ id: slip.id, netPay: slip.netPay })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف فیش — منابع انسانی و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.payslip.findUnique({ where: { id } })
    if (!exists) return fail('فیش پیدا نشد', 404)
    await db.payslip.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
