import { hasUserPanelAccess } from '@/lib/permissions'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { payslipSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { netOf, parseItems } from '@/lib/payslip'

/**
 * لیست فیش‌ها (ساختار آیتمی: مزایا و کسورات قابل تعریف):
 *  - کارمند: فیش‌های خودش
 *  - منابع انسانی و ادمین: همه با فیلتر ?userId= و ?period=1404/08
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('HR', 'EMPLOYEE')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const userId = sp.get('userId')
    const period = sp.get('period')

    const where: Record<string, unknown> = {}
    // دارندگان بخش HR همه را می‌بینند؛ بقیه فقط دادهٔ خودشان
    const canSeeAll =
      g.session.role === 'ADMIN' ||
      (await hasUserPanelAccess(g.session.userId, g.session.role, 'HR'))
    if (!canSeeAll) where.userId = g.session.userId
    else if (userId) where.userId = userId
    if (period) where.period = period

    const rows = await db.payslip.findMany({
      where,
      orderBy: [{ period: 'desc' }, { createdAt: 'desc' }],
      include: {
        user: { select: { fullName: true } },
        issuer: { select: { fullName: true } },
      },
      take: 300,
    })
    return ok(
      rows.map((p) => ({
        id: p.id,
        userId: p.userId,
        userName: p.user.fullName,
        period: p.period,
        baseSalary: p.baseSalary,
        items: parseItems(p.items),
        netPay: p.netPay,
        note: p.note,
        issuedByName: p.issuer.fullName,
        createdAt: p.createdAt.toISOString(),
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** صدور فیش حقوقی — منابع انسانی و ادمین؛ خالص پرداختی سرور محاسبه می‌کند */
export async function POST(req: Request) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const parsed = payslipSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const target = await db.user.findUnique({ where: { id: input.userId } })
    if (!target || target.role !== 'EMPLOYEE') return fail('کارمند پیدا نشد', 422)

    const netPay = netOf(input.baseSalary, input.items)

    const slip = await db.payslip
      .create({
        data: {
          userId: input.userId,
          period: input.period,
          baseSalary: input.baseSalary,
          items: input.items,
          netPay,
          note: input.note || null,
          issuedById: g.session.userId,
        },
      })
      .catch((e: { code?: string }) => {
        if (e.code === 'P2002') return null
        throw e
      })
    if (!slip) return fail('برای این دوره قبلاً فیش صادر شده است', 409)

    return ok({ id: slip.id, netPay }, 201)
  } catch (e) {
    return serverError(e)
  }
}
