import type { NextRequest } from 'next/request'
import * as XLSX from 'xlsx'
import { db } from '@/lib/db'
import { ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { normalizeTitle } from '@/lib/payslip'
import { toEnDigits } from '@/lib/excel'

/**
 * ورود گروهی دریافت و پرداخت‌ها از اکسل — واحد مالی و ادمین
 *
 * قالب فایل (هدرها در ردیف اول):
 *   تاریخ | نوع | بابت | مبلغ (تومان) | حساب بانکی (اختیاری) | یادداشت (اختیاری)
 *
 *  - «نوع» شامل دریافت/وارده → RECEIVE و پرداخت/پرداخت‌شده → PAY.
 *  - «حساب بانکی» با نام یکی از حساب‌های ثبت‌شده تطبیق داده می‌شود؛
 *    اگر مطابقت نداشت تراکنش بدون حساب ثبت می‌شود (رد نمی‌شود).
 */

const MAX_ROWS = 500

interface RowProblem {
  row: number
  title: string
  reason: string
}

export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const form = await req.formData().catch(() => null)
    const file = form?.get('file')
    if (!file || !(file instanceof File)) return fail('فایل اکسل را انتخاب کنید', 422)
    if (file.size > 5 * 1024 * 1024) return fail('حجم فایل باید کمتر از ۵ مگابایت باشد', 413)

    let rows: unknown[][]
    try {
      const buf = Buffer.from(await file.arrayBuffer())
      const wb = XLSX.read(buf, { type: 'buffer' })
      const sheet = wb.Sheets[wb.SheetNames[0]]
      if (!sheet) return fail('فایل اکسل هیچ شیتی ندارد', 422)
      rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: '', blankrows: false })
    } catch {
      return fail('خواندن فایل اکسل ناموفق بود — فایل معتبر xlsx/xls بدهید', 422)
    }
    if (rows.length < 2) return fail('فایل خالی است — بعد از هدر، حداقل یک ردیف لازم است', 422)

    // ── ردیف هدر: اولین ردیفی که «تاریخ» و («نوع» یا «مبلغ») دارد
    let headerRow = -1
    for (let i = 0; i < Math.min(rows.length, 5); i++) {
      const cells = (rows[i] ?? []).map((c) => normalizeTitle(String(c ?? '')))
      if (cells.some((c) => /^تاریخ|date/i.test(c)) &&
          (cells.some((c) => /^نوع/.test(c)) || cells.some((c) => /مبلغ|amount/i.test(c)))) {
        headerRow = i
        break
      }
    }
    if (headerRow === -1) {
      return fail('ستون‌های «تاریخ»، «نوع» و «مبلغ» در فایل لازم است — از قالب نمونه استفاده کنید', 422)
    }

    const headers = (rows[headerRow] ?? []).map((c) => normalizeTitle(String(c ?? '')))
    const findCol = (...patterns: RegExp[]) =>
      headers.findIndex((h) => h.length > 0 && patterns.some((p) => p.test(h)))

    const dateIdx = findCol(/^تاریخ/, /date/i)
    const kindIdx = findCol(/^نوع/, /kind|type/i)
    const titleIdx = findCol(/بابت|شرح|عنوان/, /title|desc/i)
    const amountIdx = findCol(/مبلغ/, /amount/i)
    if (dateIdx === -1 || kindIdx === -1 || titleIdx === -1 || amountIdx === -1) {
      return fail('ستون‌های «تاریخ»، «نوع»، «بابت» و «مبلغ» در فایل لازم است', 422)
    }
    const bankIdx = findCol(/حساب بانکی|بانک/)
    const noteIdx = findCol(/یادداشت|توضیح/)

    // ── حساب‌های بانکی موجود (تطبیق با نام)
    const banks = await db.bankAccount.findMany({ select: { id: true, name: true } })
    const bankByName = new Map(banks.map((b) => [normalizeTitle(b.name), b]))

    const meId = g.session.userId
    let imported = 0
    const problems: RowProblem[] = []

    const dataRows = rows.slice(headerRow + 1)
    for (let i = 0; i < dataRows.length; i++) {
      if (imported >= MAX_ROWS) {
        problems.push({ row: i + headerRow + 2, title: '-', reason: `بیش از ${MAX_ROWS} ردیف پردازش نشد` })
        break
      }
      const raw = dataRows[i] ?? []
      const rowNo = i + headerRow + 2

      const cell = (idx: number) => {
        const v = String(raw[idx] ?? '').trim()
        return v.length > 0 ? v : null
      }

      if (!raw.some((c) => String(c ?? '').trim() !== '')) continue // ردیف خالی

      const title = cell(titleIdx) ?? ''
      if (title.length < 2) {
        problems.push({ row: rowNo, title, reason: 'ستون «بابت» را پر کنید' })
        continue
      }

      // نوع — دریافت یا پرداخت
      const kindRaw = cell(kindIdx) ?? ''
      const kindNorm = normalizeTitle(kindRaw)
      let kind: 'RECEIVE' | 'PAY' | null = null
      if (/دریافت|وارده|واریز|receive|in\b/i.test(kindNorm)) kind = 'RECEIVE'
      else if (/پرداخت|پرد|خروج|pay|out\b/i.test(kindNorm)) kind = 'PAY'
      if (!kind) {
        problems.push({ row: rowNo, title, reason: `نوع نامعتبر است («${kindRaw}») — دریافت یا پرداخت بنویسید` })
        continue
      }

      // تاریخ شمسی — با اسلش یا پیوسته مثل 14050816
      const dateRaw = cell(dateIdx) ?? ''
      const cleaned = toEnDigits(dateRaw).replace(/[^\d/]/g, '')
      let parts = cleaned.split('/').filter(Boolean)
      if (parts.length === 1 && parts[0].length === 8) {
        const d = parts[0]
        parts = [d.slice(0, 4), d.slice(4, 6), d.slice(6, 8)]
      }
      let date: string | null = null
      if (parts.length === 3) {
        date = `${parts[0]}/${parts[1].padStart(2, '0')}/${parts[2].padStart(2, '0')}`
      }
      if (!date || !/^\d{4}\/\d{2}\/\d{2}$/.test(date)) {
        problems.push({ row: rowNo, title, reason: `تاریخ نامعتبر است («${dateRaw}») — مثل 1405/08/15` })
        continue
      }

      // مبلغ
      const amountRaw = cell(amountIdx) ?? ''
      const amount = Number(toEnDigits(amountRaw).replace(/[,،\s]/g, '').replace(/[^\d.-]/g, ''))
      if (!Number.isFinite(amount) || amount <= 0) {
        problems.push({ row: rowNo, title, reason: `مبلغ نامعتبر است («${amountRaw}»)` })
        continue
      }

      // حساب بانکی — اگر مطابقت نداشت بدون حساب ثبت می‌شود
      let bankAccountId: string | null = null
      const bankRaw = bankIdx !== -1 ? cell(bankIdx) : null
      if (bankRaw) {
        bankAccountId = bankByName.get(normalizeTitle(bankRaw))?.id ?? null
      }

      await db.transaction.create({
        data: {
          kind,
          amount,
          date,
          title: title.slice(0, 150),
          bankAccountId,
          note: (noteIdx !== -1 ? cell(noteIdx) : null)?.slice(0, 300) || null,
          createdById: meId,
        },
      })
      imported++
    }

    return ok({
      imported,
      failed: problems.length,
      problems: problems.slice(0, 20),
    })
  } catch (e) {
    return serverError(e)
  }
}
