import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'

/** خروجی اکسل تراکنش‌ها — مالی، مدیریت و ادمین */
export async function GET() {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const txs = await db.transaction.findMany({
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
      include: { bankAccount: { select: { name: true } } },
      take: 1000,
    })
    const data = txs.map((t) => ({
      نوع: t.kind === 'RECEIVE' ? 'دریافت' : 'پرداخت',
      'مبلغ (تومان)': t.amount,
      تاریخ: t.date,
      بابت: t.title,
      'بانک/حساب': t.bankAccount?.name ?? '',
      یادداشت: t.note ?? '',
    }))
    return excelResponse(data, 'تراکنش‌ها-مالی.xlsx', 'تراکنش‌ها')
  } catch (e) {
    return serverError(e)
  }
}
