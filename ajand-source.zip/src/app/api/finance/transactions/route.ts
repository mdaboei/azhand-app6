import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { transactionSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { padJalali } from '@/lib/persian'
import type { TransactionDTO, TransactionKind } from '@/lib/types'

/**
 * لیست تراکنش‌ها — واحد مالی، مدیریت و ادمین (فقط دیدن)
 * فیلترها: ?kind=RECEIVE|PAY ، ?month=1405/08 ، ?bankAccountId=
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const kind = sp.get('kind')
    const month = sp.get('month')
    const bankAccountId = sp.get('bankAccountId')

    const where: Record<string, unknown> = {}
    if (kind === 'RECEIVE' || kind === 'PAY') where.kind = kind
    if (month?.trim()) where.date = { startsWith: padJalali(month.trim()).slice(0, 7) }
    if (bankAccountId) where.bankAccountId = bankAccountId

    const rows = await db.transaction.findMany({
      where,
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
      include: { bankAccount: { select: { name: true } } },
      take: 300,
    })

    // createdById رابطه‌ای با کاربر ندارد → نام ثبت‌کننده با یک کوئری جدا
    const creatorIds = Array.from(new Set(rows.map((r) => r.createdById)))
    const creators = creatorIds.length
      ? await db.user.findMany({ where: { id: { in: creatorIds } }, select: { id: true, fullName: true } })
      : []
    const nameOf = new Map(creators.map((c) => [c.id, c.fullName]))

    const data: TransactionDTO[] = rows.map((t) => ({
      id: t.id,
      kind: t.kind as TransactionKind,
      amount: t.amount,
      date: t.date,
      title: t.title,
      bankAccountId: t.bankAccountId,
      bankAccountName: t.bankAccount?.name ?? null,
      note: t.note,
      createdByName: nameOf.get(t.createdById) ?? '—',
      createdAt: t.createdAt.toISOString(),
    }))
    return ok(data)
  } catch (e) {
    return serverError(e)
  }
}

/** ثبت تراکنش دریافت/پرداخت — واحد مالی و ادمین */
export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const parsed = transactionSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    if (input.bankAccountId) {
      const bank = await db.bankAccount.findUnique({ where: { id: input.bankAccountId } })
      if (!bank) return fail('حساب بانکی انتخاب‌شده پیدا نشد', 422)
    }

    const tx = await db.transaction.create({
      data: {
        kind: input.kind,
        amount: input.amount,
        date: input.date,
        title: input.title,
        bankAccountId: input.bankAccountId || null,
        note: input.note || null,
        createdById: g.session.userId,
      },
    })
    return ok({ id: tx.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
