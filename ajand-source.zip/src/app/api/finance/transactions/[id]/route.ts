import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { transactionUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش تراکنش — واحد مالی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = transactionUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.transaction.findUnique({ where: { id } })
    if (!exists) return fail('تراکنش پیدا نشد', 404)

    if (input.bankAccountId) {
      const bank = await db.bankAccount.findUnique({ where: { id: input.bankAccountId } })
      if (!bank) return fail('حساب بانکی انتخاب‌شده پیدا نشد', 422)
    }

    await db.transaction.update({
      where: { id },
      data: {
        ...(input.kind !== undefined ? { kind: input.kind } : {}),
        ...(input.amount !== undefined ? { amount: input.amount } : {}),
        ...(input.date !== undefined ? { date: input.date } : {}),
        ...(input.title !== undefined ? { title: input.title } : {}),
        ...(input.bankAccountId !== undefined ? { bankAccountId: input.bankAccountId || null } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })
    return ok({ id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف تراکنش — واحد مالی و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.transaction.findUnique({ where: { id } })
    if (!exists) return fail('تراکنش پیدا نشد', 404)

    await db.transaction.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
