import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import { requireAnyPanel, serverError } from '@/lib/api-helpers'
import { jalaliToday } from '@/lib/persian'

/**
 * قالب نمونهٔ اکسل ورود دریافت و پرداخت — واحد مالی و ادمین
 * ستون‌ها: تاریخ | نوع | بابت | مبلغ (تومان) | حساب بانکی (اختیاری) | یادداشت (اختیاری)
 */
export async function GET() {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const today = jalaliToday()
    const rows = [
      {
        'تاریخ': today,
        'نوع': 'دریافت',
        'بابت': 'دریافت صورت‌وضعیت پروژه',
        'مبلغ (تومان)': 150000000,
        'حساب بانکی (اختیاری)': 'بانک ملت — شعبه مرکزی',
        'یادداشت (اختیاری)': '',
      },
      {
        'تاریخ': today,
        'نوع': 'پرداخت',
        'بابت': 'خرید قطعات یدکی',
        'مبلغ (تومان)': 25000000,
        'حساب بانکی (اختیاری)': '',
        'یادداشت (اختیاری)': 'پرداخت نقدی',
      },
    ]
    return excelResponse(rows, 'قالب-دریافت-پرداخت.xlsx', 'تراکنش‌ها')
  } catch (e) {
    return serverError(e)
  }
}
