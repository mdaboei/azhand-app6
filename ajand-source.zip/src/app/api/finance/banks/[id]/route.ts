import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { bankAccountUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش حساب بانکی — واحد مالی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = bankAccountUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.bankAccount.findUnique({ where: { id } })
    if (!exists) return fail('حساب بانکی پیدا نشد', 404)

    const acc = await db.bankAccount.update({
      where: { id },
      data: {
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.accountNumber !== undefined ? { accountNumber: input.accountNumber || null } : {}),
        ...(input.balance !== undefined ? { balance: input.balance } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })
    return ok({ id: acc.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف حساب بانکی — اگر تراکنشی به آن وصل باشد اجازه حذف نیست */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.bankAccount.findUnique({ where: { id } })
    if (!exists) return fail('حساب بانکی پیدا نشد', 404)

    const used = await db.transaction.count({ where: { bankAccountId: id } })
    if (used > 0) return fail('اول تراکنش‌های این حساب را حذف کنید', 409)

    await db.bankAccount.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
