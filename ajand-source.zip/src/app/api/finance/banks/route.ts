import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { bankAccountSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import type { BankAccountDTO } from '@/lib/types'

/** لیست همه حساب‌های بانکی — واحد مالی، مدیریت و ادمین (فقط دیدن) */
export async function GET() {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const rows = await db.bankAccount.findMany({ orderBy: { createdAt: 'asc' } })
    const data: BankAccountDTO[] = rows.map((b) => ({
      id: b.id,
      name: b.name,
      accountNumber: b.accountNumber,
      balance: b.balance,
      note: b.note,
    }))
    return ok(data)
  } catch (e) {
    return serverError(e)
  }
}

/** ثبت حساب بانکی جدید — واحد مالی و ادمین */
export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const parsed = bankAccountSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const acc = await db.bankAccount.create({
      data: {
        name: input.name,
        accountNumber: input.accountNumber || null,
        balance: input.balance ?? 0,
        note: input.note || null,
      },
    })
    return ok({ id: acc.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
