import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'

/** خروجی اکسل بانک‌ها و حساب‌ها — مالی، مدیریت و ادمین */
export async function GET() {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const banks = await db.bankAccount.findMany({
      orderBy: { createdAt: 'asc' },
      include: { _count: { select: { transactions: true } } },
    })
    const data = banks.map((b) => ({
      'نام بانک/حساب': b.name,
      'شماره حساب/کارت': b.accountNumber ?? '',
      'موجودی (تومان)': b.balance,
      'تعداد تراکنش‌ها': b._count.transactions,
      یادداشت: b.note ?? '',
    }))
    return excelResponse(data, 'بانک-ها-و-حساب-ها.xlsx', 'بانک‌ها')
  } catch (e) {
    return serverError(e)
  }
}
