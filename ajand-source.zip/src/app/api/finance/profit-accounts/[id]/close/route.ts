import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { profitCloseSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { cmpJalali, isValidJalali, rebuildProfitPeriods, todayJalali } from '@/lib/profit-engine'
import { addProfitLog } from '@/lib/profit-service'

/** بستن حساب (تسویه) — دورهٔ ناقص آخر طبق قاعدهٔ حساب قطعی می‌شود */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = profitCloseSchema.safeParse((await req.json().catch(() => null)) ?? {})
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const today = todayJalali()
    const date = parsed.data.date || today

    const acc = await db.profitAccount.findUnique({ where: { id } })
    if (!acc) return fail('حساب پیدا نشد', 404)
    if (acc.status === 'CLOSED') return fail('این حساب قبلاً بسته شده است', 422)

    if (!isValidJalali(date)) return fail('تاریخ بستن نامعتبر است', 422)
    if (cmpJalali(date, today) > 0) return fail('تاریخ بستن نمی‌تواند در آینده باشد', 422)
    if (cmpJalali(date, acc.startDate) < 0) return fail('تاریخ بستن نمی‌تواند قبل از تاریخ شروع باشد', 422)

    const lastPay = await db.profitPayment.findFirst({
      where: { accountId: id },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
    })
    if (lastPay && cmpJalali(date, lastPay.date) < 0) {
      return fail(`تاریخ بستن نمی‌تواند قبل از آخرین پرداخت (${lastPay.date}) باشد`, 422)
    }

    await db.profitAccount.update({ where: { id }, data: { status: 'CLOSED', closedAt: date } })
    await rebuildProfitPeriods(id)
    await addProfitLog(id, 'CLOSE', `حساب در تاریخ ${date} بسته شد`, g.session.userId)
    return ok({ ok: true, closedAt: date })
  } catch (e) {
    return serverError(e)
  }
}
