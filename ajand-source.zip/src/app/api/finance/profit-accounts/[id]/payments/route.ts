import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { profitPaymentSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import {
  balancesOf,
  cmpJalali,
  isValidJalali,
  rebuildProfitPeriods,
  todayJalali,
  type PayType,
  type PaymentCore,
} from '@/lib/profit-engine'
import { accountCoreOf, addProfitLog } from '@/lib/profit-service'
import { faNum } from '@/lib/persian'

/**
 * ثبت پرداخت جدید — سود / اصل / ترکیبی.
 * مانده‌ها لحظه‌ای محاسبه و پرداخت بیش از مانده رد می‌شود.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = profitPaymentSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data
    const today = todayJalali()

    const acc = await db.profitAccount.findUnique({ where: { id } })
    if (!acc) return fail('حساب پیدا نشد', 404)
    if (acc.status === 'CLOSED') {
      return fail('این حساب بسته شده است و ثبت پرداخت جدید در آن ممکن نیست', 422)
    }

    // اعتبارسنجی تاریخ
    if (!isValidJalali(input.date)) return fail('تاریخ پرداخت نامعتبر است', 422)
    if (cmpJalali(input.date, acc.startDate) < 0) {
      return fail('تاریخ پرداخت نمی‌تواند قبل از تاریخ شروع حساب باشد', 422)
    }
    if (cmpJalali(input.date, today) > 0) {
      return fail('تاریخ پرداخت نمی‌تواند در آینده باشد', 422)
    }

    // تفکیک بخش سود و اصل
    const payType = input.payType as PayType
    let interestPart = 0
    let principalPart = 0
    if (payType === 'INTEREST') {
      interestPart = input.amount
    } else if (payType === 'PRINCIPAL') {
      principalPart = input.amount
    } else {
      const ip = input.interestPart ?? 0
      if (ip <= 0 || ip >= input.amount) {
        return fail('در پرداخت ترکیبی، «بخش سود» باید بیشتر از صفر و کمتر از مبلغ کل باشد', 422)
      }
      interestPart = roundMoney(ip)
      principalPart = roundMoney(input.amount - ip)
    }

    // اعتبارسنجی مانده‌ها
    const payments = await db.profitPayment.findMany({ where: { accountId: id } })
    const cores: PaymentCore[] = payments.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart }))
    const stats = balancesOf(accountCoreOf(acc), cores, today)
    if (interestPart > 0 && interestPart > stats.unpaidInterest + 0.009) {
      return fail(
        `مبلغ سود واردشده (${faNum(interestPart)} تومان) بیشتر از سود پرداخت‌نشدهٔ این حساب است (حداکثر: ${faNum(stats.unpaidInterest)} تومان)`,
        422,
      )
    }
    if (principalPart > 0 && principalPart > stats.currentPrincipal + 0.009) {
      return fail(
        `مبلغ اصل واردشده (${faNum(principalPart)} تومان) بیشتر از ماندهٔ اصل سرمایه است (حداکثر: ${faNum(stats.currentPrincipal)} تومان)`,
        422,
      )
    }

    const pay = await db.profitPayment.create({
      data: {
        accountId: id,
        date: input.date,
        amount: input.amount,
        payType,
        interestPart,
        principalPart,
        note: input.note || null,
        createdById: g.session.userId,
      },
    })
    await rebuildProfitPeriods(id)
    await addProfitLog(
      id,
      'PAYMENT_ADD',
      `پرداخت ${faNum(pay.amount)} تومان در تاریخ ${pay.date} (${payTypeLabel(payType)}) ثبت شد`,
      g.session.userId,
    )
    return ok({ id: pay.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}

function roundMoney(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100
}

function payTypeLabel(t: string): string {
  return t === 'INTEREST' ? 'بابت سود' : t === 'PRINCIPAL' ? 'بابت اصل سرمایه' : 'ترکیبی (اصل و سود)'
}
