import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { profitPaymentUpdateSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import {
  balancesOf,
  cmpJalali,
  isValidJalali,
  rebuildProfitPeriods,
  round2,
  todayJalali,
  type PayType,
  type PaymentCore,
} from '@/lib/profit-engine'
import { accountCoreOf, addProfitLog } from '@/lib/profit-service'
import { faNum } from '@/lib/persian'

/** ویرایش پرداخت — پس از اصلاح، همهٔ محاسبات از نو انجام می‌شود */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string; paymentId: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id, paymentId } = await params
    const parsed = profitPaymentUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data
    const today = todayJalali()

    const acc = await db.profitAccount.findUnique({ where: { id } })
    if (!acc) return fail('حساب پیدا نشد', 404)
    const old = await db.profitPayment.findUnique({ where: { id: paymentId } })
    if (!old || old.accountId !== id) return fail('پرداخت پیدا نشد', 404)

    // مقدارهای نهایی پس از ادغام تغییرات
    const payType = (input.payType ?? old.payType) as PayType
    const date = input.date ?? old.date
    const amount = input.amount ?? old.amount
    const note = input.note !== undefined ? (input.note || null) : old.note

    if (!isValidJalali(date)) return fail('تاریخ پرداخت نامعتبر است', 422)
    if (cmpJalali(date, acc.startDate) < 0) {
      return fail('تاریخ پرداخت نمی‌تواند قبل از تاریخ شروع حساب باشد', 422)
    }
    if (cmpJalali(date, today) > 0) {
      return fail('تاریخ پرداخت نمی‌تواند در آینده باشد', 422)
    }

    // تفکیک بخش‌ها بر اساس نوع جدید
    let interestPart: number
    let principalPart: number
    if (payType === 'INTEREST') {
      interestPart = amount
      principalPart = 0
    } else if (payType === 'PRINCIPAL') {
      interestPart = 0
      principalPart = amount
    } else {
      const ip = input.interestPart ?? (old.payType === 'MIXED' ? old.interestPart : 0)
      if (ip <= 0 || ip >= amount) {
        return fail('در پرداخت ترکیبی، «بخش سود» باید بیشتر از صفر و کمتر از مبلغ کل باشد', 422)
      }
      interestPart = round2(ip)
      principalPart = round2(amount - ip)
    }

    // اعتبارسنجی مانده‌ها بدون خودِ این پرداخت (پس ماندهٔ قابل قبول = مانده + بخش قبلی)
    const others = await db.profitPayment.findMany({ where: { accountId: id, NOT: { id: paymentId } } })
    const cores: PaymentCore[] = others.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart }))
    const stats = balancesOf(accountCoreOf(acc), cores, today)
    const interestHeadroom = stats.unpaidInterest + old.interestPart
    const principalHeadroom = stats.currentPrincipal + old.principalPart
    if (interestPart > interestHeadroom + 0.009) {
      return fail(
        `مبلغ سود واردشده (${faNum(interestPart)} تومان) بیشتر از سود قابل تسویه است (حداکثر: ${faNum(interestHeadroom)} تومان)`,
        422,
      )
    }
    if (principalPart > principalHeadroom + 0.009) {
      return fail(
        `مبلغ اصل واردشده (${faNum(principalPart)} تومان) بیشتر از ماندهٔ قابل بازپرداخت است (حداکثر: ${faNum(principalHeadroom)} تومان)`,
        422,
      )
    }

    await db.profitPayment.update({
      where: { id: paymentId },
      data: { date, amount, payType, interestPart, principalPart, note },
    })
    await rebuildProfitPeriods(id)
    await addProfitLog(
      id,
      'PAYMENT_EDIT',
      `پرداخت ${faNum(old.amount)} تومان تاریخ ${old.date} به مبلغ ${faNum(amount)} تومان تاریخ ${date} اصلاح شد؛ محاسبات از نو انجام شد`,
      g.session.userId,
    )
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف پرداخت — محاسبات پس از حذف از نو انجام می‌شود */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string; paymentId: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id, paymentId } = await params
    const old = await db.profitPayment.findUnique({ where: { id: paymentId } })
    if (!old || old.accountId !== id) return fail('پرداخت پیدا نشد', 404)

    await db.profitPayment.delete({ where: { id: paymentId } })
    await rebuildProfitPeriods(id)
    await addProfitLog(
      id,
      'PAYMENT_DELETE',
      `پرداخت ${faNum(old.amount)} تومان تاریخ ${old.date} حذف شد؛ محاسبات از نو انجام شد`,
      g.session.userId,
    )
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
