import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { rebuildProfitPeriods } from '@/lib/profit-engine'
import { addProfitLog } from '@/lib/profit-service'

/** بازگشایی حساب بسته‌شده — دورهٔ بریده‌شدهٔ آخر حذف و محاسبه ادامه می‌یابد */
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const acc = await db.profitAccount.findUnique({ where: { id } })
    if (!acc) return fail('حساب پیدا نشد', 404)
    if (acc.status !== 'CLOSED') return fail('این حساب باز است', 422)

    await db.profitAccount.update({ where: { id }, data: { status: 'ACTIVE', closedAt: null } })
    await rebuildProfitPeriods(id)
    await addProfitLog(id, 'REOPEN', 'حساب بازگشایی شد و محاسبهٔ سود ادامه یافت', g.session.userId)
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
