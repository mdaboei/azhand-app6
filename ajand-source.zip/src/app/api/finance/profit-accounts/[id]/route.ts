import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { profitAccountUpdateSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { isValidJalali, cmpJalali, rebuildProfitPeriods, round2 } from '@/lib/profit-engine'
import { accountCoreOf, addProfitLog, getProfitAccountDetail } from '@/lib/profit-service'
import { faNum } from '@/lib/persian'

/** جزئیات کامل حساب سوددار — مالی، مدیریت و ادمین */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const detail = await getProfitAccountDetail(id)
    if (!detail) return fail('حساب پیدا نشد', 404)
    return ok(detail)
  } catch (e) {
    return serverError(e)
  }
}

/** ویرایش مشخصات حساب — هر تغییر اثرگذار، دوره‌ها را از نو محاسبه می‌کند */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = profitAccountUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const acc = await db.profitAccount.findUnique({ where: { id } })
    if (!acc) return fail('حساب پیدا نشد', 404)

    // اعتبارسنجی‌های متقاطع
    const newStart = input.startDate ?? acc.startDate
    const newMaturity = input.maturityDate !== undefined ? (input.maturityDate || null) : acc.maturityDate
    if (newStart && !isValidJalali(newStart)) return fail('تاریخ شروع نامعتبر است', 422)
    if (newMaturity) {
      if (!isValidJalali(newMaturity)) return fail('تاریخ سررسید نامعتبر است', 422)
      if (cmpJalali(newMaturity, newStart) < 0) {
        return fail('تاریخ سررسید نمی‌تواند قبل از تاریخ شروع باشد', 422)
      }
    }
    if (input.principal !== undefined) {
      const paid = await db.profitPayment.aggregate({ where: { accountId: id }, _sum: { principalPart: true } })
      const paidPrincipal = paid._sum.principalPart ?? 0
      if (input.principal < paidPrincipal) {
        return fail(`اصل اولیه نمی‌تواند کمتر از مجموع اصل بازپرداخت‌شده (${faNum(paidPrincipal)} تومان) باشد`, 422)
      }
    }

    // کدام فیلدها بر محاسبات اثر دارند؟
    const material =
      input.principal !== undefined ||
      input.startDate !== undefined ||
      input.monthlyRate !== undefined ||
      input.calcMethod !== undefined ||
      input.partialRule !== undefined ||
      (input.maturityDate !== undefined && (input.maturityDate || null) !== acc.maturityDate)

    const changes: string[] = []
    if (input.personName !== undefined && input.personName !== acc.personName) changes.push('نام شخص')
    if (input.principal !== undefined && input.principal !== acc.principal) changes.push('اصل اولیه')
    if (input.startDate !== undefined && input.startDate !== acc.startDate) changes.push('تاریخ شروع')
    if (input.monthlyRate !== undefined && input.monthlyRate !== acc.monthlyRate) changes.push('نرخ سود')
    if (input.calcMethod !== undefined && input.calcMethod !== acc.calcMethod) changes.push('روش محاسبه')
    if (input.partialRule !== undefined && input.partialRule !== acc.partialRule) changes.push('قاعده ماه ناقص')
    if (input.maturityDate !== undefined && (input.maturityDate || null) !== acc.maturityDate) changes.push('تاریخ سررسید')
    if (input.contractNo !== undefined && (input.contractNo || null) !== acc.contractNo) changes.push('شماره قرارداد')

    await db.profitAccount.update({
      where: { id },
      data: {
        ...(input.personName !== undefined ? { personName: input.personName } : {}),
        ...(input.principal !== undefined ? { principal: input.principal } : {}),
        ...(input.startDate !== undefined ? { startDate: input.startDate } : {}),
        ...(input.monthlyRate !== undefined ? { monthlyRate: input.monthlyRate } : {}),
        ...(input.calcMethod !== undefined ? { calcMethod: input.calcMethod } : {}),
        ...(input.partialRule !== undefined ? { partialRule: input.partialRule } : {}),
        ...(input.maturityDate !== undefined ? { maturityDate: input.maturityDate || null } : {}),
        ...(input.contractNo !== undefined ? { contractNo: input.contractNo || null } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })

    if (material) {
      await rebuildProfitPeriods(id)
      await addProfitLog(id, 'RECALC', `مشخصات حساب تغییر کرد (${changes.join('، ')}) و همهٔ دوره‌ها از نو محاسبه شد`, g.session.userId)
    }
    if (changes.length > 0) {
      await addProfitLog(id, 'UPDATE', `ویرایش: ${changes.join('، ')}`, g.session.userId)
    }

    const detail = await getProfitAccountDetail(id)
    return ok(detail)
  } catch (e) {
    return serverError(e)
  }
}

/** حذف کامل حساب (دوره‌ها، پرداخت‌ها و تاریخچه همراه آن حذف می‌شود) */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const acc = await db.profitAccount.findUnique({ where: { id } })
    if (!acc) return fail('حساب پیدا نشد', 404)
    await db.profitAccount.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
