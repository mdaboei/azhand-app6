import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { profitAccountSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { isValidJalali, todayJalali, cmpJalali, syncProfitAccount } from '@/lib/profit-engine'
import { addProfitLog, listProfitAccountDTOs, mapAccountDTO } from '@/lib/profit-service'
import { faNum } from '@/lib/persian'

/** لیست همهٔ حساب‌های سوددار اشخاص با خلاصهٔ محاسباتی — مالی، مدیریت و ادمین */
export async function GET() {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const data = await listProfitAccountDTOs()
    return ok(data)
  } catch (e) {
    return serverError(e)
  }
}

/** ثبت حساب سوددار جدید — واحد مالی و ادمین */
export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('FINANCE')
  if ('res' in g) return g.res
  try {
    const parsed = profitAccountSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data
    const today = todayJalali()

    if (!isValidJalali(input.startDate)) {
      return fail('تاریخ شروع نامعتبر است', 422)
    }
    if (input.maturityDate) {
      if (!isValidJalali(input.maturityDate)) return fail('تاریخ سررسید نامعتبر است', 422)
      if (cmpJalali(input.maturityDate, input.startDate) < 0) {
        return fail('تاریخ سررسید نمی‌تواند قبل از تاریخ شروع باشد', 422)
      }
    }

    const acc = await db.profitAccount.create({
      data: {
        personName: input.personName,
        principal: input.principal,
        startDate: input.startDate,
        monthlyRate: input.monthlyRate,
        calcMethod: input.calcMethod,
        partialRule: input.partialRule,
        maturityDate: input.maturityDate || null,
        contractNo: input.contractNo || null,
        note: input.note || null,
        status: 'ACTIVE',
        createdById: g.session.userId,
      },
    })
    await addProfitLog(
      acc.id,
      'CREATE',
      `حساب برای «${acc.personName}» ایجاد شد — اصل ${faNum(acc.principal)} تومان، سود ${faNum(acc.monthlyRate)}٪ ماهانه، شروع ${acc.startDate}`,
      g.session.userId,
    )
    await syncProfitAccount(acc.id)
    const payments = await db.profitPayment.findMany({ where: { accountId: acc.id } })
    return ok(mapAccountDTO(acc, payments.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart }))), 201)
  } catch (e) {
    return serverError(e)
  }
}
