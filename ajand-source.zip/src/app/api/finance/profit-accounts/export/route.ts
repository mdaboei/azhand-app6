import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { excelResponse, type ExcelRow } from '@/lib/excel'
import { requireAnyPanel, serverError } from '@/lib/api-helpers'
import { computeStats, syncProfitAccount, todayJalali } from '@/lib/profit-engine'
import { accountCoreOf } from '@/lib/profit-service'
import {
  PROFIT_METHOD_LABELS,
  PROFIT_PAYTYPE_LABELS,
  PROFIT_RULE_LABELS,
  type ProfitCalcMethod,
  type ProfitPartialRule,
} from '@/lib/types'
import { padJalali } from '@/lib/persian'

/**
 * خروجی اکسل گزارش‌های حساب‌های سوددار:
 *  STATEMENT           — گزارش کامل حساب یک شخص (?id=)
 *  INTEREST_PAID       — سود پرداخت‌شده در بازهٔ زمانی (?from=&to=)
 *  INTEREST_UNPAID     — سود معوق و پرداخت‌نشده
 *  PRINCIPAL_REMAINING — اصل سرمایهٔ باقی‌مانده
 *  MATURITY_UPCOMING   — سررسیدهای پیش رو (?days= پیش‌فرض ۳۰)
 *  OVERALL             — گزارش کلی بدهی شرکت به اشخاص
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('FINANCE', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const type = sp.get('type') ?? 'OVERALL'

    if (type === 'STATEMENT') {
      const id = sp.get('id') ?? ''
      await syncProfitAccount(id)
      const acc = await db.profitAccount.findUnique({ where: { id } })
      if (!acc) return excelResponse([], 'gozaresh-hesab.xlsx')
      const paymentsRaw = await db.profitPayment.findMany({
        where: { accountId: id },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      })
      const stats = await statsOf(acc)
      const methodLabel = PROFIT_METHOD_LABELS[acc.calcMethod as ProfitCalcMethod] ?? acc.calcMethod
      const rows: ExcelRow[] = [
        {
          'نام شخص': acc.personName,
          'اصل اولیه (تومان)': acc.principal,
          'تاریخ شروع': acc.startDate,
          'سود ماهانه (٪)': acc.monthlyRate,
          'روش محاسبه': methodLabel,
          'قاعده ماه ناقص': PROFIT_RULE_LABELS[acc.partialRule as ProfitPartialRule] ?? acc.partialRule,
          'تاریخ سررسید': acc.maturityDate ?? '—',
          'شماره قرارداد': acc.contractNo ?? '—',
          'ماه‌های سپری‌شده': stats.monthsElapsed,
          'سود ایجادشده (تومان)': stats.accrued,
          'سود پرداخت‌شده (تومان)': stats.paidInterest,
          'سود پرداخت‌نشده (تومان)': stats.unpaidInterest,
          'اصل بازپرداخت‌شده (تومان)': stats.paidPrincipal,
          'مانده اصل سرمایه (تومان)': stats.currentPrincipal,
          'بدهی کل شرکت (تومان)': stats.totalDebt,
          'وضعیت': acc.status === 'ACTIVE' ? 'فعال' : `بسته (${acc.closedAt ?? ''})`,
        },
      ]
      for (const p of paymentsRaw) {
        rows.push({
          'نام شخص': `پرداخت — ${p.date}`,
          'تاریخ': p.date,
          'نوع': PROFIT_PAYTYPE_LABELS[p.payType as keyof typeof PROFIT_PAYTYPE_LABELS] ?? p.payType,
          'بخش سود (تومان)': p.interestPart,
          'بخش اصل (تومان)': p.principalPart,
          'مبلغ کل پرداخت (تومان)': p.amount,
          'توضیح': p.note ?? '',
        })
      }
      return excelResponse(rows, 'gozaresh-hesab.xlsx', 'گزارش حساب')
    }

    const accounts = await db.profitAccount.findMany({ orderBy: [{ status: 'asc' }, { createdAt: 'desc' }] })

    if (type === 'INTEREST_PAID') {
      const from = sp.get('from') ? padJalali(sp.get('from')!) : null
      const to = sp.get('to') ? padJalali(sp.get('to')!) : null
      const all = await db.profitPayment.findMany({
        where: { interestPart: { gt: 0 } },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
        include: { account: { select: { personName: true, contractNo: true } } },
      })
      const filtered = all.filter((p) => {
        const d = padJalali(p.date)
        if (from && d < from) return false
        if (to && d > to) return false
        return true
      })
      const rows: ExcelRow[] = filtered.map((p) => ({
        'تاریخ': p.date,
        'نام شخص': p.account.personName,
        'شماره قرارداد': p.account.contractNo ?? '—',
        'نوع پرداخت': PROFIT_PAYTYPE_LABELS[p.payType as keyof typeof PROFIT_PAYTYPE_LABELS] ?? p.payType,
        'سود پرداخت‌شده (تومان)': p.interestPart,
        'بخش اصل همان پرداخت (تومان)': p.principalPart,
        'مبلغ کل پرداخت (تومان)': p.amount,
        'توضیح': p.note ?? '',
      }))
      const total = filtered.reduce((s, p) => s + p.interestPart, 0)
      rows.push({ 'تاریخ': 'جمع کل', 'سود پرداخت‌شده (تومان)': Math.round(total * 100) / 100 })
      return excelResponse(rows, 'sood-pardakht-shode.xlsx', 'سود پرداخت‌شده')
    }

    if (type === 'INTEREST_UNPAID') {
      const rows: ExcelRow[] = []
      let total = 0
      for (const acc of accounts) {
        const stats = await statsOf(acc)
        if (stats.unpaidInterest <= 0) continue
        total += stats.unpaidInterest
        rows.push({
          'نام شخص': acc.personName,
          'روش محاسبه': PROFIT_METHOD_LABELS[acc.calcMethod as ProfitCalcMethod] ?? acc.calcMethod,
          'سود ایجادشده (تومان)': stats.accrued,
          'سود پرداخت‌شده (تومان)': stats.paidInterest,
          'سود پرداخت‌نشده (تومان)': stats.unpaidInterest,
          'ماه‌های سپری‌شده': stats.monthsElapsed,
          'وضعیت': acc.status === 'ACTIVE' ? 'فعال' : 'بسته',
        })
      }
      rows.push({ 'نام شخص': 'جمع کل', 'سود پرداخت‌نشده (تومان)': Math.round(total * 100) / 100 })
      return excelResponse(rows, 'sood-pardakht-nashode.xlsx', 'سود پرداخت‌نشده')
    }

    if (type === 'PRINCIPAL_REMAINING') {
      const rows: ExcelRow[] = []
      let total = 0
      for (const acc of accounts) {
        const stats = await statsOf(acc)
        if (stats.currentPrincipal <= 0) continue
        total += stats.currentPrincipal
        rows.push({
          'نام شخص': acc.personName,
          'اصل اولیه (تومان)': acc.principal,
          'تاریخ شروع': acc.startDate,
          'اصل بازپرداخت‌شده (تومان)': stats.paidPrincipal,
          'مانده اصل سرمایه (تومان)': stats.currentPrincipal,
          'ماه‌های سپری‌شده': stats.monthsElapsed,
          'وضعیت': acc.status === 'ACTIVE' ? 'فعال' : 'بسته',
        })
      }
      rows.push({ 'نام شخص': 'جمع کل', 'مانده اصل سرمایه (تومان)': Math.round(total * 100) / 100 })
      return excelResponse(rows, 'asl-bagi-mande.xlsx', 'اصل باقی‌مانده')
    }

    if (type === 'MATURITY_UPCOMING') {
      const days = Number(sp.get('days') ?? '30') || 30
      const items: { acc: (typeof accounts)[number]; daysLeft: number }[] = []
      for (const acc of accounts) {
        if (!acc.maturityDate) continue
        const stats = await statsOf(acc)
        items.push({ acc, daysLeft: stats.daysToMaturity ?? 0 })
      }
      items.sort((a, b) => a.daysLeft - b.daysLeft)
      const fullRows: ExcelRow[] = []
      for (const { acc, daysLeft } of items.filter((it) => it.daysLeft <= days)) {
        const stats = await statsOf(acc)
        fullRows.push({
          'نام شخص': acc.personName,
          'تاریخ سررسید': acc.maturityDate ?? '—',
          'روز تا سررسید': daysLeft < 0 ? `گذشته (${Math.abs(daysLeft)} روز)` : daysLeft,
          'وضعیت': daysLeft <= 0 ? 'رسیده به سررسید' : 'فعال',
          'مانده اصل (تومان)': stats.currentPrincipal,
          'سود پرداخت‌نشده (تومان)': stats.unpaidInterest,
          'بدهی کل (تومان)': stats.totalDebt,
        })
      }
      return excelResponse(fullRows, 'sorresid-ha.xlsx', 'سررسیدها')
    }

    // OVERALL — گزارش کلی بدهی شرکت به اشخاص
    const rows: ExcelRow[] = []
    let debtTotal = 0
    let principalTotal = 0
    for (const acc of accounts) {
      const stats = await statsOf(acc)
      debtTotal += stats.totalDebt
      principalTotal += stats.currentPrincipal
      rows.push({
        'نام شخص': acc.personName,
        'شماره قرارداد': acc.contractNo ?? '—',
        'اصل اولیه (تومان)': acc.principal,
        'تاریخ شروع': acc.startDate,
        'سود ماهانه (٪)': acc.monthlyRate,
        'روش محاسبه': PROFIT_METHOD_LABELS[acc.calcMethod as ProfitCalcMethod] ?? acc.calcMethod,
        'مانده اصل (تومان)': stats.currentPrincipal,
        'سود پرداخت‌نشده (تومان)': stats.unpaidInterest,
        'بدهی کل شرکت (تومان)': stats.totalDebt,
        'وضعیت': acc.status === 'ACTIVE' ? 'فعال' : `بسته (${acc.closedAt ?? ''})`,
      })
    }
    rows.push({
      'نام شخص': 'جمع کل',
      'مانده اصل (تومان)': Math.round(principalTotal * 100) / 100,
      'بدهی کل شرکت (تومان)': Math.round(debtTotal * 100) / 100,
    })
    return excelResponse(rows, 'gozaresh-koli-bedehi.xlsx', 'بدهی کلی')
  } catch (e) {
    return serverError(e)
  }
}

/** آمار محاسباتی یک حساب با خواندن پرداخت‌ها */
async function statsOf(acc: NonNullable<Awaited<ReturnType<typeof db.profitAccount.findFirst>>>) {
  const payments = await db.profitPayment.findMany({ where: { accountId: acc.id } })
  const today = todayJalali()
  const core = accountCoreOf(acc)
  const rows = (await import('@/lib/profit-engine')).computePeriods(core, payments.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart })), today)
  return computeStats(core, rows, payments.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart })), today)
}
