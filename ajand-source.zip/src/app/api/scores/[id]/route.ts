import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { scoreEntryUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش امتیاز — منابع انسانی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = scoreEntryUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.scoreEntry.findUnique({ where: { id } })
    if (!exists) return fail('امتیاز پیدا نشد', 404)

    const row = await db.scoreEntry.update({
      where: { id },
      data: {
        ...(input.period !== undefined ? { period: input.period } : {}),
        ...(input.score !== undefined ? { score: input.score } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })
    return ok({ id: row.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف امتیاز — منابع انسانی و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.scoreEntry.findUnique({ where: { id } })
    if (!exists) return fail('امتیاز پیدا نشد', 404)
    await db.scoreEntry.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
