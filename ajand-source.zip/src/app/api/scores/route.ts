import { hasUserPanelAccess } from '@/lib/permissions'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { scoreEntrySchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * لیست امتیازها:
 *  - کارمند: امتیازهای خودش
 *  - منابع انسانی و ادمین: همه با فیلتر ?userId= و ?period=
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('HR', 'EMPLOYEE')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const userId = sp.get('userId')
    const period = sp.get('period')

    const where: Record<string, unknown> = {}
    // دارندگان بخش HR همه را می‌بینند؛ بقیه فقط دادهٔ خودشان
    const canSeeAll =
      g.session.role === 'ADMIN' ||
      (await hasUserPanelAccess(g.session.userId, g.session.role, 'HR'))
    if (!canSeeAll) where.userId = g.session.userId
    else if (userId) where.userId = userId
    if (period) where.period = period

    const rows = await db.scoreEntry.findMany({
      where,
      orderBy: [{ period: 'desc' }, { createdAt: 'desc' }],
      include: { user: { select: { fullName: true } } },
      take: 300,
    })
    return ok(
      rows.map((s) => ({
        id: s.id,
        userId: s.userId,
        userName: s.user.fullName,
        period: s.period,
        score: s.score,
        note: s.note,
        createdAt: s.createdAt.toISOString(),
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** ثبت/به‌روزرسانی امتیاز — منابع انسانی و ادمین (برای هر دوره یک امتیاز) */
export async function POST(req: Request) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const parsed = scoreEntrySchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const target = await db.user.findUnique({ where: { id: input.userId } })
    if (!target || target.role !== 'EMPLOYEE') return fail('کارمند پیدا نشد', 422)

    const row = await db.scoreEntry.upsert({
      where: { userId_period: { userId: input.userId, period: input.period } },
      create: {
        userId: input.userId,
        period: input.period,
        score: input.score,
        note: input.note || null,
        createdById: g.session.userId,
      },
      update: {
        score: input.score,
        note: input.note || null,
      },
    })
    return ok({ id: row.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
