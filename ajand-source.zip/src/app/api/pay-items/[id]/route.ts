import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { payItemUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش آیتم فیش — منابع انسانی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = payItemUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.payItem.findUnique({ where: { id } })
    if (!exists) return fail('آیتم پیدا نشد', 404)

    const row = await db.payItem
      .update({ where: { id }, data: input })
      .catch((e: { code?: string }) => {
        if (e.code === 'P2002') return null
        throw e
      })
    if (!row) return fail('آیتمی با این عنوان قبلاً تعریف شده است', 409)

    return ok({ id: row.id })
  } catch (e) {
    return serverError(e)
  }
}

/**
 * حذف آیتم فیش — منابع انسانی و ادمین
 * سابقهٔ فیش‌ها خراب نمی‌شود، چون آیتم‌ها هنگام صدور به‌صورت اسنپ‌شات داخل فیش کپی می‌شوند.
 */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.payItem.findUnique({ where: { id } })
    if (!exists) return fail('آیتم پیدا نشد', 404)
    await db.payItem.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
