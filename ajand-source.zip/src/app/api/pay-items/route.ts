import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { payItemSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** لیست آیتم‌های فیش (مزایا و کسورات) — منابع انسانی و ادمین */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const onlyActive = req.nextUrl.searchParams.get('active') === '1'
    const rows = await db.payItem.findMany({
      where: onlyActive ? { isActive: true } : undefined,
      orderBy: [{ kind: 'asc' }, { order: 'asc' }, { title: 'asc' }],
    })
    return ok(rows)
  } catch (e) {
    return serverError(e)
  }
}

/** تعریف آیتم جدید — منابع انسانی و ادمین */
export async function POST(req: Request) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const parsed = payItemSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const row = await db.payItem
      .create({ data: input })
      .catch((e: { code?: string }) => {
        if (e.code === 'P2002') return null
        throw e
      })
    if (!row) return fail('آیتمی با این عنوان قبلاً تعریف شده است', 409)

    return ok({ id: row.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
