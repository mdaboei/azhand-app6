import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'
import { padJalali } from '@/lib/persian'

/**
 * خروجی اکسل کارکرد — منابع انسانی و ادمین
 * ?userId= و ?from=1404/08/01 و ?to=1404/08/30 (همگی اختیاری)
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const userId = sp.get('userId')
    const from = sp.get('from')
    const to = sp.get('to')

    const where: Record<string, unknown> = {}
    if (userId) where.userId = userId
    if (from && to) {
      where.date = { gte: padJalali(from), lte: padJalali(to) }
    } else if (from) {
      where.date = { gte: padJalali(from) }
    } else if (to) {
      where.date = { lte: padJalali(to) }
    }

    const logs = await db.workLog.findMany({
      where,
      orderBy: [{ date: 'desc' }],
      include: { user: { select: { fullName: true, username: true } } },
      take: 2000,
    })

    const data = logs.map((l) => ({
      'نام کاربری': l.user.username,
      'نام و نام خانوادگی': l.user.fullName,
      تاریخ: l.date,
      'ساعت کارکرد عادی': l.hours,
      'اضافه‌کاری (ساعت)': l.overtime,
      یادداشت: l.note ?? '',
    }))
    return excelResponse(data, 'کارکرد.xlsx', 'کارکرد')
  } catch (e) {
    return serverError(e)
  }
}
