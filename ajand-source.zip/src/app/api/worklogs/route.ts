import { hasUserPanelAccess } from '@/lib/permissions'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { workLogSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * لیست کارکرد:
 *  - کارمند: فقط خودش (?month=1404/08)
 *  - منابع انسانی و ادمین: همه با فیلتر ?userId= و ?month=
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('HR', 'EMPLOYEE')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const userId = sp.get('userId')
    const month = sp.get('month')

    const where: Record<string, unknown> = {}
    // دارندگان بخش HR همه را می‌بینند؛ بقیه فقط دادهٔ خودشان
    const canSeeAll =
      g.session.role === 'ADMIN' ||
      (await hasUserPanelAccess(g.session.userId, g.session.role, 'HR'))
    if (!canSeeAll) where.userId = g.session.userId
    else if (userId) where.userId = userId
    if (month) where.date = { startsWith: month }

    const rows = await db.workLog.findMany({
      where,
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
      include: { user: { select: { fullName: true } } },
      take: 400,
    })
    return ok(
      rows.map((w) => ({
        id: w.id,
        userId: w.userId,
        userName: w.user.fullName,
        date: w.date,
        hours: w.hours,
        overtime: w.overtime,
        note: w.note,
        createdAt: w.createdAt.toISOString(),
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** ثبت کارکرد — منابع انسانی و ادمین */
export async function POST(req: Request) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const parsed = workLogSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const target = await db.user.findUnique({ where: { id: input.userId } })
    if (!target || target.role !== 'EMPLOYEE') return fail('کارمند پیدا نشد', 422)

    const row = await db.workLog.create({
      data: {
        userId: input.userId,
        date: input.date,
        hours: input.hours,
        overtime: input.overtime ?? 0,
        note: input.note || null,
      },
    })
    return ok({ id: row.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
