import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { workLogUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش کارکرد — منابع انسانی و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = workLogUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.workLog.findUnique({ where: { id } })
    if (!exists) return fail('رکورد کارکرد پیدا نشد', 404)

    const row = await db.workLog.update({
      where: { id },
      data: {
        ...(input.date !== undefined ? { date: input.date } : {}),
        ...(input.hours !== undefined ? { hours: input.hours } : {}),
        ...(input.overtime !== undefined ? { overtime: input.overtime } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })
    return ok({ id: row.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف کارکرد — منابع انسانی و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.workLog.findUnique({ where: { id } })
    if (!exists) return fail('رکورد کارکرد پیدا نشد', 404)
    await db.workLog.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
