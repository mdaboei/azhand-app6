import { ok, fail } from '@/lib/api-helpers'
import { getSession } from '@/lib/session'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getSession()
  if (!session) return fail('وارد نشده‌اید', 401)
  const user = await db.user.findUnique({
    where: { id: session.userId },
    include: { project: { select: { name: true } } },
  })
  if (!user) return fail('کاربر پیدا نشد', 404)
  return ok({
    user: session,
    profile: {
      fullName: user.fullName,
      nationalId: user.nationalId,
      phone: user.phone,
      position: user.position,
      hireDate: user.hireDate,
      baseSalary: user.baseSalary,
      projectName: user.project?.name ?? null,
    },
  })
}
