import type { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { loginSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, serverError } from '@/lib/api-helpers'
import { setSessionCookie } from '@/lib/session'
import { homeForRole, PANEL_PATHS, type Role } from '@/lib/types'
import { getUserPanelList } from '@/lib/permissions'
import { checkRateLimit, resetRateLimit, clientIp } from '@/lib/rate-limit'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null)
    const parsed = loginSchema.safeParse(body)
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)

    const username = parsed.data.username.toLowerCase()

    // ─── ضد brute-force: حداکثر ۵ تلاش در ۱۰ دقیقه برای هر IP + نام کاربری ───
    const rlKey = `${clientIp(req.headers)}:${username}`
    const rl = checkRateLimit(rlKey)
    if (!rl.ok) {
      return Response.json(
        { error: `تلاش‌های ناموفق زیاد بود — حساب موقتاً قفل شد. ${rl.retryAfterSec} ثانیه دیگر دوباره امتحان کنید` },
        { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } },
      )
    }

    const user = await db.user.findUnique({ where: { username } })
    if (!user) return fail('نام کاربری یا رمز عبور اشتباه است', 401)

    const passOk = await bcrypt.compare(parsed.data.password, user.passwordHash)
    if (!passOk) return fail('نام کاربری یا رمز عبور اشتباه است', 401)

    if (!user.isActive) {
      return fail('حساب شما غیرفعال است — با ادمین سیستم تماس بگیرید', 403)
    }

    resetRateLimit(rlKey)

    const payload = {
      userId: user.id,
      role: user.role as Role,
      fullName: user.fullName,
      username: user.username,
    }
    await setSessionCookie(payload)
    // مقصد بعد از ورود: نقش‌های پایه مسیر مشخص دارند؛ نقش سفارشی به اولین
    // بخش مجازش می‌رود (ماتریس دسترسی‌ها یا تخصیص اختصاصی خودش)
    let redirect = homeForRole(payload.role)
    if (redirect === '/') {
      const panels = await getUserPanelList(user.id, payload.role)
      redirect = panels[0] ? PANEL_PATHS[panels[0]] : '/'
    }
    return ok({ ok: true, role: user.role, redirect })
  } catch (e) {
    return serverError(e)
  }
}
