import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { projectSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireSession, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** لیست پروژه‌ها با تعداد کارمند فعال هر پروژه — همه کاربران وارد شده */
export async function GET() {
  const g = await requireSession()
  if ('res' in g) return g.res
  try {
    const rows = await db.project.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { users: { where: { role: 'EMPLOYEE', isActive: true } } } },
      },
    })
    return ok(
      rows.map((p) => ({
        id: p.id,
        name: p.name,
        note: p.note,
        isActive: p.isActive,
        employeeCount: p._count.users,
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** ساخت پروژه — فقط ادمین (تعریف پروژه از منابع انسانی حذف شده) */
export async function POST(req: Request) {
  const g = await requireAnyPanel('ADMIN')
  if ('res' in g) return g.res
  try {
    const parsed = projectSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const name = parsed.data.name
    const exists = await db.project.findUnique({ where: { name } })
    if (exists) return fail('پروژه‌ای با این نام هست', 409)
    const proj = await db.project.create({
      data: { name, note: parsed.data.note || null },
    })
    return ok({ id: proj.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
