import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { projectUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش پروژه — فقط ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('ADMIN')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = projectUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)

    const exists = await db.project.findUnique({ where: { id } })
    if (!exists) return fail('پروژه پیدا نشد', 404)

    if (parsed.data.name && parsed.data.name !== exists.name) {
      const dup = await db.project.findUnique({ where: { name: parsed.data.name } })
      if (dup) return fail('پروژه‌ای با این نام هست', 409)
    }

    const proj = await db.project.update({
      where: { id },
      data: {
        ...(parsed.data.name !== undefined ? { name: parsed.data.name } : {}),
        ...(parsed.data.note !== undefined ? { note: parsed.data.note || null } : {}),
        ...(parsed.data.isActive !== undefined ? { isActive: parsed.data.isActive } : {}),
      },
    })
    return ok({ id: proj.id, isActive: proj.isActive })
  } catch (e) {
    return serverError(e)
  }
}
