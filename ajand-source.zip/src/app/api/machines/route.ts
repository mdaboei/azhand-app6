import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { machineSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** لیست ماشین‌ها با تعداد بیمه‌نامه‌های فعال، پیوست سند و خلاصه کارت سوخت — واحد ماشین‌آلات، بیمه و ادمین */
export async function GET() {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const rows = await db.machine.findMany({
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: {
            policies: { where: { status: 'ACTIVE' } },
            attachments: true,
          },
        },
        fuelCard: {
          select: {
            cardNumber: true,
            assignedAt: true,
            holder: { select: { fullName: true } },
            project: { select: { name: true } },
          },
        },
      },
    })
    return ok(
      rows.map((m) => ({
        id: m.id,
        name: m.name,
        deviceNumber: m.deviceNumber,
        model: m.model,
        plateNumber: m.plateNumber,
        ownerName: m.ownerName,
        chassisNumber: m.chassisNumber,
        year: m.year,
        status: m.status as 'ACTIVE' | 'INACTIVE',
        note: m.note,
        activePolicyCount: m._count.policies,
        attachmentsCount: m._count.attachments,
        fuelCard: m.fuelCard
          ? {
              cardNumber: m.fuelCard.cardNumber,
              assignedAt: m.fuelCard.assignedAt,
              holderName: m.fuelCard.holder?.fullName ?? null,
              projectName: m.fuelCard.project?.name ?? null,
            }
          : null,
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** ثبت ماشین جدید — واحد ماشین‌آلات و ادمین */
export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const parsed = machineSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const row = await db.machine.create({
      data: {
        name: input.name,
        deviceNumber: input.deviceNumber,
        model: input.model || null,
        plateNumber: input.plateNumber || null,
        ownerName: input.ownerName || null,
        chassisNumber: input.chassisNumber || null,
        year: input.year || null,
        status: input.status,
        note: input.note || null,
        createdById: g.session.userId,
      },
    })
    return ok({ id: row.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
