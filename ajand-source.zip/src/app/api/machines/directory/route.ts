import { db } from '@/lib/db'
import { ok, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * فهرست کارکنان فعال و پروژه‌ها برای «کارت سوخت» ماشین‌ها —
 * فقط برای تخصیص تحویل کارت سوخت استفاده می‌شود (واحد ماشین‌آلات و ادمین).
 */
export async function GET() {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const [employees, projects] = await Promise.all([
      db.user.findMany({
        where: { isActive: true },
        orderBy: { fullName: 'asc' },
        select: {
          id: true,
          fullName: true,
          role: true,
          project: { select: { name: true } },
        },
      }),
      db.project.findMany({
        where: { isActive: true },
        orderBy: { name: 'asc' },
        select: { id: true, name: true },
      }),
    ])
    return ok({ employees, projects })
  } catch (e) {
    return serverError(e)
  }
}
