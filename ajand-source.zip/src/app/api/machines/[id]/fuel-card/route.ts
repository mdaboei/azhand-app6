import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { fuelCardSchema } from '@/lib/schemas'
import { ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

function cardDTO(card: {
  id: string
  machineId: string
  cardNumber: string
  holderId: string | null
  holder: { fullName: string } | null
  projectId: string | null
  project: { name: string } | null
  assignedAt: string | null
  note: string | null
  attachments: { id: string; cardId: string; fileName: string; mimeType: string; size: number; createdAt: Date }[]
}) {
  return {
    id: card.id,
    machineId: card.machineId,
    cardNumber: card.cardNumber,
    holderId: card.holderId,
    holderName: card.holder?.fullName ?? null,
    projectId: card.projectId,
    projectName: card.project?.name ?? null,
    assignedAt: card.assignedAt,
    note: card.note,
    attachments: card.attachments.map((a) => ({
      id: a.id,
      cardId: a.cardId,
      fileName: a.fileName,
      mimeType: a.mimeType,
      size: a.size,
      createdAt: a.createdAt.toISOString(),
    })),
  }
}

/** کارت سوخت ماشین (در صورت ثبت) همراه پیوست‌های رسید تحویل — واحد ماشین‌آلات و ادمین */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const card = await db.fuelCard.findUnique({
      where: { machineId: id },
      select: {
        id: true,
        machineId: true,
        cardNumber: true,
        holderId: true,
        holder: { select: { fullName: true } },
        projectId: true,
        project: { select: { name: true } },
        assignedAt: true,
        note: true,
        attachments: {
          orderBy: { createdAt: 'desc' },
          select: { id: true, cardId: true, fileName: true, mimeType: true, size: true, createdAt: true },
        },
      },
    })
    return ok(card ? cardDTO(card) : null)
  } catch (e) {
    return serverError(e)
  }
}

/**
 * ثبت یا ویرایش کارت سوخت ماشین (upsert) — واحد ماشین‌آلات و ادمین.
 * تحویل‌گیرنده (کارمند) و پروژه فقط مخصوص کارت سوخت است.
 */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const machine = await db.machine.findUnique({ where: { id } })
    if (!machine) return fail('ماشین پیدا نشد', 404)

    const parsed = fuelCardSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const holderId = input.holderId || null
    if (holderId) {
      const holder = await db.user.findUnique({ where: { id: holderId }, select: { id: true } })
      if (!holder) return fail('کارمند انتخاب‌شده پیدا نشد', 422)
    }
    const projectId = input.projectId || null
    if (projectId) {
      const project = await db.project.findUnique({ where: { id: projectId }, select: { id: true } })
      if (!project) return fail('پروژه انتخاب‌شده پیدا نشد', 422)
    }

    const card = await db.fuelCard.upsert({
      where: { machineId: id },
      create: {
        machineId: id,
        cardNumber: input.cardNumber,
        holderId,
        projectId,
        assignedAt: input.assignedAt || null,
        note: input.note || null,
      },
      update: {
        cardNumber: input.cardNumber,
        holderId,
        projectId,
        assignedAt: input.assignedAt || null,
        note: input.note || null,
      },
      select: {
        id: true,
        machineId: true,
        cardNumber: true,
        holderId: true,
        holder: { select: { fullName: true } },
        projectId: true,
        project: { select: { name: true } },
        assignedAt: true,
        note: true,
        attachments: {
          orderBy: { createdAt: 'desc' },
          select: { id: true, cardId: true, fileName: true, mimeType: true, size: true, createdAt: true },
        },
      },
    })
    return ok(cardDTO(card))
  } catch (e) {
    return serverError(e)
  }
}

/** حذف کارت سوخت ماشین (رسیدهای تحویل هم حذف می‌شوند) — واحد ماشین‌آلات و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const card = await db.fuelCard.findUnique({ where: { machineId: id } })
    if (!card) return fail('برای این ماشین کارت سوختی ثبت نشده است', 404)

    await db.fuelCard.delete({ where: { id: card.id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
