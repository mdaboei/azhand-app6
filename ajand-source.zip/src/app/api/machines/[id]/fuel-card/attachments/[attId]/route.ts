import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * دریافت فایل رسید تحویل کارت سوخت — واحد ماشین‌آلات و ادمین
 *  - حالت عادی: دانلود (attachment)
 *  - ?mode=inline : نمایش داخل مرورگر برای چاپ
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ attId: string }> }) {
  const g = await requireAnyPanel('MACHINERY', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const { attId } = await params
    const att = await db.fuelCardAttachment.findUnique({
      where: { id: attId },
      select: { data: true, mimeType: true, fileName: true },
    })
    if (!att) return fail('رسید پیدا نشد', 404)

    const inline = req.nextUrl.searchParams.get('mode') === 'inline'
    const safeName = encodeURIComponent(att.fileName)
    return new NextResponse(new Uint8Array(att.data), {
      headers: {
        'Content-Type': att.mimeType,
        'Content-Disposition': inline
          ? `inline; filename="fuel-receipt-${attId}"; filename*=UTF-8''${safeName}`
          : `attachment; filename="fuel-receipt-${attId}"; filename*=UTF-8''${safeName}`,
        'Cache-Control': 'private, max-age=3600',
      },
    })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف رسید تحویل کارت سوخت — واحد ماشین‌آلات و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ attId: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { attId } = await params
    const att = await db.fuelCardAttachment.findUnique({ where: { id: attId } })
    if (!att) return fail('رسید پیدا نشد', 404)

    await db.fuelCardAttachment.delete({ where: { id: attId } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
