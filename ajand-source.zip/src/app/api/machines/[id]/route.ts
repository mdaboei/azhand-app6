import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { machineUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش ماشین — واحد ماشین‌آلات و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = machineUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.machine.findUnique({ where: { id } })
    if (!exists) return fail('ماشین پیدا نشد', 404)

    const row = await db.machine.update({
      where: { id },
      data: {
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.deviceNumber !== undefined ? { deviceNumber: input.deviceNumber } : {}),
        ...(input.model !== undefined ? { model: input.model || null } : {}),
        ...(input.plateNumber !== undefined ? { plateNumber: input.plateNumber || null } : {}),
        ...(input.ownerName !== undefined ? { ownerName: input.ownerName || null } : {}),
        ...(input.chassisNumber !== undefined ? { chassisNumber: input.chassisNumber || null } : {}),
        ...(input.year !== undefined ? { year: input.year || null } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })
    return ok({ id: row.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف ماشین — اگر بیمه‌نامه داشته باشد اجازه نیست */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.machine.findUnique({ where: { id } })
    if (!exists) return fail('ماشین پیدا نشد', 404)

    const policyCount = await db.insurancePolicy.count({ where: { machineId: id } })
    if (policyCount > 0) return fail('این ماشین بیمه‌نامه دارد — اول بیمه‌نامه‌ها را حذف کنید', 409)

    await db.machine.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
