import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'

const MAX_SIZE = 5 * 1024 * 1024 // ۵ مگابایت

/** لیست پیوست‌های سند ماشین (بدون محتوا) — واحد ماشین‌آلات و ادمین */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const machine = await db.machine.findUnique({ where: { id }, select: { id: true } })
    if (!machine) return fail('ماشین پیدا نشد', 404)

    const rows = await db.machineAttachment.findMany({
      where: { machineId: id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, machineId: true, fileName: true, mimeType: true, size: true, createdAt: true },
    })
    return ok(rows.map((a) => ({ ...a, createdAt: a.createdAt.toISOString() })))
  } catch (e) {
    return serverError(e)
  }
}

/** بارگذاری پیوست سند ماشین (عکس یا PDF، حداکثر ۵ مگابایت) — واحد ماشین‌آلات و ادمین */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const machine = await db.machine.findUnique({ where: { id } })
    if (!machine) return fail('ماشین پیدا نشد', 404)

    const form = await req.formData().catch(() => null)
    if (!form) return fail('فایل ارسال نشده است', 422)

    const file = form.get('file')
    if (!(file instanceof File)) return fail('فایل را انتخاب کنید', 422)

    if (file.size > MAX_SIZE) return fail('حجم فایل بیشتر از ۵ مگابایت است', 413)

    const mimeType = file.type || 'application/octet-stream'
    if (!mimeType.startsWith('image/') && mimeType !== 'application/pdf') {
      return fail('فقط عکس یا PDF', 422)
    }

    const data = Buffer.from(await file.arrayBuffer())
    const att = await db.machineAttachment.create({
      data: {
        machineId: id,
        fileName: file.name || `machine-doc-${Date.now()}`,
        mimeType,
        size: data.length,
        data,
        createdById: g.session.userId,
      },
    })
    return ok({ id: att.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
