import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import { requireAnyPanel, serverError } from '@/lib/api-helpers'

/** خروجی اکسل ماشین‌ها — ماشین‌آلات، بیمه و ادمین */
export async function GET() {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const machines = await db.machine.findMany({
      orderBy: { name: 'asc' },
      include: {
        _count: { select: { policies: { where: { status: 'ACTIVE' } } } },
        fuelCard: {
          select: {
            cardNumber: true,
            assignedAt: true,
            holder: { select: { fullName: true } },
            project: { select: { name: true } },
          },
        },
      },
    })
    const data = machines.map((m) => ({
      'نام ماشین': m.name,
      'شماره دستگاه': m.deviceNumber ?? '',
      'نام صاحب خودرو': m.ownerName ?? '',
      'شماره شاسی': m.chassisNumber ?? '',
      'مدل/تیپ': m.model ?? '',
      'شماره پلاک': m.plateNumber ?? '',
      'سال ساخت': m.year ?? '',
      وضعیت: m.status === 'ACTIVE' ? 'فعال' : 'خارج از سرویس',
      'بیمه‌نامه‌های فعال': m._count.policies,
      'کارت سوخت': m.fuelCard?.cardNumber ?? '',
      'تحویل‌گیرنده کارت': m.fuelCard?.holder?.fullName ?? '',
      'پروژه کارت سوخت': m.fuelCard?.project?.name ?? '',
      'تاریخ تحویل کارت': m.fuelCard?.assignedAt ?? '',
      یادداشت: m.note ?? '',
    }))
    return excelResponse(data, 'ماشین‌آلات.xlsx', 'ماشین‌آلات')
  } catch (e) {
    return serverError(e)
  }
}
