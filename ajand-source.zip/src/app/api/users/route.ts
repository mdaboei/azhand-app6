import type { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { createUserSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { isValidRole } from '@/lib/roles'

/**
 * لیست کاربران:
 *  - ادمین: همه کاربران
 *  - منابع انسانی: فقط کارمندها (برای پرسنل/کارکرد/فیش/امتیاز)
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('ADMIN', 'HR')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const role = sp.get('role')
    const projectId = sp.get('projectId')

    const where: Record<string, unknown> = {}
    if (g.session.role === 'HR') where.role = 'EMPLOYEE'
    if (role && g.session.role === 'ADMIN') where.role = role
    if (projectId) where.projectId = projectId

    const rows = await db.user.findMany({
      where,
      orderBy: [{ role: 'asc' }, { fullName: 'asc' }],
      include: { project: { select: { name: true } } },
    })
    return ok(
      rows.map((u) => ({
        id: u.id,
        username: u.username,
        fullName: u.fullName,
        role: u.role,
        isActive: u.isActive,
        nationalId: u.nationalId,
        phone: u.phone,
        position: u.position,
        hireDate: u.hireDate,
        baseSalary: u.baseSalary,
        projectId: u.projectId,
        projectName: u.project?.name ?? null,
        createdAt: u.createdAt.toISOString(),
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/**
 * ساخت کاربر جدید:
 *  - ادمین: هر نقشی
 *  - منابع انسانی: فقط کارمند (پرسنل جدید) — رمز پیش‌فرض 12345678
 */
export async function POST(req: Request) {
  const g = await requireAnyPanel('ADMIN', 'HR')
  if ('res' in g) return g.res
  try {
    const parsed = createUserSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    if (g.session.role === 'HR' && input.role !== 'EMPLOYEE') {
      return fail('منابع انسانی فقط می‌تواند کارمند ثبت کند', 403)
    }

    // نقش باید پایه یا سفارشیِ تعریف‌شده باشد
    if (!(await isValidRole(input.role))) {
      return fail('نقش انتخابی معتبر نیست', 422)
    }

    const username = input.username.toLowerCase()
    const exists = await db.user.findUnique({ where: { username } })
    if (exists) return fail('این نام کاربری قبلاً گرفته شده است', 409)

    if (input.projectId) {
      const proj = await db.project.findUnique({ where: { id: input.projectId } })
      if (!proj) return fail('پروژه پیدا نشد', 422)
    }

    const passwordHash = bcrypt.hashSync(input.password || '12345678', 10)
    const user = await db.user.create({
      data: {
        username,
        passwordHash,
        fullName: input.fullName,
        role: input.role,
        nationalId: input.nationalId || null,
        phone: input.phone || null,
        position: input.position || null,
        hireDate: input.hireDate || null,
        baseSalary: input.baseSalary ?? null,
        projectId: input.projectId || null,
      },
    })
    return ok({ id: user.id, username: user.username }, 201)
  } catch (e) {
    return serverError(e)
  }
}
