import type { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { updateUserSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { isValidRole } from '@/lib/roles'

/** ویرایش کاربر:
 *  - ادمین: همه‌چیز (نام، نقش، فعال/غیرفعال، رمز، پروفایل)
 *  - منابع انسانی: فقط پروفایل کارمندها (نه نقش/فعال/رمز)
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('ADMIN', 'HR')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = updateUserSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const target = await db.user.findUnique({ where: { id } })
    if (!target) return fail('کاربر پیدا نشد', 404)

    const data: Record<string, unknown> = {}

    if (g.session.role === 'ADMIN') {
      if (input.fullName !== undefined) data.fullName = input.fullName
      if (input.isActive !== undefined) data.isActive = input.isActive
      if (input.role !== undefined) {
        // نقش باید پایه یا سفارشیِ تعریف‌شده باشد
        if (!(await isValidRole(input.role))) return fail('نقش انتخابی معتبر نیست', 422)
        data.role = input.role
      }
      if (input.password) data.passwordHash = bcrypt.hashSync(input.password, 10)
    } else {
      // HR — فقط پروفایل کارمند
      if (target.role !== 'EMPLOYEE') return fail('منابع انسانی فقط می‌تواند اطلاعات کارمند را ویرایش کند', 403)
      if (input.password || input.role || input.isActive !== undefined) {
        return fail('تغییر رمز و وضعیت فقط با ادمین است', 403)
      }
      if (input.fullName !== undefined) data.fullName = input.fullName
    }

    if (input.nationalId !== undefined) data.nationalId = input.nationalId || null
    if (input.phone !== undefined) data.phone = input.phone || null
    if (input.position !== undefined) data.position = input.position || null
    if (input.hireDate !== undefined) data.hireDate = input.hireDate || null
    if (input.baseSalary !== undefined) data.baseSalary = input.baseSalary
    if (input.projectId !== undefined) {
      if (input.projectId) {
        const proj = await db.project.findUnique({ where: { id: input.projectId } })
        if (!proj) return fail('پروژه پیدا نشد', 422)
      }
      data.projectId = input.projectId || null
    }

    const user = await db.user.update({ where: { id }, data })
    return ok({ id: user.id, fullName: user.fullName, role: user.role, isActive: user.isActive })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف هم نداریم — غیرفعال‌سازی با PATCH isActive=false تا سابقه حفظ شود */
