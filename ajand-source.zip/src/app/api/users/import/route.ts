import type { NextRequest } from 'next/request'
import * as XLSX from 'xlsx'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'
import { normalizeTitle } from '@/lib/payslip'
import { toEnDigits } from '@/lib/excel'

/**
 * ورود گروهی پرسنل از اکسل — منابع انسانی و ادمین
 *
 * قالب فایل (هدرها در ردیف اول):
 *   نام کاربری | نام و نام خانوادگی | سمت | کد ملی | شماره تماس |
 *   تاریخ استخدام | حقوق پایه (تومان) | پروژه | رمز عبور (اختیاری)
 *
 *  - همهٔ ردیف‌ها به‌عنوان «کارمند» ثبت می‌شوند (HR فقط کارمند می‌سازد).
 *  - نام کاربری الزامی و یکتاست (تکراری → رد می‌شود).
 *  - اگر «پروژه» داده شود باید با نام یکی از پروژه‌های تعریف‌شدهٔ ادمین مطابقت داشته باشد.
 *  - اگر «رمز عبور» داده نشود رمز پیش‌فرض 12345678 می‌شود.
 */

const MAX_ROWS = 500
const DEFAULT_PASSWORD = '12345678'

interface RowProblem {
  row: number
  username: string
  reason: string
}

export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('HR')
  if ('res' in g) return g.res
  try {
    const form = await req.formData().catch(() => null)
    const file = form?.get('file')
    if (!file || !(file instanceof File)) return fail('فایل اکسل را انتخاب کنید', 422)
    if (file.size > 5 * 1024 * 1024) return fail('حجم فایل باید کمتر از ۵ مگابایت باشد', 413)

    let rows: unknown[][]
    try {
      const buf = Buffer.from(await file.arrayBuffer())
      const wb = XLSX.read(buf, { type: 'buffer' })
      const sheet = wb.Sheets[wb.SheetNames[0]]
      if (!sheet) return fail('فایل اکسل هیچ شیتی ندارد', 422)
      rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: '', blankrows: false })
    } catch {
      return fail('خواندن فایل اکسل ناموفق بود — فایل معتبر xlsx/xls بدهید', 422)
    }
    if (rows.length < 2) return fail('فایل خالی است — بعد از هدر، حداقل یک ردیف لازم است', 422)

    // ── ردیف هدر: اولین ردیفی که «نام کاربری» دارد
    let headerRow = -1
    for (let i = 0; i < Math.min(rows.length, 5); i++) {
      const cells = (rows[i] ?? []).map((c) => normalizeTitle(String(c ?? '')))
      if (cells.some((c) => /نام کاربری|username/i.test(c))) {
        headerRow = i
        break
      }
    }
    if (headerRow === -1) {
      return fail('ستون «نام کاربری» در فایل پیدا نشد — از قالب نمونه استفاده کنید', 422)
    }

    const headers = (rows[headerRow] ?? []).map((c) => normalizeTitle(String(c ?? '')))
    const findCol = (...patterns: RegExp[]) =>
      headers.findIndex((h) => h.length > 0 && patterns.some((p) => p.test(h)))

    const usernameIdx = findCol(/نام کاربری/, /username/i)
    const nameIdx = findCol(/نام و نام خانوادگی/, /نام کارمند/, /^نام$/, /full ?name/i)
    if (usernameIdx === -1 || nameIdx === -1) {
      return fail('ستون‌های «نام کاربری» و «نام و نام خانوادگی» در فایل لازم است', 422)
    }
    const positionIdx = findCol(/سمت/)
    const nationalIdx = findCol(/کد ملی/)
    const phoneIdx = findCol(/شماره تماس|تلفن|موبایل/)
    const hireDateIdx = findCol(/تاریخ استخدام/)
    const salaryIdx = findCol(/حقوق پایه/, /^حقوق/)
    const projectIdx = findCol(/پروژه/)
    const passwordIdx = findCol(/رمز/)

    // ── پروژه‌های موجود (تطبیق با نام)
    const projects = await db.project.findMany({ select: { id: true, name: true } })
    const projectByName = new Map(projects.map((p) => [normalizeTitle(p.name), p]))

    let imported = 0
    const problems: RowProblem[] = []

    const dataRows = rows.slice(headerRow + 1)
    for (let i = 0; i < dataRows.length; i++) {
      if (imported + problems.length >= MAX_ROWS * 2) {
        problems.push({ row: i + headerRow + 2, username: '-', reason: `بیش از ${MAX_ROWS} ردیف پردازش نشد` })
        break
      }
      const raw = dataRows[i] ?? []
      const rowNo = i + headerRow + 2

      const username = toEnDigits(String(raw[usernameIdx] ?? '')).trim().toLowerCase()
      if (!username) continue // ردیف کاملاً خالی

      const cell = (idx: number) => {
        const v = String(raw[idx] ?? '').trim()
        return v.length > 0 ? v : null
      }

      const fullName = cell(nameIdx)
      if (!fullName || fullName.length < 3) {
        problems.push({ row: rowNo, username, reason: 'نام و نام خانوادگی را کامل وارد کنید' })
        continue
      }
      if (!/^[a-z0-9._-]{3,40}$/.test(username)) {
        problems.push({ row: rowNo, username, reason: 'نام کاربری فقط حروف انگلیسی، عدد، نقطه و خط تیره (حداقل ۳ نویسه)' })
        continue
      }

      const exists = await db.user.findUnique({ where: { username } })
      if (exists) {
        problems.push({ row: rowNo, username, reason: 'این نام کاربری قبلاً ثبت شده است' })
        continue
      }

      // تاریخ استخدام — شمسی مثل 1404/05/01 یا پیوسته مثل 14040501
      let hireDate: string | null = null
      const hireRaw = hireDateIdx !== -1 ? cell(hireDateIdx) : null
      if (hireRaw) {
        const cleaned = toEnDigits(hireRaw).replace(/[^\d/]/g, '')
        let parts = cleaned.split('/').filter(Boolean)
        if (parts.length === 1 && parts[0].length === 8) {
          const d = parts[0]
          parts = [d.slice(0, 4), d.slice(4, 6), d.slice(6, 8)]
        }
        if (parts.length === 3) {
          hireDate = `${parts[0]}/${parts[1].padStart(2, '0')}/${parts[2].padStart(2, '0')}`
        }
        if (!hireDate || !/^\d{4}\/\d{2}\/\d{2}$/.test(hireDate)) {
          problems.push({ row: rowNo, username, reason: `تاریخ استخدام نامعتبر است: ${hireRaw}` })
          continue
        }
      }

      // حقوق پایه
      let baseSalary: number | null = null
      const salaryRaw = salaryIdx !== -1 ? cell(salaryIdx) : null
      if (salaryRaw) {
        const num = Number(toEnDigits(salaryRaw).replace(/[,،\s]/g, '').replace(/[^\d.-]/g, ''))
        if (!Number.isFinite(num) || num < 0) {
          problems.push({ row: rowNo, username, reason: `حقوق پایه نامعتبر است: ${salaryRaw}` })
          continue
        }
        baseSalary = num
      }

      // پروژه — باید از قبل تعریف شده باشد
      let projectId: string | null = null
      const projectRaw = projectIdx !== -1 ? cell(projectIdx) : null
      if (projectRaw) {
        const found = projectByName.get(normalizeTitle(projectRaw))
        if (!found) {
          problems.push({ row: rowNo, username, reason: `پروژه‌ای به نام «${projectRaw}» پیدا نشد — اول در پنل ادمین تعریف کنید` })
          continue
        }
        projectId = found.id
      }

      // رمز عبور — اختیاری با سیاست حداقل ۸ نویسه + حرف + عدد
      let password = DEFAULT_PASSWORD
      const passRaw = passwordIdx !== -1 ? cell(passwordIdx) : null
      if (passRaw) {
        const p = toEnDigits(passRaw).trim()
        if (p.length < 8 || !/[a-zA-Zآ-ی]/.test(p) || !/[0-9]/.test(p)) {
          problems.push({ row: rowNo, username, reason: 'رمز عبور حداقل ۸ نویسه با حرف و عدد باشد (یا خالی بگذارید تا 12345678 شود)' })
          continue
        }
        password = p
      }

      await db.user.create({
        data: {
          username,
          passwordHash: bcrypt.hashSync(password, 10),
          fullName: fullName.slice(0, 80),
          role: 'EMPLOYEE',
          nationalId: (nationalIdx !== -1 ? cell(nationalIdx) : null)?.slice(0, 20) || null,
          phone: (phoneIdx !== -1 ? cell(phoneIdx) : null)?.slice(0, 20) || null,
          position: (positionIdx !== -1 ? cell(positionIdx) : null)?.slice(0, 60) || null,
          hireDate,
          baseSalary,
          projectId,
        },
      })
      imported++
    }

    return ok({
      imported,
      failed: problems.length,
      problems: problems.slice(0, 20),
    })
  } catch (e) {
    return serverError(e)
  }
}
