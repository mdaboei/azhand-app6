import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'
import { getRoleLabelMap } from '@/lib/roles'

/** خروجی اکسل پرسنل — منابع انسانی و ادمین (بدون هیچ اطلاعات حساب/رمز) */
export async function GET() {
  const g = await requireAnyPanel('ADMIN', 'HR')
  if ('res' in g) return g.res
  try {
    const [users, labels] = await Promise.all([
      db.user.findMany({
        orderBy: [{ role: 'asc' }, { fullName: 'asc' }],
        include: { project: { select: { name: true } } },
      }),
      getRoleLabelMap(),
    ])
    const data = users.map((u) => ({
      'نام کاربری': u.username,
      'نام و نام خانوادگی': u.fullName,
      نقش: labels[u.role] ?? u.role,
      وضعیت: u.isActive ? 'فعال' : 'غیرفعال',
      'کد ملی': u.nationalId ?? '',
      تلفن: u.phone ?? '',
      سمت: u.position ?? '',
      'تاریخ استخدام': u.hireDate ?? '',
      'حقوق پایه (تومان)': u.baseSalary ?? '',
      پروژه: u.project?.name ?? '',
    }))
    return excelResponse(data, 'پرسنل.xlsx', 'پرسنل')
  } catch (e) {
    return serverError(e)
  }
}
