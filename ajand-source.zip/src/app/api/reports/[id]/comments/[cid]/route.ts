import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requirePanelSession, serverError } from '@/lib/api-helpers'

/** حذف کامنت — نویسندهٔ کامنت یا مدیریت/ادمین */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; cid: string }> },
) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { cid } = await params
    const comment = await db.reportComment.findUnique({ where: { id: cid } })
    if (!comment) return fail('کامنت پیدا نشد', 404)

    const { userId, role } = g.session
    const canDelete = comment.userId === userId || role === 'MANAGEMENT' || role === 'ADMIN'
    if (!canDelete) return fail('فقط نویسندهٔ کامنت یا مدیریت می‌تواند حذف کند', 403)

    await db.reportComment.delete({ where: { id: cid } })
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
}
