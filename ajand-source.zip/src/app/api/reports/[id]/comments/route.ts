import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requirePanelSession, serverError } from '@/lib/api-helpers'

/** کامنت‌های پست گزارش: GET فهرست | POST کامنت جدید */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const report = await db.projectReport.findUnique({ where: { id } })
    if (!report) return fail('پست پیدا نشد', 404)

    if (!report.isPublic) {
      const { userId, role } = g.session
      const allowed = report.authorId === userId || role === 'MANAGEMENT' || role === 'ADMIN'
      if (!allowed) return fail('این پست خصوصی است', 403)
    }

    const rows = await db.reportComment.findMany({
      where: { reportId: id },
      orderBy: { createdAt: 'asc' },
      include: { user: { select: { id: true, fullName: true } } },
    })

    return ok(rows.map((c) => ({
      id: c.id,
      reportId: c.reportId,
      userId: c.user.id,
      userName: c.user.fullName,
      body: c.body,
      createdAt: c.createdAt.toISOString(),
    })))
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const body = await req.json().catch(() => null)
    const text = String(body?.body ?? '').trim()
    if (!text) return fail('متن کامنت را وارد کنید', 422)
    if (text.length > 1000) return fail('متن کامنت طولانی است', 422)

    const report = await db.projectReport.findUnique({ where: { id } })
    if (!report) return fail('پست پیدا نشد', 404)

    if (!report.isPublic) {
      const { userId, role } = g.session
      const allowed = report.authorId === userId || role === 'MANAGEMENT' || role === 'ADMIN'
      if (!allowed) return fail('این پست خصوصی است', 403)
    }

    const created = await db.reportComment.create({
      data: { reportId: id, userId: g.session.userId, body: text },
      include: { user: { select: { id: true, fullName: true } } },
    })

    return ok({
      id: created.id,
      reportId: created.reportId,
      userId: created.user.id,
      userName: created.user.fullName,
      body: created.body,
      createdAt: created.createdAt.toISOString(),
    }, 201)
  } catch (e) {
    return serverError(e)
  }
}
