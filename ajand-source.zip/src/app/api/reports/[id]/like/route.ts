import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requirePanelSession, serverError } from '@/lib/api-helpers'

/**
 * لایک پست گزارش (toggle):
 *  - هر کاربر فقط یک لایک؛ ارسال دوباره = برداشتن لایک.
 *  - لایک «سوپر» فقط برای نقش مدیریت و ادمین است — سوپر لایک جدا شمرده می‌شود.
 *  body: { isSuper?: boolean }
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const body = await req.json().catch(() => ({}))

    const report = await db.projectReport.findUnique({ where: { id } })
    if (!report) return fail('پست پیدا نشد', 404)

    // پست خصوصی فقط نویسنده/مدیریت/ادمین
    if (!report.isPublic) {
      const { userId, role } = g.session
      const allowed = report.authorId === userId || role === 'MANAGEMENT' || role === 'ADMIN'
      if (!allowed) return fail('این پست خصوصی است', 403)
    }

    const { userId, role } = g.session
    const wantsSuper = body?.isSuper === true && (role === 'MANAGEMENT' || role === 'ADMIN')

    const existing = await db.reportLike.findUnique({
      where: { reportId_userId: { reportId: id, userId } },
    })

    let liked: boolean
    let isSuper = false
    if (!existing) {
      await db.reportLike.create({ data: { reportId: id, userId, isSuper: wantsSuper } })
      liked = true
      isSuper = wantsSuper
    } else if (wantsSuper) {
      if (existing.isSuper) {
        // دوباره ستاره = برداشتن لایک
        await db.reportLike.delete({ where: { id: existing.id } })
        liked = false
      } else {
        // ارتقای لایک عادی به سوپر لایک (فقط مدیریت)
        await db.reportLike.update({ where: { id: existing.id }, data: { isSuper: true } })
        liked = true
        isSuper = true
      }
    } else {
      // کلیک قلب
      if (existing.isSuper) {
        // تبدیل سوپر لایک به لایک عادی
        await db.reportLike.update({ where: { id: existing.id }, data: { isSuper: false } })
        liked = true
        isSuper = false
      } else {
        // دوباره قلب = برداشتن لایک
        await db.reportLike.delete({ where: { id: existing.id } })
        liked = false
      }
    }

    const [normalCount, superCount] = await Promise.all([
      db.reportLike.count({ where: { reportId: id, isSuper: false } }),
      db.reportLike.count({ where: { reportId: id, isSuper: true } }),
    ])

    return ok({ liked, isSuper, likeCount: normalCount, superLikeCount: superCount })
  } catch (e) {
    return serverError(e)
  }
}
