import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requirePanelSession, serverError } from '@/lib/api-helpers'

/** حذف پست گزارش — نویسنده یا مدیریت/ادمین */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const report = await db.projectReport.findUnique({ where: { id } })
    if (!report) return fail('پست پیدا نشد', 404)

    const { userId, role } = g.session
    const canDelete = report.authorId === userId || role === 'MANAGEMENT' || role === 'ADMIN'
    if (!canDelete) return fail('فقط نویسنده یا مدیریت می‌تواند پست را حذف کند', 403)

    await db.projectReport.delete({ where: { id } })
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
}
