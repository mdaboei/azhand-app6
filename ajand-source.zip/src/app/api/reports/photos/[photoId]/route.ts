import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { fail, requirePanelSession, serverError } from '@/lib/api-helpers'

/** سرو عکس گزارش — فقط دارندگان بخش گزارش؛ پست خصوصی برای نویسنده/مدیریت/ادمین */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ photoId: string }> },
) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { photoId } = await params
    const photo = await db.reportPhoto.findUnique({
      where: { id: photoId },
      include: { report: { select: { isPublic: true, authorId: true } } },
    })
    if (!photo) return fail('عکس پیدا نشد', 404)

    if (!photo.report.isPublic) {
      const { userId, role } = g.session
      const allowed = photo.report.authorId === userId || role === 'MANAGEMENT' || role === 'ADMIN'
      if (!allowed) return fail('این پست خصوصی است', 403)
    }

    const data = Buffer.from(photo.data)
    return new Response(new Uint8Array(data), {
      headers: {
        'Content-Type': photo.mimeType,
        'Content-Length': String(data.length),
        'Cache-Control': 'private, max-age=86400',
      },
    })
  } catch (e) {
    return serverError(e)
  }
}
