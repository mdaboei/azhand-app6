import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requirePanelSession, serverError } from '@/lib/api-helpers'
import { getRoleLabelMap } from '@/lib/roles'
import type { ReportDTO } from '@/lib/types'

const MAX_PHOTOS = 20
const MAX_PHOTO_SIZE = 5 * 1024 * 1024 // ۵ مگابایت

function canSeePrivate(role: string): boolean {
  return role === 'MANAGEMENT' || role === 'ADMIN'
}

/**
 * فید گزارش پروژه‌ها — فقط دارندگان بخش REPORTS:
 *  GET              → همه پست‌های قابل مشاهده (عمومی + خصوصی برای مدیریت/ادمین/نویسنده)
 *  GET ?userId=X    → پروفایل نویسنده + پست‌های او (همان قواعد دید)
 *  POST (multipart) → پست جدید: body + isPublic + photos[] (تا ۲۰ عکس)
 */
export async function GET(req: NextRequest) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const { userId: me, role: myRole } = g.session
    const seeAll = canSeePrivate(myRole)
    const authorId = req.nextUrl.searchParams.get('userId')

    const where: Record<string, unknown> = seeAll
      ? {}
      : { OR: [{ isPublic: true }, { authorId: me }] }
    if (authorId) where.authorId = authorId

    const rows = await db.projectReport.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: {
        author: { select: { id: true, fullName: true, role: true, position: true } },
        photos: { select: { id: true }, orderBy: { idx: 'asc' } },
        likes: { select: { isSuper: true, userId: true } },
        _count: { select: { comments: true } },
      },
    })

    const labels = await getRoleLabelMap()

    const reports: ReportDTO[] = rows.map((r) => {
      const mine = r.likes.find((l) => l.userId === me)
      return {
        id: r.id,
        authorId: r.author.id,
        authorName: r.author.fullName,
        authorRole: r.author.role,
        authorRoleLabel: labels[r.author.role] ?? r.author.role,
        authorPosition: r.author.position,
        body: r.body,
        isPublic: r.isPublic,
        createdAt: r.createdAt.toISOString(),
        photoIds: r.photos.map((p) => p.id),
        likeCount: r.likes.filter((l) => !l.isSuper).length,
        superLikeCount: r.likes.filter((l) => l.isSuper).length,
        commentCount: r._count.comments,
        likedByMe: !!mine,
        myLikeIsSuper: mine?.isSuper ?? false,
      }
    })

    let author
    if (authorId) {
      const u = await db.user.findUnique({
        where: { id: authorId },
        select: {
          id: true, fullName: true, role: true, position: true,
          project: { select: { name: true } },
          _count: { select: { reports: { where: seeAll ? {} : { isPublic: true } } } },
        },
      })
      if (u) {
        author = {
          id: u.id,
          fullName: u.fullName,
          role: u.role,
          roleLabel: labels[u.role] ?? u.role,
          position: u.position,
          projectName: u.project?.name ?? null,
          postCount: u._count.reports,
        }
      }
    }

    return ok({ reports, author })
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(req: NextRequest) {
  const g = await requirePanelSession('REPORTS')
  if ('res' in g) return g.res
  try {
    const form = await req.formData().catch(() => null)
    if (!form) return fail('فرم نامعتبر است', 422)

    const body = String(form.get('body') ?? '').trim()
    const isPublic = String(form.get('isPublic') ?? 'true') !== 'false'
    const photos = form.getAll('photos').filter((f): f is File => f instanceof File && f.size > 0)

    if (!body && photos.length === 0) {
      return fail('توضیحات یا حداقل یک عکس لازم است', 422)
    }
    if (photos.length > MAX_PHOTOS) {
      return fail(`حداکثر ${MAX_PHOTOS} عکس در هر پست`, 422)
    }
    for (const f of photos) {
      if (!f.type.startsWith('image/')) return fail('فقط فایل تصویری مجاز است', 422)
      if (f.size > MAX_PHOTO_SIZE) return fail(`عکس «${f.name}» بزرگ‌تر از ۵ مگابایت است`, 422)
    }

    const created = await db.projectReport.create({
      data: {
        authorId: g.session.userId,
        body: body || '—',
        isPublic,
      },
    })

    let idx = 0
    for (const f of photos) {
      const data = Buffer.from(await f.arrayBuffer())
      await db.reportPhoto.create({
        data: {
          reportId: created.id,
          idx: idx++,
          fileName: f.name || `photo-${idx}.jpg`,
          mimeType: f.type,
          size: f.size,
          data,
        },
      })
    }

    return ok({ id: created.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
