import { db } from '@/lib/db'
import { jalaliDayNumber, jalaliToday, padJalali } from '@/lib/persian'
import { ok, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * بیمه‌نامه‌های فعال که تا ۲ روز آینده منقضی می‌شوند — نوتیف بالای صفحه.
 * محاسبه بر مبنای تبدیل دقیق تاریخ شمسی به شمارهٔ روز ژولین انجام می‌شود؛
 * شامل امروز (۰ روز مانده)، فردا (۱) و پس‌فردا (۲).
 */
export async function GET() {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const todayNum = jalaliDayNumber(jalaliToday())
    if (Number.isNaN(todayNum)) return ok([])

    const rows = await db.insurancePolicy.findMany({
      where: { status: 'ACTIVE', endDate: { not: '' } },
      include: {
        machine: { select: { id: true, name: true } },
        type: { select: { name: true } },
      },
    })

    const expiring = rows
      .map((p) => {
        const endNum = jalaliDayNumber(padJalali(p.endDate))
        if (Number.isNaN(endNum)) return null
        const daysLeft = endNum - todayNum
        if (daysLeft < 0 || daysLeft > 2) return null
        return {
          id: p.id,
          machineId: p.machine.id,
          machineName: p.machine.name,
          typeName: p.type.name,
          company: p.company,
          policyNumber: p.policyNumber,
          endDate: p.endDate,
          daysLeft,
        }
      })
      .filter((x): x is NonNullable<typeof x> => x !== null)
      .sort((a, b) => a.daysLeft - b.daysLeft)

    return ok(expiring)
  } catch (e) {
    return serverError(e)
  }
}
