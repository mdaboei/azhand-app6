import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { insuranceTypeSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** ویرایش نوع بیمه — واحد بیمه و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = insuranceTypeSchema.partial().safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.insuranceType.findUnique({ where: { id } })
    if (!exists) return fail('نوع بیمه پیدا نشد', 404)

    const row = await db.insuranceType
      .update({
        where: { id },
        data: {
          ...(input.name !== undefined ? { name: input.name } : {}),
          ...(input.note !== undefined ? { note: input.note || null } : {}),
        },
      })
      .catch((e: { code?: string }) => {
        if (e.code === 'P2002') return null
        throw e
      })
    if (!row) return fail('این نوع بیمه قبلاً تعریف شده', 409)

    return ok({ id: row.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف نوع بیمه — اگر در بیمه‌نامه‌ای استفاده شده باشد اجازه نیست */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.insuranceType.findUnique({ where: { id } })
    if (!exists) return fail('نوع بیمه پیدا نشد', 404)

    const usedCount = await db.insurancePolicy.count({ where: { typeId: id } })
    if (usedCount > 0) return fail('این نوع بیمه در بیمه‌نامه‌ها استفاده شده — اول بیمه‌نامه‌ها را حذف کنید', 409)

    await db.insuranceType.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
