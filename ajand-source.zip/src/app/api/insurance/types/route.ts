import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { insuranceTypeSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** لیست نوع بیمه‌ها — واحد بیمه، ماشین‌آلات و ادمین */
export async function GET() {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const rows = await db.insuranceType.findMany({ orderBy: { name: 'asc' } })
    return ok(
      rows.map((t) => ({
        id: t.id,
        name: t.name,
        note: t.note,
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** تعریف نوع بیمه جدید — واحد بیمه و ادمین */
export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const parsed = insuranceTypeSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const row = await db.insuranceType
      .create({ data: { name: input.name, note: input.note || null } })
      .catch((e: { code?: string }) => {
        if (e.code === 'P2002') return null
        throw e
      })
    if (!row) return fail('این نوع بیمه قبلاً تعریف شده', 409)

    return ok({ id: row.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
