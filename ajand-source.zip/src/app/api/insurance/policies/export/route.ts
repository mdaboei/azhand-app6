import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { excelResponse } from '@/lib/excel'
import {requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * خروجی اکسل بیمه‌نامه‌ها — بیمه، مدیریت و ادمین
 * ?machineId= (اختیاری) و ?status= (اختیاری: ACTIVE/CANCELED)
 */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('MACHINERY', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const machineId = sp.get('machineId')
    const status = sp.get('status')

    const where: Record<string, unknown> = {}
    if (machineId) where.machineId = machineId
    if (status && status !== 'all') where.status = status

    const policies = await db.insurancePolicy.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        machine: { select: { name: true, deviceNumber: true } },
        type: { select: { name: true } },
      },
      take: 1000,
    })

    const data = policies.map((p) => ({
      ماشین: p.machine.name,
      'شماره دستگاه': p.machine.deviceNumber ?? '',
      'نوع بیمه': p.type.name,
      'شرکت بیمه‌گر': p.company,
      'شماره بیمه‌نامه': p.policyNumber,
      'از تاریخ': p.startDate,
      'تا تاریخ': p.endDate,
      وضعیت: p.status === 'ACTIVE' ? 'فعال' : p.status === 'CANCELED' ? 'لغو شده' : 'منقضی',
      یادداشت: p.note ?? '',
    }))
    return excelResponse(data, 'بیمه‌نامه‌ها.xlsx', 'بیمه‌نامه‌ها')
  } catch (e) {
    return serverError(e)
  }
}
