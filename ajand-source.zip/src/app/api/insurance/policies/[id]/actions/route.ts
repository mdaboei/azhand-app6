import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { policyActionSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * ثبت الحاقیه روی بیمه‌نامه — واحد بیمه و ادمین
 *  - الحاقیه فقط سابقه (تاریخ/یادداشت) ثبت می‌کند — مبلغ حق بیمه از برنامه حذف شده است.
 *  - تمدید حذف شد: برای سررسید جدید، بیمه‌نامهٔ جدید ثبت می‌شود (چند بیمه‌نامه هم‌نوع مجاز است).
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = policyActionSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const policy = await db.insurancePolicy.findUnique({ where: { id } })
    if (!policy) return fail('بیمه‌نامه پیدا نشد', 404)

    const action = await db.insuranceAction.create({
      data: {
        policyId: id,
        kind: 'ENDORSEMENT',
        date: input.date,
        newEndDate: null,
        amount: input.amount ?? null,
        note: input.note || null,
        createdById: g.session.userId,
      },
    })

    return ok({ id: action.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
