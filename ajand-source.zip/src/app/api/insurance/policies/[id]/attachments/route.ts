import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import {ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'

const MAX_SIZE = 5 * 1024 * 1024 // ۵ مگابایت

/** بارگذاری پیوست برای بیمه‌نامه (عکس یا PDF، حداکثر ۵ مگابایت) — واحد بیمه و ادمین */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const policy = await db.insurancePolicy.findUnique({ where: { id } })
    if (!policy) return fail('بیمه‌نامه پیدا نشد', 404)

    const form = await req.formData().catch(() => null)
    if (!form) return fail('فایل ارسال نشده است', 422)

    const file = form.get('file')
    if (!(file instanceof File)) return fail('فایل را انتخاب کنید', 422)

    if (file.size > MAX_SIZE) return fail('حجم فایل بیشتر از ۵ مگابایت است', 413)

    const mimeType = file.type || 'application/octet-stream'
    if (!mimeType.startsWith('image/') && mimeType !== 'application/pdf') {
      return fail('فقط عکس یا PDF', 422)
    }

    const data = Buffer.from(await file.arrayBuffer())
    const att = await db.insuranceAttachment.create({
      data: {
        policyId: id,
        fileName: file.name || `policy-file-${Date.now()}`,
        mimeType,
        size: data.length,
        data,
        createdById: g.session.userId,
      },
    })
    return ok({ id: att.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
