import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { policyUpdateSchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** جزئیات یک بیمه‌نامه + سابقه اقدامات + پیوست‌ها (بدون محتوای فایل) */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const p = await db.insurancePolicy.findUnique({
      where: { id },
      include: {
        machine: { select: { name: true } },
        type: { select: { name: true } },
        actions: { orderBy: { createdAt: 'desc' } },
        attachments: {
          orderBy: { createdAt: 'desc' },
          select: { id: true, policyId: true, fileName: true, mimeType: true, size: true, createdAt: true },
        },
      },
    })
    if (!p) return fail('بیمه‌نامه پیدا نشد', 404)

    return ok({
      id: p.id,
      machineId: p.machineId,
      machineName: p.machine.name,
      typeId: p.typeId,
      typeName: p.type.name,
      company: p.company,
      policyNumber: p.policyNumber,
      startDate: p.startDate,
      endDate: p.endDate,
      status: p.status as 'ACTIVE' | 'EXPIRED' | 'CANCELED',
      note: p.note,
      createdAt: p.createdAt.toISOString(),
      actions: p.actions.map((a) => ({
        id: a.id,
        policyId: a.policyId,
        kind: a.kind as 'RENEWAL' | 'ENDORSEMENT',
        date: a.date,
        newEndDate: a.newEndDate,
        amount: a.amount,
        note: a.note,
        createdAt: a.createdAt.toISOString(),
      })),
      attachments: p.attachments.map((f) => ({
        id: f.id,
        policyId: f.policyId,
        fileName: f.fileName,
        mimeType: f.mimeType,
        size: f.size,
        createdAt: f.createdAt.toISOString(),
      })),
    })
  } catch (e) {
    return serverError(e)
  }
}

/** ویرایش بیمه‌نامه (شامل وضعیت) — واحد بیمه و ادمین */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const parsed = policyUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const exists = await db.insurancePolicy.findUnique({ where: { id } })
    if (!exists) return fail('بیمه‌نامه پیدا نشد', 404)

    if (input.machineId) {
      const machine = await db.machine.findUnique({ where: { id: input.machineId } })
      if (!machine) return fail('ماشین انتخاب‌شده پیدا نشد', 422)
    }
    if (input.typeId) {
      const type = await db.insuranceType.findUnique({ where: { id: input.typeId } })
      if (!type) return fail('نوع بیمه انتخاب‌شده پیدا نشد', 422)
    }

    const row = await db.insurancePolicy.update({
      where: { id },
      data: {
        ...(input.machineId !== undefined ? { machineId: input.machineId } : {}),
        ...(input.typeId !== undefined ? { typeId: input.typeId } : {}),
        ...(input.company !== undefined ? { company: input.company } : {}),
        ...(input.policyNumber !== undefined ? { policyNumber: input.policyNumber } : {}),
        ...(input.startDate !== undefined ? { startDate: input.startDate } : {}),
        ...(input.endDate !== undefined ? { endDate: input.endDate } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.note !== undefined ? { note: input.note || null } : {}),
      },
    })
    return ok({ id: row.id })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف بیمه‌نامه همراه با اقدامات و پیوست‌ها */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const exists = await db.insurancePolicy.findUnique({ where: { id } })
    if (!exists) return fail('بیمه‌نامه پیدا نشد', 404)

    // ابتدا وابسته‌ها، بعد خود بیمه‌نامه
    await db.insuranceAttachment.deleteMany({ where: { policyId: id } })
    await db.insuranceAction.deleteMany({ where: { policyId: id } })
    await db.insurancePolicy.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
