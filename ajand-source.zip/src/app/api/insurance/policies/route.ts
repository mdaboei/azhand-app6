import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { policySchema } from '@/lib/schemas'
import {ok, fail, zodMessage, requireAnyPanel, serverError } from '@/lib/api-helpers'

/** لیست بیمه‌نامه‌ها با فیلتر ماشین و وضعیت — واحد بیمه و ادمین */
export async function GET(req: NextRequest) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const sp = req.nextUrl.searchParams
    const machineId = sp.get('machineId')
    const status = sp.get('status')

    const where: Record<string, unknown> = {}
    if (machineId) where.machineId = machineId
    if (status) where.status = status

    const rows = await db.insurancePolicy.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        machine: { select: { name: true } },
        type: { select: { name: true } },
      },
      take: 300,
    })
    return ok(
      rows.map((p) => ({
        id: p.id,
        machineId: p.machineId,
        machineName: p.machine.name,
        typeId: p.typeId,
        typeName: p.type.name,
        company: p.company,
        policyNumber: p.policyNumber,
        startDate: p.startDate,
        endDate: p.endDate,
        status: p.status as 'ACTIVE' | 'EXPIRED' | 'CANCELED',
        note: p.note,
        createdAt: p.createdAt.toISOString(),
      }))
    )
  } catch (e) {
    return serverError(e)
  }
}

/** صدور بیمه‌نامه جدید — واحد بیمه و ادمین */
export async function POST(req: NextRequest) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const parsed = policySchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) return fail(zodMessage(parsed.error), 422)
    const input = parsed.data

    const machine = await db.machine.findUnique({ where: { id: input.machineId } })
    if (!machine) return fail('ماشین انتخاب‌شده پیدا نشد', 422)
    const type = await db.insuranceType.findUnique({ where: { id: input.typeId } })
    if (!type) return fail('نوع بیمه انتخاب‌شده پیدا نشد', 422)

    const row = await db.insurancePolicy.create({
      data: {
        machineId: input.machineId,
        typeId: input.typeId,
        company: input.company,
        policyNumber: input.policyNumber,
        startDate: input.startDate,
        endDate: input.endDate,
        note: input.note || null,
        createdById: g.session.userId,
      },
    })
    return ok({ id: row.id }, 201)
  } catch (e) {
    return serverError(e)
  }
}
