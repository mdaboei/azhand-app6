import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import {ok, fail, requireAnyPanel, serverError } from '@/lib/api-helpers'

/**
 * دریافت فایل پیوست — واحد بیمه و ادمین
 *  - حالت عادی: دانلود (attachment)
 *  - ?mode=inline : نمایش داخل مرورگر برای چاپ (صفحهٔ چاپ پیوست این را در iframe/img نشان می‌دهد)
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY', 'MANAGEMENT')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const att = await db.insuranceAttachment.findUnique({
      where: { id },
      select: { data: true, mimeType: true, fileName: true },
    })
    if (!att) return fail('پیوست پیدا نشد', 404)

    const inline = req.nextUrl.searchParams.get('mode') === 'inline'
    const safeName = encodeURIComponent(att.fileName)
    return new NextResponse(new Uint8Array(att.data), {
      headers: {
        'Content-Type': att.mimeType,
        'Content-Disposition': inline
          ? `inline; filename="policy-file-${id}"; filename*=UTF-8''${safeName}`
          : `attachment; filename="policy-file-${id}"; filename*=UTF-8''${safeName}`,
        'Cache-Control': 'private, max-age=3600',
      },
    })
  } catch (e) {
    return serverError(e)
  }
}

/** حذف پیوست — واحد بیمه و ادمین */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await requireAnyPanel('MACHINERY')
  if ('res' in g) return g.res
  try {
    const { id } = await params
    const att = await db.insuranceAttachment.findUnique({ where: { id } })
    if (!att) return fail('پیوست پیدا نشد', 404)

    await db.insuranceAttachment.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return serverError(e)
  }
}
