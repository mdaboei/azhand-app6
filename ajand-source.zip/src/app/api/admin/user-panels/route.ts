import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, serverError } from '@/lib/api-helpers'
import { getUserPanelList, hasExplicitPanels, setUserPanels } from '@/lib/permissions'
import { PANELS, type Panel, type Role } from '@/lib/types'

/**
 * تخصیص ریزدانهٔ دسترسی هر کاربر — فقط ادمین:
 *  GET  → فهرست کاربران + بخش‌های فعال هرکدام (اختصاصی یا پیش‌فرض نقش)
 *  PUT  → { userId, panels: [...] } تخصیص اختصاصی | { userId, reset: true } بازگشت به پیش‌فرض نقش
 */
export async function GET(req: NextRequest) {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const userId = req.nextUrl.searchParams.get('userId')
    if (userId) {
      const user = await db.user.findUnique({
        where: { id: userId },
        select: { id: true, username: true, fullName: true, role: true },
      })
      if (!user) return fail('کاربر پیدا نشد', 404)
      return ok({
        panels: PANELS,
        user: {
          ...user,
          panels: await getUserPanelList(user.id, user.role as Role),
          isCustom: await hasExplicitPanels(user.id),
        },
      })
    }
    const users = await db.user.findMany({
      where: { role: { not: 'ADMIN' } },
      orderBy: [{ role: 'asc' }, { fullName: 'asc' }],
      select: { id: true, username: true, fullName: true, role: true, isActive: true },
    })
    const rows = await Promise.all(
      users.map(async (u) => ({
        ...u,
        panels: await getUserPanelList(u.id, u.role as Role),
        isCustom: await hasExplicitPanels(u.id),
      })),
    )
    return ok({ panels: PANELS, users: rows })
  } catch (e) {
    return serverError(e)
  }
}

export async function PUT(req: NextRequest) {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const body = await req.json().catch(() => null)
    const userId = body?.userId as string | undefined
    if (!userId) return fail('کاربر مشخص نشده است', 422)

    const user = await db.user.findUnique({ where: { id: userId } })
    if (!user) return fail('کاربر پیدا نشد', 404)
    if (user.role === 'ADMIN') return fail('دسترسی ادمین همیشه کامل است', 422)

    if (body?.reset === true) {
      await setUserPanels(userId, [], true)
      return ok({ saved: true, reset: true })
    }

    const panels = Array.isArray(body?.panels) ? body.panels : null
    if (!panels || panels.some((p: unknown) => !(PANELS as readonly string[]).includes(p as string))) {
      return fail('فهرست بخش‌ها نامعتبر است', 422)
    }
    await setUserPanels(userId, panels as Panel[])
    return ok({ saved: true })
  } catch (e) {
    return serverError(e)
  }
}
