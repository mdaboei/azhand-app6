import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, serverError } from '@/lib/api-helpers'
import { getPanelMap, setRolePanels } from '@/lib/permissions'
import { getRoleDefs, isValidRole } from '@/lib/roles'
import { PANELS, type Panel, type Role } from '@/lib/types'

/**
 * مدیریت دسترسی پنل‌ها — فقط ادمین:
 *  GET  → ماتریس کامل نقش × پنل + برچسب نقش‌ها + تعداد کاربران هر نقش
 *  PUT  → ذخیرهٔ پنل‌های یک نقش { role, panels: [...] }
 */
export async function GET() {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const [map, defs, counts] = await Promise.all([
      getPanelMap(),
      getRoleDefs(),
      db.user.groupBy({ by: ['role'], _count: { _all: true } }),
    ])
    const countMap: Record<string, number> = {}
    for (const c of counts) countMap[c.role] = c._count._all
    return ok({
      panels: PANELS,
      roles: defs.map((d) => d.key),
      roleLabels: Object.fromEntries(defs.map((d) => [d.key, d.label])),
      roleSystem: Object.fromEntries(defs.map((d) => [d.key, d.isSystem])),
      map,
      userCounts: countMap,
    })
  } catch (e) {
    return serverError(e)
  }
}

export async function PUT(req: NextRequest) {
  const g = await requireSession(['ADMIN'])
  if ('res' in g) return g.res
  try {
    const body = await req.json().catch(() => null)
    const role = body?.role as Role | string
    const panels = Array.isArray(body?.panels) ? body.panels : null
    if (!role || typeof role !== 'string' || !(await isValidRole(role))) {
      return fail('نقش نامعتبر است', 422)
    }
    if (!panels || panels.some((p: unknown) => !(PANELS as readonly string[]).includes(p as string))) {
      return fail('فهرست پنل‌ها نامعتبر است', 422)
    }
    await setRolePanels(role, panels as Panel[])
    return ok({ saved: true })
  } catch (e) {
    return serverError(e)
  }
}
