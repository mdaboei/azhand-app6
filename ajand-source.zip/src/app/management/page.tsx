'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  ArrowDownLeft, ArrowUpRight, Banknote, FileText, FolderKanban, Loader2, PiggyBank, Printer, UsersRound,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { ExportButton } from '@/components/export-button'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { BankAccountDTO, TransactionDTO, ProfitAccountDTO, ProjectDTO, type Role } from '@/lib/types'
import { faDigits, faMoney, faNum } from '@/lib/persian'
import { ReportsClient } from '../reports/reports-client'

export default function ManagementPage() {
  const [banks, setBanks] = useState<BankAccountDTO[] | null>(null)
  const [transactions, setTransactions] = useState<TransactionDTO[] | null>(null)
  const [profits, setProfits] = useState<ProfitAccountDTO[] | null>(null)
  const [projects, setProjects] = useState<ProjectDTO[] | null>(null)
  // سشن کاربر جاری — برای لایک/سوپرلایک داخل گزارش پروژه‌ها لازم است
  const [me, setMe] = useState<{ userId: string; role: string } | null>(null)

  useEffect(() => {
    ;(async () => {
      try {
        const [r1, r2, r3, r4, r5] = await Promise.all([
          fetch('/api/finance/banks'),
          fetch('/api/finance/transactions'),
          fetch('/api/finance/profit-accounts'),
          fetch('/api/projects'),
          fetch('/api/auth/me'),
        ])
        if (r1.ok) setBanks(await r1.json())
        if (r2.ok) setTransactions(await r2.json())
        if (r3.ok) setProfits(await r3.json())
        if (r4.ok) setProjects(await r4.json())
        if (r5.ok) setMe(((await r5.json()) as { user: { userId: string; role: string } }).user)
        if (!r1.ok || !r2.ok || !r3.ok || !r4.ok) toast.error('دریافت گزارش‌ها ناموفق بود')
      } catch {
        toast.error('ارتباط با سرور برقرار نشد')
        setBanks([]); setTransactions([]); setProfits([]); setProjects([])
      }
    })()
  }, [])

  const totalBalance = (banks ?? []).reduce((s, b) => s + b.balance, 0)
  const totalDebt = (profits ?? []).reduce((s, p) => s + p.stats.totalDebt, 0)
  const totalEmployees = (projects ?? []).reduce((s, p) => s + (p.employeeCount ?? 0), 0)

  return (
    <div className="space-y-4">
      {/* خلاصه کلی */}
      <section className="grid grid-cols-3 gap-3" aria-label="خلاصه کلی">
        <Card>
          <CardContent className="space-y-1 p-4 text-center">
            <Banknote className="mx-auto size-5 text-brand-600" />
            <p className="truncate text-sm font-bold">{faMoney(totalBalance)}</p>
            <p className="text-xs text-muted-foreground">موجودی کل بانک‌ها</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-1 p-4 text-center">
            <PiggyBank className="mx-auto size-5 text-emerald-600" />
            <p className="truncate text-sm font-bold">{faMoney(totalDebt)}</p>
            <p className="text-xs text-muted-foreground">بدهی حساب‌های سوددار</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-1 p-4 text-center">
            <UsersRound className="mx-auto size-5 text-amber-600" />
            <p className="text-lg font-bold">{faDigits(totalEmployees)}</p>
            <p className="text-xs text-muted-foreground">کل کارمندان</p>
          </CardContent>
        </Card>
      </section>

      <Tabs defaultValue="finance">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3">
          <TabsTrigger value="finance" className="gap-1"><Banknote className="size-4" /> گزارش مالی</TabsTrigger>
          <TabsTrigger value="hr" className="gap-1"><FolderKanban className="size-4" /> کارمند در پروژه</TabsTrigger>
          <TabsTrigger value="reports" className="gap-1"><FileText className="size-4" /> گزارش پروژه‌ها</TabsTrigger>
        </TabsList>

        {/* ─── گزارش مالی ─── */}
        <TabsContent value="finance" className="mt-4 space-y-4">
          {/* نوار ابزار خروجی اکسل و چاپ */}
          <div className="flex flex-wrap gap-2" aria-label="ابزارهای خروجی گزارش مالی">
            <ExportButton url="/api/finance/banks/export" filename="banks.xlsx" label="خروجی اکسل بانک‌ها" />
            <ExportButton url="/api/finance/transactions/export" filename="transactions.xlsx" label="خروجی اکسل تراکنش‌ها" />
            <Button asChild variant="outline" size="sm" className="gap-1" aria-label="چاپ تراکنش‌ها">
              <Link href="/print/transactions">
                <Printer className="size-4" aria-hidden /> چاپ تراکنش‌ها
              </Link>
            </Button>
          </div>

          <section aria-label="موجودی بانک‌ها" className="space-y-2">
            <h3 className="text-sm font-bold">موجودی بانک‌ها</h3>
            {!banks ? (
              <Skeleton className="h-24 w-full" />
            ) : banks.length === 0 ? (
              <Card><CardContent className="py-6 text-center text-sm text-muted-foreground">حسابی ثبت نشده است</CardContent></Card>
            ) : (
              banks.map((b) => (
                <Card key={b.id}>
                  <CardContent className="flex items-center gap-3 p-4">
                    <Banknote className="size-5 text-brand-600" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{b.name}</p>
                      {b.accountNumber && <p className="dir-ltr text-xs text-muted-foreground">{b.accountNumber}</p>}
                    </div>
                    <p className="text-sm font-bold">{faMoney(b.balance)}</p>
                  </CardContent>
                </Card>
              ))
            )}
          </section>

          <section aria-label="ریز دریافت و پرداخت" className="space-y-2">
            <h3 className="text-sm font-bold">آخرین دریافت و پرداخت‌ها</h3>
            <Card>
              <CardContent className="p-0">
                {!transactions ? (
                  <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> در حال بارگذاری…</div>
                ) : transactions.length === 0 ? (
                  <p className="py-8 text-center text-sm text-muted-foreground">تراکنشی ثبت نشده است</p>
                ) : (
                  <div className="max-h-80 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-right">تاریخ</TableHead>
                          <TableHead className="text-right">بابت</TableHead>
                          <TableHead className="text-center">نوع</TableHead>
                          <TableHead className="text-left">مبلغ</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transactions.slice(0, 15).map((t) => (
                          <TableRow key={t.id}>
                            <TableCell className="text-right">{faDigits(t.date)}</TableCell>
                            <TableCell className="text-right text-xs">{t.title}</TableCell>
                            <TableCell className="text-center">
                              {t.kind === 'RECEIVE' ? (
                                <Badge className="gap-1 bg-emerald-600 hover:bg-emerald-600"><ArrowDownLeft className="size-3" /> دریافت</Badge>
                              ) : (
                                <Badge variant="destructive" className="gap-1"><ArrowUpRight className="size-3" /> پرداخت</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-left font-medium">{faNum(t.amount)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          <section aria-label="حساب‌های سوددار" className="space-y-2">
            <h3 className="text-sm font-bold">حساب‌های سوددار اشخاص</h3>
            {!profits ? (
              <Skeleton className="h-20 w-full" />
            ) : profits.length === 0 ? (
              <Card><CardContent className="py-6 text-center text-sm text-muted-foreground">حساب سودداری ثبت نشده است</CardContent></Card>
            ) : (
              profits.map((p) => (
                <Card key={p.id}>
                  <CardContent className="flex items-center gap-3 p-4">
                    <PiggyBank className="size-5 text-emerald-600" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{p.personName}</p>
                      <p className="text-xs text-muted-foreground">مانده اصل: {faMoney(p.stats.currentPrincipal)} — سود معوق: {faMoney(p.stats.unpaidInterest)}</p>
                    </div>
                    <p className="text-sm font-bold text-red-600 dark:text-red-400">{faMoney(p.stats.totalDebt)}</p>
                  </CardContent>
                </Card>
              ))
            )}
          </section>
        </TabsContent>

        {/* ─── کارمند در پروژه ─── */}
        <TabsContent value="hr" className="mt-4 space-y-2">
          <h3 className="text-sm font-bold">تعداد کارمند در هر پروژه</h3>
          <p className="text-xs text-muted-foreground">
            این آمار از اطلاعات پرسنلی که واحد منابع انسانی ثبت می‌کند گرفته می‌شود.
          </p>
          {!projects ? (
            <Skeleton className="h-24 w-full" />
          ) : projects.length === 0 ? (
            <Card><CardContent className="py-6 text-center text-sm text-muted-foreground">پروژه‌ای ثبت نشده است</CardContent></Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">پروژه</TableHead>
                      <TableHead className="text-right">توضیح</TableHead>
                      <TableHead className="text-center">تعداد کارمند</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.map((p) => (
                      <TableRow key={p.id}>
                        <TableCell className="text-right font-medium">
                          {p.name}
                          {!p.isActive && <Badge variant="secondary" className="mr-2">غیرفعال</Badge>}
                        </TableCell>
                        <TableCell className="text-right text-xs text-muted-foreground">{p.note || '—'}</TableCell>
                        <TableCell className="text-center">
                          <Badge className="bg-brand-600 hover:bg-brand-600">{faDigits(p.employeeCount ?? 0)}</Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ─── گزارش پروژه‌ها (فید پست‌های مدیران پروژه) ─── */}
        <TabsContent value="reports" className="mt-4">
          {me ? (
            <ReportsClient myUserId={me.userId} myRole={me.role as Role} />
          ) : (
            <Skeleton className="h-40 w-full" />
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
