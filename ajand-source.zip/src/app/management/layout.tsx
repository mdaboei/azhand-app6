import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function ManagementLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('MANAGEMENT')
  return (
    <PanelShell fullName={user.fullName}
      roleLabel={roleLabel}
      role={session.role as 'MANAGEMENT' | 'ADMIN'} unitLabel="گزارش‌های مدیریتی" panels={panels}>
      {children}
    </PanelShell>
  )
}
