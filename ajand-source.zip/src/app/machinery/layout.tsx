import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function MachineryLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('MACHINERY')

  return (
    <PanelShell fullName={user.fullName}
      roleLabel={roleLabel}
      role={session.role as 'MACHINERY' | 'ADMIN'} unitLabel={session.role === 'ADMIN' ? 'ماشین‌آلات و بیمه' : null} panels={panels}>
      {children}
    </PanelShell>
  )
}
