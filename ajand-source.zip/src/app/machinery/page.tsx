'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  Calendar, CalendarClock, ChevronDown, FileSignature, FileText, Files,
  Fuel, Loader2, Paperclip, Pencil, Plus, Printer, Save, ShieldCheck, StickyNote,
  Trash2, Tractor, Upload,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ExportButton } from '@/components/export-button'
import { daysUntilJalali, faNum, formatJalaliDateInput, jalaliToday } from '@/lib/persian'
import type {
  FuelCardAttachmentDTO, FuelCardDTO, InsuranceTypeDTO, MachineAttachmentDTO,
  MachineDTO, PolicyActionDTO, PolicyAttachmentDTO, PolicyDTO,
} from '@/lib/types'

interface PolicyDetail extends PolicyDTO {
  actions: PolicyActionDTO[]
  attachments: PolicyAttachmentDTO[]
}

/** کارمند و پروژه برای تخصیص تحویل کارت سوخت */
interface DirectoryEmployee {
  id: string
  fullName: string
  role: string
  project?: { name: string } | null
}
interface DirectoryProject {
  id: string
  name: string
}

/** MachineDTO به‌همراه «شماره دستگاه» — ردیف‌های قدیمی ممکن است این فیلد را نداشته باشند */
type MachineRow = MachineDTO & { deviceNumber?: string | null }

/**
 * رنگ وضعیت بیمه‌نامه:
 * لغو → خاکستری | منقضی → قرمز | ۵ روز یا کمتر مانده → زرد | سالم → سبز
 */
function statusOf(p: { status: string; endDate: string }): { label: string; className: string } {
  if (p.status === 'CANCELED') {
    return {
      label: 'لغو شده',
      className: 'border-zinc-300 bg-zinc-100 text-zinc-600 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-300',
    }
  }
  const days = daysUntilJalali(p.endDate)
  if (Number.isFinite(days) && days < 0) {
    return {
      label: 'منقضی',
      className: 'border-red-200 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950 dark:text-red-300',
    }
  }
  if (Number.isFinite(days) && days <= 5) {
    const label = days === 0 ? 'امروز آخرین روز' : `${faNum(days)} روز مانده`
    return {
      label,
      className: 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300',
    }
  }
  return {
    label: 'فعال',
    className: 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-300',
  }
}

const ACTION_LABEL: Record<string, string> = { RENEWAL: 'تمدید (سابقه)', ENDORSEMENT: 'الحاقیه' }

/**
 * پنل ماشین‌آلات و بیمه — واحد یکپارچه:
 *  تب ۱: ناوگان (ثبت/ویرایش ماشین با نام صاحب خودرو و شماره شاسی + بیمه‌های هر ماشین
 *        با الحاقیه و پیوست مجزا + پیوست سند ماشین + کارت سوخت با تحویل کارمند/پروژه و رسید تحویل)
 *  تب ۲: همه بیمه‌نامه‌ها (فیلتر + خروجی اکسل + چاپ)
 *  تب ۳: نوع بیمه‌ها
 */
export default function MachineryPage() {
  // ─── ماشین‌ها ─────────────────────────────────────────────────────
  const [machines, setMachines] = useState<MachineRow[]>([])
  const [loading, setLoading] = useState(true)
  const [listError, setListError] = useState('')

  const [formOpen, setFormOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [fName, setFName] = useState('')
  const [fDevice, setFDevice] = useState('')
  const [fModel, setFModel] = useState('')
  const [fPlate, setFPlate] = useState('')
  const [fOwner, setFOwner] = useState('')
  const [fChassis, setFChassis] = useState('')
  const [fYear, setFYear] = useState('')
  const [fNote, setFNote] = useState('')
  const [fActive, setFActive] = useState(true)
  const [saving, setSaving] = useState(false)

  const [deleteTarget, setDeleteTarget] = useState<MachineDTO | null>(null)
  const [deleting, setDeleting] = useState(false)

  const loadMachines = useCallback(async () => {
    try {
      setListError('')
      const res = await fetch('/api/machines')
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        setListError(data.error || 'دریافت لیست ماشین‌ها ناموفق بود')
        return
      }
      setMachines(await res.json())
    } catch {
      setListError('ارتباط با سرور برقرار نشد')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadMachines() }, [loadMachines])

  function openCreate() {
    setEditingId(null)
    setFName(''); setFDevice(''); setFModel(''); setFPlate(''); setFOwner(''); setFChassis(''); setFYear(''); setFNote('')
    setFActive(true)
    setFormOpen(true)
  }

  function openEdit(m: MachineRow) {
    setEditingId(m.id)
    setFName(m.name)
    setFDevice(m.deviceNumber ?? '')
    setFModel(m.model ?? '')
    setFPlate(m.plateNumber ?? '')
    setFOwner(m.ownerName ?? '')
    setFChassis(m.chassisNumber ?? '')
    setFYear(m.year ?? '')
    setFNote(m.note ?? '')
    setFActive(m.status === 'ACTIVE')
    setFormOpen(true)
  }

  async function saveMachine() {
    if (!fName.trim()) { toast.error('نام ماشین را وارد کنید'); return }
    if (!fDevice.trim()) { toast.error('شماره دستگاه را وارد کنید'); return }
    setSaving(true)
    try {
      const body = JSON.stringify({
        name: fName.trim(),
        deviceNumber: fDevice.trim(),
        model: fModel.trim() || null,
        plateNumber: fPlate.trim() || null,
        ownerName: fOwner.trim() || null,
        chassisNumber: fChassis.trim() || null,
        year: fYear.trim() || null,
        status: fActive ? 'ACTIVE' : 'INACTIVE',
        note: fNote.trim() || null,
      })
      const res = editingId
        ? await fetch(`/api/machines/${editingId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body })
        : await fetch('/api/machines', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success(editingId ? 'ماشین ویرایش شد' : 'ماشین ثبت شد — حالا می‌توانید برایش بیمه ثبت کنید')
      setFormOpen(false)
      await loadMachines()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSaving(false)
    }
  }

  async function deleteMachine() {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/machines/${deleteTarget.id}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف ناموفق بود'); return }
      toast.success(`ماشین «${deleteTarget.name}» حذف شد`)
      setDeleteTarget(null)
      await loadMachines()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setDeleting(false)
    }
  }

  // ─── دایرکتوری کارکنان و پروژه‌ها (برای تخصیص کارت سوخت) ─────────
  const [employees, setEmployees] = useState<DirectoryEmployee[]>([])
  const [projects, setProjects] = useState<DirectoryProject[]>([])

  const loadDirectory = useCallback(async () => {
    try {
      const res = await fetch('/api/machines/directory')
      if (!res.ok) return
      const data = await res.json()
      setEmployees(data.employees ?? [])
      setProjects(data.projects ?? [])
    } catch {
      // بی‌صدا — لیست‌های انتخابی خالی می‌مانند
    }
  }, [])

  useEffect(() => { loadDirectory() }, [loadDirectory])

  // ─── پیوست سند ماشین (برگ سبز، سند مالکیت و…) ────────────────────
  const [machineAtts, setMachineAtts] = useState<MachineAttachmentDTO[]>([])
  const [machineAttsLoading, setMachineAttsLoading] = useState(false)
  const [machineFile, setMachineFile] = useState<File | null>(null)
  const [machineUploading, setMachineUploading] = useState(false)

  const loadMachineAtts = useCallback(async (machineId: string) => {
    setMachineAttsLoading(true)
    try {
      const res = await fetch(`/api/machines/${machineId}/attachments`)
      if (res.ok) setMachineAtts(await res.json())
      else setMachineAtts([])
    } catch {
      setMachineAtts([])
    } finally {
      setMachineAttsLoading(false)
    }
  }, [])

  async function uploadMachineAtt() {
    if (!detailMachine || !machineFile) { toast.error('فایل سند را انتخاب کنید'); return }
    setMachineUploading(true)
    try {
      const form = new FormData()
      form.append('file', machineFile)
      const res = await fetch(`/api/machines/${detailMachine.id}/attachments`, { method: 'POST', body: form })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'بارگذاری ناموفق بود'); return }
      toast.success('سند ماشین بارگذاری شد')
      setMachineFile(null)
      await loadMachineAtts(detailMachine.id)
      await loadMachines()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setMachineUploading(false)
    }
  }

  async function deleteMachineAtt(attId: string) {
    if (!detailMachine) return
    try {
      const res = await fetch(`/api/machines/${detailMachine.id}/attachments/${attId}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف پیوست ناموفق بود'); return }
      toast.success('پیوست سند حذف شد')
      await loadMachineAtts(detailMachine.id)
      await loadMachines()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  // ─── کارت سوخت ماشین (تحویل به کارمند/پروژه + رسید تحویل) ────────
  const [fuelCard, setFuelCard] = useState<FuelCardDTO | null>(null)
  const [fcLoading, setFcLoading] = useState(false)
  const [fcNumber, setFcNumber] = useState('')
  const [fcHolder, setFcHolder] = useState('')
  const [fcProject, setFcProject] = useState('')
  const [fcDate, setFcDate] = useState('')
  const [fcNote, setFcNote] = useState('')
  const [fcSaving, setFcSaving] = useState(false)
  const [fcFile, setFcFile] = useState<File | null>(null)
  const [fcUploading, setFcUploading] = useState(false)
  const [fcDeleteOpen, setFcDeleteOpen] = useState(false)
  const [fcDeleting, setFcDeleting] = useState(false)

  const loadFuelCard = useCallback(async (machineId: string) => {
    setFcLoading(true)
    try {
      const res = await fetch(`/api/machines/${machineId}/fuel-card`)
      if (!res.ok) { setFuelCard(null); return }
      const card: FuelCardDTO | null = await res.json()
      setFuelCard(card)
      setFcNumber(card?.cardNumber ?? '')
      setFcHolder(card?.holderId ?? '')
      setFcProject(card?.projectId ?? '')
      setFcDate(card?.assignedAt ?? '')
      setFcNote(card?.note ?? '')
    } catch {
      setFuelCard(null)
    } finally {
      setFcLoading(false)
    }
  }, [])

  function resetFuelCardForm() {
    setFuelCard(null)
    setFcNumber(''); setFcHolder(''); setFcProject(''); setFcDate(''); setFcNote('')
    setFcFile(null)
  }

  async function saveFuelCard() {
    if (!detailMachine) return
    if (!fcNumber.trim()) { toast.error('شماره کارت سوخت را وارد کنید'); return }
    setFcSaving(true)
    try {
      const res = await fetch(`/api/machines/${detailMachine.id}/fuel-card`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cardNumber: fcNumber.trim(),
          holderId: fcHolder || null,
          projectId: fcProject || null,
          assignedAt: fcDate.trim() || null,
          note: fcNote.trim() || null,
        }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت کارت سوخت ناموفق بود'); return }
      toast.success('کارت سوخت ذخیره شد')
      setFuelCard(data)
      await loadMachines()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setFcSaving(false)
    }
  }

  async function uploadFuelReceipt() {
    if (!detailMachine) return
    if (!fuelCard) { toast.error('اول کارت سوخت را ذخیره کنید، بعد رسید تحویل را بارگذاری کنید'); return }
    if (!fcFile) { toast.error('فایل رسید را انتخاب کنید'); return }
    setFcUploading(true)
    try {
      const form = new FormData()
      form.append('file', fcFile)
      const res = await fetch(`/api/machines/${detailMachine.id}/fuel-card/attachments`, { method: 'POST', body: form })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'بارگذاری ناموفق بود'); return }
      toast.success('رسید تحویل بارگذاری شد')
      setFcFile(null)
      await loadFuelCard(detailMachine.id)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setFcUploading(false)
    }
  }

  async function deleteFuelReceipt(att: FuelCardAttachmentDTO) {
    if (!detailMachine) return
    try {
      const res = await fetch(`/api/machines/${detailMachine.id}/fuel-card/attachments/${att.id}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف رسید ناموفق بود'); return }
      toast.success('رسید حذف شد')
      await loadFuelCard(detailMachine.id)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  async function deleteFuelCard() {
    if (!detailMachine || !fuelCard) return
    setFcDeleting(true)
    try {
      const res = await fetch(`/api/machines/${detailMachine.id}/fuel-card`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف کارت سوخت ناموفق بود'); return }
      toast.success('کارت سوخت و رسیدهای آن حذف شد')
      setFcDeleteOpen(false)
      resetFuelCardForm()
      await loadMachines()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setFcDeleting(false)
    }
  }

  // ─── نوع بیمه‌ها ──────────────────────────────────────────────────
  const [types, setTypes] = useState<InsuranceTypeDTO[]>([])
  const [typeOpen, setTypeOpen] = useState(false)
  const [editingTypeId, setEditingTypeId] = useState<string | null>(null)
  const [tName, setTName] = useState('')
  const [tNote, setTNote] = useState('')
  const [savingType, setSavingType] = useState(false)
  const [deleteTypeTarget, setDeleteTypeTarget] = useState<InsuranceTypeDTO | null>(null)
  const [deletingType, setDeletingType] = useState(false)

  const loadTypes = useCallback(async () => {
    try {
      const rt = await fetch('/api/insurance/types')
      setTypes(rt.ok ? await rt.json() : [])
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }, [])

  useEffect(() => { loadTypes() }, [loadTypes])

  function openTypeCreate() {
    setEditingTypeId(null); setTName(''); setTNote(''); setTypeOpen(true)
  }
  function openTypeEdit(t: InsuranceTypeDTO) {
    setEditingTypeId(t.id); setTName(t.name); setTNote(t.note ?? ''); setTypeOpen(true)
  }

  async function saveType() {
    if (!tName.trim()) { toast.error('نوع بیمه را وارد کنید'); return }
    setSavingType(true)
    try {
      const body = JSON.stringify({ name: tName.trim(), note: tNote.trim() || null })
      const res = editingTypeId
        ? await fetch(`/api/insurance/types/${editingTypeId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body })
        : await fetch('/api/insurance/types', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success(editingTypeId ? 'نوع بیمه ویرایش شد' : 'نوع بیمه اضافه شد')
      setTypeOpen(false)
      await loadTypes()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSavingType(false)
    }
  }

  async function deleteType() {
    if (!deleteTypeTarget) return
    setDeletingType(true)
    try {
      const res = await fetch(`/api/insurance/types/${deleteTypeTarget.id}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف ناموفق بود'); return }
      toast.success(`نوع «${deleteTypeTarget.name}» حذف شد`)
      setDeleteTypeTarget(null)
      await loadTypes()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setDeletingType(false)
    }
  }

  // ─── دیالوگ جزئیات ماشین (بیمه‌نامه‌های آن ماشین) ─────────────────
  const [detailMachine, setDetailMachine] = useState<MachineRow | null>(null)
  const [machinePolicies, setMachinePolicies] = useState<PolicyDTO[]>([])
  const [policiesLoading, setPoliciesLoading] = useState(false)
  const [focusPolicyId, setFocusPolicyId] = useState<string | null>(null)

  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [detail, setDetail] = useState<PolicyDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)

  const loadMachinePolicies = useCallback(async (machineId: string) => {
    setPoliciesLoading(true)
    try {
      const res = await fetch(`/api/insurance/policies?machineId=${machineId}`)
      if (res.ok) setMachinePolicies(await res.json())
      else toast.error('دریافت بیمه‌نامه‌ها ناموفق بود')
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setPoliciesLoading(false)
    }
  }, [])

  const loadDetail = useCallback(async (id: string) => {
    setDetailLoading(true)
    try {
      const res = await fetch(`/api/insurance/policies/${id}`)
      if (!res.ok) { toast.error('دریافت جزئیات ناموفق بود'); return }
      setDetail(await res.json())
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setDetailLoading(false)
    }
  }, [])

  function openMachineDetail(m: MachineRow, focusPolicy?: string) {
    setDetailMachine(m)
    setMachinePolicies([])
    setDetail(null)
    setFile(null)
    setMachineFile(null)
    setFocusPolicyId(focusPolicy ?? null)
    setExpandedId(focusPolicy ?? null)
    if (focusPolicy) loadDetail(focusPolicy)
    loadMachinePolicies(m.id)
    loadMachineAtts(m.id)
    loadFuelCard(m.id)
  }

  function closeMachineDetail() {
    setDetailMachine(null)
    setMachinePolicies([])
    setDetail(null)
    setExpandedId(null)
    setFocusPolicyId(null)
    setFile(null)
    setMachineFile(null)
    setMachineAtts([])
    resetFuelCardForm()
  }

  function toggleExpand(id: string, open: boolean) {
    if (open) {
      setExpandedId(id)
      setDetail(null)
      setFile(null)
      loadDetail(id)
    } else {
      setExpandedId(null)
      setDetail(null)
      setFile(null)
    }
  }

  // ─── ثبت بیمه‌نامه برای ماشین ─────────────────────────────────────
  const [policyOpen, setPolicyOpen] = useState(false)
  const [savingPolicy, setSavingPolicy] = useState(false)
  const [pTypeId, setPTypeId] = useState('')
  const [pCompany, setPCompany] = useState('')
  const [pNumber, setPNumber] = useState('')
  const [pStart, setPStart] = useState('')
  const [pEnd, setPEnd] = useState('')
  const [pNote, setPNote] = useState('')

  function openPolicyCreate() {
    if (!detailMachine) return
    setPTypeId(''); setPCompany(''); setPNumber('')
    setPStart(jalaliToday()); setPEnd(''); setPNote('')
    setPolicyOpen(true)
  }

  async function savePolicy() {
    if (!detailMachine) return
    if (!pTypeId) { toast.error('نوع بیمه را انتخاب کنید'); return }
    setSavingPolicy(true)
    try {
      const res = await fetch('/api/insurance/policies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          machineId: detailMachine.id,
          typeId: pTypeId,
          company: pCompany.trim(),
          policyNumber: pNumber.trim(),
          startDate: pStart.trim(),
          endDate: pEnd.trim(),
          note: pNote.trim() || null,
        }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت بیمه‌نامه ناموفق بود'); return }
      toast.success('بیمه‌نامه ثبت شد — می‌توانید الحاقیه و پیوست اضافه کنید')
      setPolicyOpen(false)
      await Promise.all([loadMachinePolicies(detailMachine.id), loadMachines()])
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSavingPolicy(false)
    }
  }

  // ─── الحاقیه ──────────────────────────────────────────────────────
  const [endorseTarget, setEndorseTarget] = useState<PolicyDTO | null>(null)
  const [eDate, setEDate] = useState('')
  const [eNote, setENote] = useState('')
  const [savingEndorse, setSavingEndorse] = useState(false)

  function openEndorse(p: PolicyDTO) {
    setEndorseTarget(p)
    setEDate(jalaliToday())
    setENote('')
  }

  async function submitEndorsement() {
    if (!endorseTarget) return
    if (!eDate.trim()) { toast.error('تاریخ الحاقیه را وارد کنید'); return }
    setSavingEndorse(true)
    try {
      const res = await fetch(`/api/insurance/policies/${endorseTarget.id}/actions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'ENDORSEMENT', date: eDate.trim(), amount: null, note: eNote.trim() || null }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت الحاقیه ناموفق بود'); return }
      toast.success('الحاقیه ثبت شد')
      setEndorseTarget(null)
      if (expandedId === endorseTarget.id) await loadDetail(endorseTarget.id)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSavingEndorse(false)
    }
  }

  // ─── حذف بیمه‌نامه ────────────────────────────────────────────────
  const [deletePolicyTarget, setDeletePolicyTarget] = useState<PolicyDTO | null>(null)
  const [deletingPolicy, setDeletingPolicy] = useState(false)

  async function deletePolicy() {
    if (!deletePolicyTarget) return
    setDeletingPolicy(true)
    try {
      const res = await fetch(`/api/insurance/policies/${deletePolicyTarget.id}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف ناموفق بود'); return }
      toast.success('بیمه‌نامه حذف شد')
      setDeletePolicyTarget(null)
      setExpandedId(null)
      setDetail(null)
      if (detailMachine) {
        await Promise.all([loadMachinePolicies(detailMachine.id), loadMachines()])
      }
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setDeletingPolicy(false)
    }
  }

  // ─── پیوست‌ها (هر بیمه‌نامه پیوست مجزای خودش) ─────────────────────
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)

  async function uploadAttachment() {
    if (!expandedId || !file) { toast.error('فایل را انتخاب کنید'); return }
    setUploading(true)
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch(`/api/insurance/policies/${expandedId}/attachments`, { method: 'POST', body: form })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'بارگذاری ناموفق بود'); return }
      toast.success('پیوست بارگذاری شد')
      setFile(null)
      await loadDetail(expandedId)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setUploading(false)
    }
  }

  async function deleteAttachment(attId: string) {
    try {
      const res = await fetch(`/api/insurance/attachments/${attId}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف پیوست ناموفق بود'); return }
      toast.success('پیوست حذف شد')
      if (expandedId) await loadDetail(expandedId)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  // ─── تب «همه بیمه‌نامه‌ها» ────────────────────────────────────────
  const [allPolicies, setAllPolicies] = useState<PolicyDTO[] | null>(null)
  const [fMachine, setFMachine] = useState('all')
  const [fStatus, setFStatus] = useState('all')

  const loadAllPolicies = useCallback(async (machineId: string, status: string) => {
    try {
      const qs = new URLSearchParams()
      if (machineId !== 'all') qs.set('machineId', machineId)
      if (status !== 'all') qs.set('status', status)
      const res = await fetch(`/api/insurance/policies${qs.size ? `?${qs.toString()}` : ''}`)
      if (res.ok) setAllPolicies(await res.json())
      else setAllPolicies([])
    } catch {
      setAllPolicies([])
    }
  }, [])

  useEffect(() => { loadAllPolicies(fMachine, fStatus) }, [loadAllPolicies, fMachine, fStatus])

  const filterQs = new URLSearchParams()
  if (fMachine !== 'all') filterQs.set('machineId', fMachine)
  if (fStatus !== 'all') filterQs.set('status', fStatus)

  function machineById(id: string): MachineRow | undefined {
    return machines.find((m) => m.id === id)
  }

  // ─── رندر ─────────────────────────────────────────────────────────
  return (
    <section aria-label="پنل ماشین‌آلات و بیمه">
      <Tabs defaultValue="machines" className="w-full gap-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="machines">ناوگان و بیمه</TabsTrigger>
          <TabsTrigger value="policies">همه بیمه‌نامه‌ها</TabsTrigger>
          <TabsTrigger value="types">نوع بیمه‌ها</TabsTrigger>
        </TabsList>

        {/* ─── تب ناوگان و بیمه ─── */}
        <TabsContent value="machines" className="mt-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">
              {loading ? 'در حال بارگذاری…' : `${faNum(machines.length)} ماشین در فهرست — برای هر ماشین چند بیمه‌نامه (انواع مختلف) با الحاقیه و پیوست مجزا`}
            </p>
            <Button onClick={openCreate} className="bg-brand-600 text-white hover:bg-brand-700">
              <Plus className="size-4" aria-hidden />
              ثبت ماشین
            </Button>
          </div>

          {loading ? (
            <div className="flex justify-center py-16" role="status" aria-label="در حال بارگذاری">
              <Loader2 className="size-6 animate-spin text-brand-600" />
            </div>
          ) : listError ? (
            <Card>
              <CardContent className="p-4 text-center text-sm text-red-600">{listError}</CardContent>
            </Card>
          ) : machines.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-2 p-8 text-center">
                <Tractor className="size-8 text-brand-600/60" aria-hidden />
                <p className="text-sm font-medium">هنوز ماشینی ثبت نشده است</p>
                <p className="text-xs text-muted-foreground">اولین ماشین ناوگان را با دکمه «ثبت ماشین» اضافه کنید؛ بعد از ثبت، دکمه «بیمه‌ها» برایش فعال می‌شود</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {machines.map((m) => (
                <Card key={m.id} className="border-brand-100 dark:border-brand-900/60">
                  <CardContent className="space-y-3 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <h2 className="flex flex-wrap items-center gap-1.5 font-bold leading-6">
                        {m.name}
                        {m.deviceNumber && (
                          <span className="rounded bg-brand-50 px-1.5 py-0.5 text-xs font-bold text-brand-700" dir="ltr">
                            {m.deviceNumber}
                          </span>
                        )}
                      </h2>
                      {m.status === 'ACTIVE' ? (
                        <Badge className="border border-brand-200 bg-brand-50 text-brand-700 dark:border-brand-900 dark:bg-brand-950 dark:text-brand-300">
                          فعال
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="border-zinc-300 text-zinc-500 dark:border-zinc-700 dark:text-zinc-400">
                          خارج از سرویس
                        </Badge>
                      )}
                    </div>

                    <dl className="space-y-1.5 text-sm">
                      <div className="flex items-center justify-between gap-2">
                        <dt className="text-muted-foreground">شماره دستگاه</dt>
                        <dd className="font-medium" dir="ltr">{m.deviceNumber || '—'}</dd>
                      </div>
                      {m.ownerName && (
                        <div className="flex items-center justify-between gap-2">
                          <dt className="text-muted-foreground">صاحب خودرو</dt>
                          <dd className="font-medium">{m.ownerName}</dd>
                        </div>
                      )}
                      {m.chassisNumber && (
                        <div className="flex items-center justify-between gap-2">
                          <dt className="text-muted-foreground">شماره شاسی</dt>
                          <dd className="font-medium" dir="ltr">{m.chassisNumber}</dd>
                        </div>
                      )}
                      {m.model && (
                        <div className="flex items-center justify-between gap-2">
                          <dt className="text-muted-foreground">مدل</dt>
                          <dd className="font-medium">{m.model}</dd>
                        </div>
                      )}
                      {m.plateNumber && (
                        <div className="flex items-center justify-between gap-2">
                          <dt className="text-muted-foreground">پلاک/شناسه</dt>
                          <dd className="font-medium" dir="rtl">{m.plateNumber}</dd>
                        </div>
                      )}
                      {m.year && (
                        <div className="flex items-center justify-between gap-2">
                          <dt className="sr-only">سال ساخت</dt>
                          <dd className="flex items-center gap-1 text-muted-foreground">
                            <Calendar className="size-3.5" aria-hidden />
                            سال ساخت {faNum(m.year)}
                          </dd>
                        </div>
                      )}
                    </dl>

                    {/* خلاصه کارت سوخت — تحویل به کدام کارمند و کدام پروژه */}
                    {m.fuelCard && (
                      <div className="flex items-start gap-1.5 rounded-lg bg-brand-50/70 px-2.5 py-2 text-xs dark:bg-brand-950/40">
                        <Fuel className="mt-0.5 size-3.5 shrink-0 text-brand-600" aria-hidden />
                        <span className="min-w-0 leading-5">
                          <span className="font-bold text-brand-700 dark:text-brand-300">کارت سوخت {m.fuelCard.cardNumber}</span>
                          {m.fuelCard.holderName ? (
                            <>
                              {' '}— تحویل به <span className="font-medium">{m.fuelCard.holderName}</span>
                              {m.fuelCard.projectName ? ` (پروژه ${m.fuelCard.projectName})` : ''}
                            </>
                          ) : (
                            ' — در انبار (تحویل نشده)'
                          )}
                          {m.fuelCard.assignedAt ? ` — ${m.fuelCard.assignedAt}` : ''}
                        </span>
                      </div>
                    )}

                    {m.note && (
                      <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
                        <StickyNote className="mt-0.5 size-3.5 shrink-0" aria-hidden />
                        <span className="line-clamp-2">{m.note}</span>
                      </p>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-2 border-t pt-3">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {(m.activePolicyCount ?? 0) > 0 ? (
                          <Badge variant="outline" className="gap-1 border-brand-200 text-brand-700 dark:border-brand-900 dark:text-brand-300">
                            <ShieldCheck className="size-3.5" aria-hidden />
                            {faNum(m.activePolicyCount ?? 0)} بیمه‌نامه فعال
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">بدون بیمه‌نامه فعال</span>
                        )}
                        {(m.attachmentsCount ?? 0) > 0 && (
                          <Badge variant="outline" className="gap-1 border-zinc-300 text-zinc-600 dark:border-zinc-700 dark:text-zinc-300">
                            <Paperclip className="size-3.5" aria-hidden />
                            {faNum(m.attachmentsCount ?? 0)} سند
                          </Badge>
                        )}
                        {m.fuelCard && (
                          <Badge variant="outline" className="gap-1 border-amber-200 text-amber-700 dark:border-amber-900 dark:text-amber-300">
                            <Fuel className="size-3.5" aria-hidden />
                            کارت سوخت
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="outline" size="sm"
                          className="border-brand-200 text-brand-700 hover:bg-brand-50 dark:border-brand-900 dark:text-brand-300 dark:hover:bg-brand-950"
                          aria-label={`جزئیات ماشین ${m.name}`}
                          onClick={() => openMachineDetail(m)}
                        >
                          <ShieldCheck className="size-4" aria-hidden />
                          جزئیات و بیمه
                        </Button>
                        <Button
                          variant="ghost" size="icon" className="size-8"
                          aria-label={`ویرایش ماشین ${m.name}`}
                          onClick={() => openEdit(m)}
                        >
                          <Pencil className="size-4" aria-hidden />
                        </Button>
                        <Button
                          variant="ghost" size="icon" className="size-8 text-red-600 hover:text-red-700"
                          aria-label={`حذف ماشین ${m.name}`}
                          onClick={() => setDeleteTarget(m)}
                        >
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ─── تب همه بیمه‌نامه‌ها ─── */}
        <TabsContent value="policies" className="mt-4 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <Select value={fMachine} onValueChange={setFMachine}>
              <SelectTrigger className="h-9 w-[170px]" aria-label="فیلتر ماشین">
                <SelectValue placeholder="همه ماشین‌ها" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه ماشین‌ها</SelectItem>
                {machines.map((m) => (
                  <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={fStatus} onValueChange={setFStatus}>
              <SelectTrigger className="h-9 w-[150px]" aria-label="فیلتر وضعیت">
                <SelectValue placeholder="همه وضعیت‌ها" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="ACTIVE">فعال</SelectItem>
                <SelectItem value="EXPIRED">منقضی</SelectItem>
                <SelectItem value="CANCELED">لغو شده</SelectItem>
              </SelectContent>
            </Select>
            <div className="grow" />
            <ExportButton url={`/api/insurance/policies/export${filterQs.size ? `?${filterQs.toString()}` : ''}`} filename="policies.xlsx" label="خروجی اکسل" />
            <Button asChild variant="outline" size="sm">
              <Link href={`/print/insurance${filterQs.size ? `?${filterQs.toString()}` : ''}`} aria-label="چاپ فهرست بیمه‌نامه‌ها">
                <Printer className="size-4" aria-hidden />
                چاپ
              </Link>
            </Button>
          </div>

          {allPolicies === null ? (
            <div className="flex justify-center py-16" role="status" aria-label="در حال بارگذاری">
              <Loader2 className="size-6 animate-spin text-brand-600" />
            </div>
          ) : allPolicies.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-2 p-8 text-center">
                <ShieldCheck className="size-8 text-brand-600/60" aria-hidden />
                <p className="text-sm font-medium">بیمه‌نامه‌ای یافت نشد</p>
                <p className="text-xs text-muted-foreground">
                  از تب «ناوگان و بیمه»، ماشین را باز کنید و دکمه «ثبت بیمه» را بزنید یا فیلترها را تغییر دهید
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {allPolicies.map((p) => {
                const st = statusOf(p)
                return (
                  <Card key={p.id} className="border-brand-100 dark:border-brand-900/60">
                    <CardContent className="space-y-2.5 p-4">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h2 className="font-bold leading-6">{p.machineName}</h2>
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            {p.typeName} — بیمه‌گر: {p.company}
                          </p>
                        </div>
                        <Badge variant="outline" className={st.className}>{st.label}</Badge>
                      </div>

                      <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-3">
                        <div className="flex items-center justify-between gap-2">
                          <dt className="text-muted-foreground">شماره</dt>
                          <dd className="font-medium" dir="ltr">{p.policyNumber}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-2">
                          <dt className="text-muted-foreground">دوره</dt>
                          <dd className="font-medium" dir="rtl">از {p.startDate} تا {p.endDate}</dd>
                        </div>
                      </dl>

                      <div className="flex justify-end border-t pt-2">
                        <Button
                          variant="outline" size="sm"
                          className="border-brand-200 text-brand-700 hover:bg-brand-50 dark:border-brand-900 dark:text-brand-300 dark:hover:bg-brand-950"
                          onClick={() => {
                            const m = machineById(p.machineId)
                            if (m) openMachineDetail(m, p.id)
                            else toast.error('ماشین این بیمه‌نامه در فهرست نیست')
                          }}
                        >
                          الحاقیه و پیوست‌ها
                          <ChevronDown className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* ─── تب نوع بیمه‌ها ─── */}
        <TabsContent value="types" className="mt-4 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">
              انواع بیمه برای انتخاب هنگام صدور بیمه‌نامه ({faNum(types.length)} نوع) — برای هر ماشین می‌توانید از هر نوع چند بیمه‌نامه ثبت کنید
            </p>
            <Button onClick={openTypeCreate} className="bg-brand-600 text-white hover:bg-brand-700">
              <Plus className="size-4" aria-hidden />
              نوع جدید
            </Button>
          </div>

          {types.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-2 p-8 text-center">
                <ShieldCheck className="size-8 text-brand-600/60" aria-hidden />
                <p className="text-sm font-medium">هنوز نوع بیمه‌ای تعریف نشده است</p>
                <p className="text-xs text-muted-foreground">مثلاً «شخص ثالث»، «بدنه» یا «مسئولیت مدنی کارفرما»</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {types.map((t) => (
                <Card key={t.id} className="border-brand-100 dark:border-brand-900/60">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="font-bold">{t.name}</h3>
                        {t.note && <p className="mt-1 text-xs text-muted-foreground">{t.note}</p>}
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost" size="icon" className="size-8"
                          aria-label={`ویرایش نوع ${t.name}`}
                          onClick={() => openTypeEdit(t)}
                        >
                          <Pencil className="size-4" aria-hidden />
                        </Button>
                        <Button
                          variant="ghost" size="icon" className="size-8 text-red-600 hover:text-red-700"
                          aria-label={`حذف نوع ${t.name}`}
                          onClick={() => setDeleteTypeTarget(t)}
                        >
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* ─── دیالوگ جزئیات ماشین: بیمه‌نامه‌ها + الحاقیه + پیوست ─── */}
      <Dialog open={!!detailMachine} onOpenChange={(open) => { if (!open) closeMachineDetail() }}>
        <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex flex-wrap items-center gap-2">
              {detailMachine?.name}
              {detailMachine?.deviceNumber && (
                <span className="rounded bg-brand-50 px-1.5 py-0.5 text-xs font-bold text-brand-700" dir="ltr">
                  {detailMachine.deviceNumber}
                </span>
              )}
            </DialogTitle>
            <DialogDescription>
              سند، کارت سوخت و بیمه‌نامه‌های این ماشین — برای هر بیمه‌نامه می‌توانید الحاقیه بزنید و پیوست جداگانه بگذارید.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* ─── پیوست سند ماشین ─── */}
            <section aria-label="پیوست سند ماشین" className="space-y-2 rounded-lg border p-3">
              <h3 className="flex items-center gap-1.5 text-sm font-bold">
                <Paperclip className="size-4 text-brand-600" aria-hidden />
                پیوست سند ماشین (برگ سبز، سند مالکیت و…)
              </h3>
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  accept="image/*,application/pdf"
                  aria-label="انتخاب فایل سند ماشین"
                  className="h-9 cursor-pointer file:cursor-pointer"
                  onChange={(e) => setMachineFile(e.target.files?.[0] ?? null)}
                />
                <Button
                  size="sm" onClick={uploadMachineAtt} disabled={machineUploading || !machineFile}
                  className="h-9 shrink-0 bg-brand-600 text-white hover:bg-brand-700"
                >
                  {machineUploading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" aria-hidden />}
                  بارگذاری
                </Button>
              </div>
              {machineAttsLoading ? (
                <div className="flex justify-center py-2" role="status" aria-label="در حال دریافت اسناد">
                  <Loader2 className="size-4 animate-spin text-brand-600" />
                </div>
              ) : machineAtts.length === 0 ? (
                <p className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground">
                  برای این ماشین سندی بارگذاری نشده است — عکس یا PDF سند را اینجا بگذارید.
                </p>
              ) : (
                <div className="max-h-56 space-y-2 overflow-y-auto pe-1">
                  {machineAtts.map((f) => (
                    <div key={f.id} className="flex items-center justify-between gap-2 rounded-md border p-2.5">
                      <div className="flex min-w-0 items-center gap-2">
                        <FileText className="size-4 shrink-0 text-brand-600" aria-hidden />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium" dir="auto">{f.fileName}</p>
                          <p className="text-xs text-muted-foreground">
                            {faNum(Math.max(1, Math.round(f.size / 1024)))} کیلوبایت
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button asChild variant="ghost" size="icon" className="size-8">
                          <a
                            href={`/api/machines/${f.machineId}/attachments/${f.id}`}
                            download={f.fileName}
                            aria-label={`دانلود سند ${f.fileName}`}
                          >
                            <Files className="size-4" aria-hidden />
                          </a>
                        </Button>
                        <Button asChild variant="outline" size="sm">
                          <Link href={`/print/attachment/${f.id}`} aria-label={`چاپ سند ${f.fileName}`}>
                            <Printer className="size-4" aria-hidden />
                            چاپ
                          </Link>
                        </Button>
                        <Button
                          variant="ghost" size="icon" className="size-8 text-red-600 hover:text-red-700"
                          aria-label={`حذف سند ${f.fileName}`}
                          onClick={() => deleteMachineAtt(f.id)}
                        >
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* ─── کارت سوخت: تحویل به کارمند/پروژه + رسید تحویل ─── */}
            <section aria-label="کارت سوخت" className="space-y-3 rounded-lg border border-amber-200/70 p-3 dark:border-amber-900/60">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="flex items-center gap-1.5 text-sm font-bold">
                  <Fuel className="size-4 text-amber-600" aria-hidden />
                  کارت سوخت
                  {fuelCard ? (
                    <Badge variant="outline" className="px-1.5 py-0 text-[11px] border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-300">
                      ثبت‌شده
                    </Badge>
                  ) : (
                    <span className="text-xs font-normal text-muted-foreground">هنوز ثبت نشده</span>
                  )}
                </h3>
                {fuelCard && (
                  <span className="text-xs text-muted-foreground">
                    {fuelCard.holderName
                      ? `تحویل به ${fuelCard.holderName}${fuelCard.projectName ? ` — پروژه ${fuelCard.projectName}` : ''}`
                      : 'در انبار — تحویل نشده'}
                  </span>
                )}
              </div>
              <p className="text-xs leading-5 text-muted-foreground">
                تحویل‌گیرنده و پروژه فقط مخصوص کارت سوخت است؛ پس از تحویل، رسید را بارگذاری کنید.
              </p>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="grid gap-1.5">
                  <Label htmlFor="fc-number">شماره کارت سوخت *</Label>
                  <Input
                    id="fc-number" value={fcNumber} placeholder="مثلاً FC-1024" dir="ltr" className="text-right"
                    onChange={(e) => setFcNumber(e.target.value)}
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="fc-date">تاریخ تحویل (شمسی)</Label>
                  <Input
                    id="fc-date" value={fcDate} placeholder="1405/08/01" dir="ltr" className="text-center"
                    inputMode="numeric" onChange={(e) => setFcDate(formatJalaliDateInput(e.target.value))}
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label>تحویل به کارمند</Label>
                  <Select
                    value={fcHolder || 'none'}
                    onValueChange={(v) => setFcHolder(v === 'none' ? '' : v)}
                  >
                    <SelectTrigger aria-label="انتخاب کارمند تحویل‌گیرنده">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون تحویل (در انبار)</SelectItem>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.fullName}
                          {emp.project?.name ? ` — ${emp.project.name}` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <Label>پروژه</Label>
                  <Select
                    value={fcProject || 'none'}
                    onValueChange={(v) => setFcProject(v === 'none' ? '' : v)}
                  >
                    <SelectTrigger aria-label="انتخاب پروژه کارت سوخت">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون پروژه</SelectItem>
                      {projects.map((pr) => (
                        <SelectItem key={pr.id} value={pr.id}>{pr.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5 sm:col-span-2">
                  <Label htmlFor="fc-note">یادداشت</Label>
                  <Textarea id="fc-note" rows={2} value={fcNote} onChange={(e) => setFcNote(e.target.value)} />
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button onClick={saveFuelCard} disabled={fcSaving || fcLoading} className="bg-brand-600 text-white hover:bg-brand-700">
                  {fcSaving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Save className="size-4" aria-hidden />}
                  ذخیره کارت سوخت
                </Button>
                {fuelCard && (
                  <Button
                    variant="ghost" size="sm" className="text-red-600 hover:bg-red-50 hover:text-red-700 dark:hover:bg-red-950"
                    aria-label="حذف کارت سوخت"
                    onClick={() => setFcDeleteOpen(true)}
                  >
                    <Trash2 className="size-4" aria-hidden />
                    حذف کارت سوخت
                  </Button>
                )}
              </div>

              {/* رسیدهای تحویل */}
              <div className="space-y-2 border-t pt-3">
                <h4 className="text-xs font-bold">رسیدهای تحویل کارت سوخت (عکس یا PDF، حداکثر ۵ مگابایت)</h4>
                <div className="flex items-center gap-2">
                  <Input
                    type="file"
                    accept="image/*,application/pdf"
                    aria-label="انتخاب فایل رسید تحویل"
                    className="h-9 cursor-pointer file:cursor-pointer"
                    onChange={(e) => setFcFile(e.target.files?.[0] ?? null)}
                  />
                  <Button
                    size="sm" onClick={uploadFuelReceipt} disabled={fcUploading || !fcFile || !fuelCard}
                    className="h-9 shrink-0 bg-brand-600 text-white hover:bg-brand-700"
                  >
                    {fcUploading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" aria-hidden />}
                    بارگذاری رسید
                  </Button>
                </div>
                {!fuelCard && (
                  <p className="text-xs text-muted-foreground">برای بارگذاری رسید، اول کارت سوخت را ذخیره کنید.</p>
                )}
                {fuelCard && fuelCard.attachments.length === 0 && (
                  <p className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground">
                    هنوز رسیدی برای تحویل این کارت بارگذاری نشده است.
                  </p>
                )}
                {fuelCard && fuelCard.attachments.length > 0 && (
                  <div className="max-h-56 space-y-2 overflow-y-auto pe-1">
                    {fuelCard.attachments.map((f) => (
                      <div key={f.id} className="flex items-center justify-between gap-2 rounded-md border p-2.5">
                        <div className="flex min-w-0 items-center gap-2">
                          <FileText className="size-4 shrink-0 text-amber-600" aria-hidden />
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium" dir="auto">{f.fileName}</p>
                            <p className="text-xs text-muted-foreground">
                              {faNum(Math.max(1, Math.round(f.size / 1024)))} کیلوبایت
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button asChild variant="ghost" size="icon" className="size-8">
                            <a
                              href={`/api/machines/${detailMachine?.id}/fuel-card/attachments/${f.id}`}
                              download={f.fileName}
                              aria-label={`دانلود رسید ${f.fileName}`}
                            >
                              <Files className="size-4" aria-hidden />
                            </a>
                          </Button>
                          <Button asChild variant="outline" size="sm">
                            <Link href={`/print/attachment/${f.id}`} aria-label={`چاپ رسید ${f.fileName}`}>
                              <Printer className="size-4" aria-hidden />
                              چاپ
                            </Link>
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="size-8 text-red-600 hover:text-red-700"
                            aria-label={`حذف رسید ${f.fileName}`}
                            onClick={() => deleteFuelReceipt(f)}
                          >
                            <Trash2 className="size-4" aria-hidden />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>

            <Button onClick={openPolicyCreate} className="w-full bg-brand-600 text-white hover:bg-brand-700">
              <Plus className="size-4" aria-hidden />
              ثبت بیمه برای این ماشین
            </Button>

            {policiesLoading ? (
              <div className="flex justify-center py-8" role="status" aria-label="در حال دریافت بیمه‌نامه‌ها">
                <Loader2 className="size-5 animate-spin text-brand-600" />
              </div>
            ) : machinePolicies.length === 0 ? (
              <p className="rounded-lg bg-muted/60 p-4 text-center text-sm text-muted-foreground">
                هنوز بیمه‌نامه‌ای برای این ماشین ثبت نشده است — با دکمه بالا اولین بیمه‌نامه را ثبت کنید.
              </p>
            ) : (
              <div className="space-y-3">
                {machinePolicies.map((p) => {
                  const st = statusOf(p)
                  const open = expandedId === p.id
                  return (
                    <Collapsible key={p.id} open={open} onOpenChange={(o) => toggleExpand(p.id, o)}
                      className="rounded-lg border">
                      <CollapsibleTrigger asChild>
                        <button
                          className="flex w-full items-center justify-between gap-2 p-3 text-right"
                          aria-expanded={open}
                        >
                          <span className="min-w-0">
                            <span className="flex flex-wrap items-center gap-1.5 text-sm font-bold">
                              {p.typeName}
                              <Badge variant="outline" className={`px-1.5 py-0 text-[11px] ${st.className}`}>{st.label}</Badge>
                            </span>
                            <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                              {p.company} — شماره {p.policyNumber} — از {p.startDate} تا {p.endDate}
                            </span>
                          </span>
                          <ChevronDown className={`size-4 shrink-0 text-muted-foreground transition-transform ${open ? 'rotate-180' : ''}`} aria-hidden />
                        </button>
                      </CollapsibleTrigger>

                      <CollapsibleContent className="border-t">
                        <div className="space-y-4 p-3">
                          {detailLoading && expandedId === p.id ? (
                            <div className="flex justify-center py-4" role="status" aria-label="در حال دریافت جزئیات">
                              <Loader2 className="size-5 animate-spin text-brand-600" />
                            </div>
                          ) : detail && expandedId === p.id ? (
                            <>
                              {/* الحاقیه‌ها */}
                              <div className="space-y-2">
                                <h3 className="flex items-center gap-1.5 text-sm font-bold">
                                  <FileSignature className="size-4 text-brand-600" aria-hidden />
                                  سابقه الحاقیه‌ها
                                </h3>
                                {detail.actions.length === 0 ? (
                                  <p className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground">
                                    هنوز الحاقیه‌ای روی این بیمه‌نامه ثبت نشده است
                                  </p>
                                ) : (
                                  <div className="max-h-56 space-y-2 overflow-y-auto pe-1">
                                    {detail.actions.map((a) => (
                                      <div key={a.id} className="rounded-md border p-2.5 text-sm">
                                        <div className="flex flex-wrap items-center justify-between gap-2">
                                          <div className="flex items-center gap-2">
                                            <Badge variant="outline" className={a.kind === 'RENEWAL'
                                              ? 'border-brand-200 bg-brand-50 text-brand-700 dark:border-brand-900 dark:bg-brand-950 dark:text-brand-300'
                                              : 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300'}
                                            >
                                              {ACTION_LABEL[a.kind] ?? a.kind}
                                            </Badge>
                                            <span className="flex items-center gap-1 text-xs text-muted-foreground">
                                              <CalendarClock className="size-3.5" aria-hidden />
                                              {a.date}
                                            </span>
                                          </div>
                                        </div>
                                        {a.kind === 'RENEWAL' && a.newEndDate && (
                                          <p className="mt-1 text-xs text-muted-foreground">سررسید جدید: {a.newEndDate}</p>
                                        )}
                                        {a.note && <p className="mt-1 text-xs text-muted-foreground">{a.note}</p>}
                                      </div>
                                    ))}
                                  </div>
                                )}
                                <Button
                                  variant="outline" size="sm"
                                  className="border-amber-200 text-amber-700 hover:bg-amber-50 dark:border-amber-900 dark:text-amber-300 dark:hover:bg-amber-950"
                                  onClick={() => openEndorse(p)}
                                >
                                  <FileSignature className="size-4" aria-hidden />
                                  ثبت الحاقیه
                                </Button>
                              </div>

                              {/* پیوست‌ها */}
                              <div className="space-y-2">
                                <h3 className="flex items-center gap-1.5 text-sm font-bold">
                                  <Paperclip className="size-4 text-brand-600" aria-hidden />
                                  پیوست‌ها (عکس یا PDF، حداکثر ۵ مگابایت)
                                </h3>
                                <div className="flex items-center gap-2">
                                  <Input
                                    type="file"
                                    accept="image/*,application/pdf"
                                    aria-label="انتخاب فایل پیوست"
                                    className="h-9 cursor-pointer file:cursor-pointer"
                                    onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                                  />
                                  <Button
                                    size="sm" onClick={uploadAttachment} disabled={uploading || !file}
                                    className="h-9 shrink-0 bg-brand-600 text-white hover:bg-brand-700"
                                  >
                                    {uploading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" aria-hidden />}
                                    بارگذاری
                                  </Button>
                                </div>
                                {detail.attachments.length === 0 ? (
                                  <p className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground">
                                    برای این بیمه‌نامه پیوستی بارگذاری نشده است
                                  </p>
                                ) : (
                                  <div className="max-h-56 space-y-2 overflow-y-auto pe-1">
                                    {detail.attachments.map((f) => (
                                      <div key={f.id} className="flex items-center justify-between gap-2 rounded-md border p-2.5">
                                        <div className="flex min-w-0 items-center gap-2">
                                          <FileText className="size-4 shrink-0 text-brand-600" aria-hidden />
                                          <div className="min-w-0">
                                            <p className="truncate text-sm font-medium" dir="auto">{f.fileName}</p>
                                            <p className="text-xs text-muted-foreground">
                                              {faNum(Math.max(1, Math.round(f.size / 1024)))} کیلوبایت
                                            </p>
                                          </div>
                                        </div>
                                        <div className="flex items-center gap-1">
                                          <Button asChild variant="ghost" size="icon" className="size-8">
                                            <a
                                              href={`/api/insurance/attachments/${f.id}`}
                                              download={f.fileName}
                                              aria-label={`دانلود پیوست ${f.fileName}`}
                                            >
                                              <Files className="size-4" aria-hidden />
                                            </a>
                                          </Button>
                                          <Button asChild variant="outline" size="sm">
                                            <Link href={`/print/attachment/${f.id}`} aria-label={`چاپ پیوست ${f.fileName}`}>
                                              <Printer className="size-4" aria-hidden />
                                              چاپ
                                            </Link>
                                          </Button>
                                          <Button
                                            variant="ghost" size="icon" className="size-8 text-red-600 hover:text-red-700"
                                            aria-label={`حذف پیوست ${f.fileName}`}
                                            onClick={() => deleteAttachment(f.id)}
                                          >
                                            <Trash2 className="size-4" aria-hidden />
                                          </Button>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>

                              {/* حذف بیمه‌نامه */}
                              <div className="flex justify-end border-t pt-2">
                                <Button
                                  variant="ghost" size="sm" className="text-red-600 hover:bg-red-50 hover:text-red-700 dark:hover:bg-red-950"
                                  aria-label={`حذف بیمه‌نامه ${p.policyNumber}`}
                                  onClick={() => setDeletePolicyTarget(p)}
                                >
                                  <Trash2 className="size-4" aria-hidden />
                                  حذف بیمه‌نامه
                                </Button>
                              </div>
                            </>
                          ) : (
                            <div className="flex justify-center py-2">
                              <Button variant="ghost" size="sm" onClick={() => { setExpandedId(p.id); loadDetail(p.id) }}>
                                نمایش الحاقیه‌ها و پیوست‌ها
                              </Button>
                            </div>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  )
                })}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* دیالوگ ثبت بیمه‌نامه جدید (برای ماشین بازشده) */}
      <Dialog open={policyOpen} onOpenChange={setPolicyOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>ثبت بیمه‌نامه — {detailMachine?.name}</DialogTitle>
            <DialogDescription>نوع بیمه و مشخصات بیمه‌نامه را وارد کنید.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-1">
            <div className="grid gap-1.5">
              <Label>نوع بیمه *</Label>
              <Select value={pTypeId} onValueChange={setPTypeId}>
                <SelectTrigger aria-label="انتخاب نوع بیمه">
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {types.map((t) => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs leading-5 text-muted-foreground">
                انواع مختلف بیمه (ثالث، بدنه، مسئولیت و…) را می‌توانید همزمان برای یک ماشین ثبت کنید.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="p-company">بیمه‌گر *</Label>
                <Input id="p-company" value={pCompany} placeholder="مثلاً بیمه ایران" onChange={(e) => setPCompany(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="p-number">شماره بیمه‌نامه *</Label>
                <Input id="p-number" value={pNumber} placeholder="IR-0000-000000" dir="ltr" className="text-right" onChange={(e) => setPNumber(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="p-start">تاریخ شروع * (شمسی)</Label>
                <Input id="p-start" value={pStart} placeholder="1405/08/01" dir="ltr" className="text-center" inputMode="numeric" onChange={(e) => setPStart(formatJalaliDateInput(e.target.value))} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="p-end">تاریخ پایان * (شمسی)</Label>
                <Input id="p-end" value={pEnd} placeholder="1406/08/01" dir="ltr" className="text-center" inputMode="numeric" onChange={(e) => setPEnd(formatJalaliDateInput(e.target.value))} />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="p-note">یادداشت</Label>
              <Textarea id="p-note" rows={2} value={pNote} onChange={(e) => setPNote(e.target.value)} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPolicyOpen(false)} disabled={savingPolicy}>انصراف</Button>
            <Button onClick={savePolicy} disabled={savingPolicy} className="bg-brand-600 text-white hover:bg-brand-700">
              {savingPolicy && <Loader2 className="size-4 animate-spin" aria-hidden />}
              ثبت بیمه‌نامه
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* دیالوگ الحاقیه */}
      <Dialog open={!!endorseTarget} onOpenChange={(open) => { if (!open) setEndorseTarget(null) }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>الحاقیه بیمه‌نامه {endorseTarget?.policyNumber}</DialogTitle>
            <DialogDescription>
              تاریخ و توضیح الحاقیه را ثبت کنید تا در سابقهٔ بیمه‌نامه بماند.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-1">
            <div className="grid gap-1.5">
              <Label htmlFor="e-date">تاریخ * (شمسی)</Label>
              <Input id="e-date" value={eDate} placeholder="1405/08/15" dir="ltr" className="text-center" inputMode="numeric" onChange={(e) => setEDate(formatJalaliDateInput(e.target.value))} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="e-note">یادداشت</Label>
              <Textarea id="e-note" rows={2} value={eNote} onChange={(e) => setENote(e.target.value)} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEndorseTarget(null)} disabled={savingEndorse}>انصراف</Button>
            <Button onClick={submitEndorsement} disabled={savingEndorse} className="bg-brand-600 text-white hover:bg-brand-700">
              {savingEndorse && <Loader2 className="size-4 animate-spin" aria-hidden />}
              ثبت الحاقیه
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* دیالوگ ثبت/ویرایش ماشین */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? 'ویرایش ماشین' : 'ثبت ماشین جدید'}</DialogTitle>
            <DialogDescription>
              مشخصات ماشین را وارد کنید؛ نام و شماره دستگاه الزامی است.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-1">
            <div className="grid gap-1.5">
              <Label htmlFor="m-name">نام ماشین *</Label>
              <Input
                id="m-name" value={fName} placeholder="مثلاً لودر کوماتسو"
                onChange={(e) => setFName(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="m-device">شماره دستگاه (شناسه داخلی شرکت) *</Label>
              <Input
                id="m-device" value={fDevice} placeholder="M-101" dir="ltr" className="text-right"
                onChange={(e) => setFDevice(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="m-model">مدل/تیپ</Label>
                <Input id="m-model" value={fModel} placeholder="WA380-7" dir="ltr" className="text-right" onChange={(e) => setFModel(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="m-year">سال ساخت</Label>
                <Input id="m-year" value={fYear} placeholder="۱۳۹۹" inputMode="numeric" onChange={(e) => setFYear(e.target.value)} />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="m-plate">شماره پلاک/شناسه</Label>
              <Input id="m-plate" value={fPlate} placeholder="ع ۵۵ ب ۷۸" onChange={(e) => setFPlate(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="m-owner">نام صاحب خودرو</Label>
              <Input id="m-owner" value={fOwner} placeholder="نام و نام خانوادگی مالک" onChange={(e) => setFOwner(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="m-chassis">شماره شاسی</Label>
              <Input id="m-chassis" value={fChassis} placeholder="MR0AX3CD2..." dir="ltr" className="text-right" onChange={(e) => setFChassis(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="m-note">یادداشت</Label>
              <Textarea id="m-note" value={fNote} rows={2} placeholder="توضیح دلخواه" onChange={(e) => setFNote(e.target.value)} />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label htmlFor="m-active" className="cursor-pointer">ماشین در سرویس است</Label>
              <Switch
                id="m-active" checked={fActive} onCheckedChange={setFActive}
                aria-label="وضعیت سرویس ماشین"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setFormOpen(false)} disabled={saving}>انصراف</Button>
            <Button onClick={saveMachine} disabled={saving} className="bg-brand-600 text-white hover:bg-brand-700">
              {saving && <Loader2 className="size-4 animate-spin" aria-hidden />}
              {editingId ? 'ذخیره تغییرات' : 'ثبت ماشین'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* دیالوگ نوع بیمه */}
      <Dialog open={typeOpen} onOpenChange={setTypeOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{editingTypeId ? 'ویرایش نوع بیمه' : 'نوع بیمه جدید'}</DialogTitle>
            <DialogDescription>نوع بیمه مثل «شخص ثالث» یا «بدنه».</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-1">
            <div className="grid gap-1.5">
              <Label htmlFor="t-name">نوع بیمه *</Label>
              <Input id="t-name" value={tName} placeholder="مثلاً بدنه" onChange={(e) => setTName(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="t-note">یادداشت</Label>
              <Textarea id="t-note" rows={2} value={tNote} onChange={(e) => setTNote(e.target.value)} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setTypeOpen(false)} disabled={savingType}>انصراف</Button>
            <Button onClick={saveType} disabled={savingType} className="bg-brand-600 text-white hover:bg-brand-700">
              {savingType && <Loader2 className="size-4 animate-spin" aria-hidden />}
              {editingTypeId ? 'ذخیره' : 'افزودن'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تایید حذف ماشین */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => { if (!open) setDeleteTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف ماشین «{deleteTarget?.name}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              این عمل قابل بازگشت نیست. اگر ماشین بیمه‌نامه داشته باشد، اول باید بیمه‌نامه‌هایش حذف شوند؛ اسناد پیوست، کارت سوخت و رسیدهای تحویل هم همراه ماشین حذف می‌شوند.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel disabled={deleting}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); deleteMachine() }}
              disabled={deleting}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deleting && <Loader2 className="size-4 animate-spin" aria-hidden />}
              حذف کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* تایید حذف بیمه‌نامه */}
      <AlertDialog open={!!deletePolicyTarget} onOpenChange={(open) => { if (!open) setDeletePolicyTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف بیمه‌نامه شماره «{deletePolicyTarget?.policyNumber}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              تمام الحاقیه‌ها و پیوست‌های این بیمه‌نامه هم حذف می‌شوند و این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel disabled={deletingPolicy}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); deletePolicy() }}
              disabled={deletingPolicy}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deletingPolicy && <Loader2 className="size-4 animate-spin" aria-hidden />}
              حذف کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* تایید حذف کارت سوخت */}
      <AlertDialog open={fcDeleteOpen} onOpenChange={setFcDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کارت سوخت «{fuelCard?.cardNumber}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              تمام رسیدهای تحویل این کارت هم حذف می‌شوند و این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel disabled={fcDeleting}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); deleteFuelCard() }}
              disabled={fcDeleting}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {fcDeleting && <Loader2 className="size-4 animate-spin" aria-hidden />}
              حذف کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* تایید حذف نوع بیمه */}
      <AlertDialog open={!!deleteTypeTarget} onOpenChange={(open) => { if (!open) setDeleteTypeTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف نوع بیمه «{deleteTypeTarget?.name}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              اگر این نوع در بیمه‌نامه‌ای استفاده شده باشد، حذف انجام نمی‌شود.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel disabled={deletingType}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); deleteType() }}
              disabled={deletingType}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deletingType && <Loader2 className="size-4 animate-spin" aria-hidden />}
              حذف کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  )
}
