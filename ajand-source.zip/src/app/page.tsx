import Link from 'next/link'
import { LogIn } from 'lucide-react'
import { db } from '@/lib/db'
import { getSession } from '@/lib/session'
import { PANEL_PATHS, type Role } from '@/lib/types'
import { getRoleLabelMap } from '@/lib/roles'
import { getUserPanelList } from '@/lib/permissions'
import { faDigits } from '@/lib/persian'
import { Button } from '@/components/ui/button'
import { Feed } from './feed-client'
import type { NewsPostDTO } from '@/lib/types'

export const dynamic = 'force-dynamic'

export default async function HomePage() {
  const session = await getSession()
  const now = new Date()
  const labels = await getRoleLabelMap()
  const rows = await db.newsPost.findMany({
    where: {
      OR: [
        { targetRole: null },
        ...(session?.role ? [{ targetRole: session.role }] : []),
      ],
      AND: [{ OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] }],
    },
    orderBy: [{ isUrgent: 'desc' }, { createdAt: 'desc' }],
    include: {
      author: { select: { fullName: true } },
      _count: { select: { likes: true, comments: true } },
      ...(session?.userId
        ? { likes: { where: { userId: session.userId }, select: { id: true } } }
        : {}),
    },
    take: 30,
  })

  const posts: NewsPostDTO[] = rows.map((n) => ({
    id: n.id,
    title: n.title,
    body: n.body,
    isUrgent: n.isUrgent,
    expiresAt: n.expiresAt?.toISOString() ?? null,
    targetRole: (n.targetRole as Role | null) ?? null,
    targetRoleLabel: n.targetRole ? (labels[n.targetRole] ?? n.targetRole) : null,
    authorName: n.author.fullName,
    createdAt: n.createdAt.toISOString(),
    hasImage: !!n.imageName,
    likeCount: n._count.likes,
    commentCount: n._count.comments,
    likedByMe: Array.isArray((n as { likes?: { id: string }[] }).likes) &&
      ((n as { likes?: { id: string }[] }).likes?.length ?? 0) > 0,
  }))

  const viewer = session
    ? { role: session.role as Role, fullName: session.fullName }
    : null

  // مقصد «پنل من»: اولین بخش مجاز کاربر (نقش سفارشی هم درست هدایت می‌شود)
  let homePath: string | null = null
  if (session) {
    const panels = await getUserPanelList(session.userId, session.role)
    homePath = panels[0] ? PANEL_PATHS[panels[0]] : null
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-brand-50 to-background dark:from-brand-950/30 dark:to-background">
      {/* هدر */}
      <header className="safe-top sticky top-0 z-10 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-center gap-3 px-4 py-3">
          {/* لوگوی شرکت — حرف A */}
          <div className="flex size-10 shrink-0 items-center justify-center rounded-xl border bg-white shadow-sm">
            { }
            <img src="/logo.png" alt="لوگوی آژند اپ" className="size-7 object-contain" />
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-bold leading-tight">آژند اپ</h1>
            <p className="text-xs text-muted-foreground">اخبار و اطلاعیه‌های شرکت آژند همت توس</p>
          </div>
          {session ? (
            homePath ? (
              <Button asChild size="sm" className="rounded-full">
                <Link href={homePath}>پنل من</Link>
              </Button>
            ) : null
          ) : (
            <Button asChild size="sm" className="rounded-full">
              <Link href="/login">
                <LogIn className="size-4" />
                ورود
              </Link>
            </Button>
          )}
        </div>
      </header>

      <main className="mx-auto w-full max-w-2xl flex-1 px-4 py-6">
        <Feed initialPosts={posts} viewer={viewer} />
      </main>

      {/* فوتر چسبان */}
      <footer className="safe-bottom mt-auto border-t py-4 text-center text-xs text-muted-foreground">
        © شرکت آژند همت توس — آژند اپ نسخه {faDigits('3.11')}
      </footer>
    </div>
  )
}
