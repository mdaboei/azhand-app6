import { requirePanelPage } from '@/lib/guard'
import { ReportsClient } from './reports-client'

export default async function ReportsPage() {
  const { session } = await requirePanelPage('REPORTS')
  return <ReportsClient myUserId={session.userId} myRole={session.role} />
}
