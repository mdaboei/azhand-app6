import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function ReportsLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('REPORTS')
  return (
    <PanelShell
      fullName={user.fullName}
      roleLabel={roleLabel}
      role={session.role as 'MANAGEMENT' | 'ADMIN'}
      unitLabel="گزارش پروژه‌ها"
      panels={panels}
    >
      {children}
    </PanelShell>
  )
}
