'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import {
  ChevronRight, Heart, ImagePlus, Loader2, Lock, MessageCircle,
  Send, Star, Trash2, X,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  ROLE_LABELS, type ReportAuthorProfile, type ReportCommentDTO, type ReportDTO, type Role,
} from '@/lib/types'
import { faDate, faDigits, faNum } from '@/lib/persian'

const MAX_PHOTOS = 20

/** صفحه گزارش پروژه‌ها: فید + پست جدید + پروفایل نویسنده‌ها */
export function ReportsClient({ myUserId, myRole }: { myUserId: string; myRole: Role }) {
  const [reports, setReports] = useState<ReportDTO[] | null>(null)
  const [profile, setProfile] = useState<ReportAuthorProfile | null>(null)
  const [loading, setLoading] = useState(true)

  const loadFeed = useCallback(async (userId?: string) => {
    setLoading(true)
    try {
      const qs = userId ? `?userId=${userId}` : ''
      const res = await fetch(`/api/reports${qs}`)
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        toast.error(data.error || 'دریافت گزارش‌ها ناموفق بود')
        setReports([])
        return
      }
      const data = await res.json()
      setReports(data.reports)
      setProfile(data.author ?? null)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
      setReports([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadFeed() }, [loadFeed])

  const canSuperLike = myRole === 'MANAGEMENT' || myRole === 'ADMIN'

  // ─── لایک / سوپر لایک ─────────────────────────────────────────────
  async function toggleLike(r: ReportDTO, isSuper: boolean) {
    try {
      const res = await fetch(`/api/reports/${r.id}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isSuper }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت لایک ناموفق بود'); return }
      setReports((prev) => (prev ?? []).map((x) => x.id === r.id ? {
        ...x,
        likedByMe: data.liked,
        myLikeIsSuper: data.liked ? data.isSuper : false,
        likeCount: data.likeCount,
        superLikeCount: data.superLikeCount,
      } : x))
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  // ─── حذف پست ──────────────────────────────────────────────────────
  const [deleteTarget, setDeleteTarget] = useState<ReportDTO | null>(null)
  const [deleting, setDeleting] = useState(false)

  async function deleteReport() {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/reports/${deleteTarget.id}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف ناموفق بود'); return }
      toast.success('پست حذف شد')
      setDeleteTarget(null)
      await loadFeed(profile?.id)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <section aria-label="گزارش پروژه‌ها" className="space-y-4">
      {/* هدر + پروفایل / بازگشت */}
      {profile ? (
        <ProfileHeader profile={profile} onBack={() => loadFeed()} />
      ) : (
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold">گزارش پروژه‌ها</h1>
            <p className="mt-0.5 text-xs text-muted-foreground">
              گزارش‌های روزانه مدیران پروژه — روی نام نویسنده بزنید تا پروفایلش را ببینید
            </p>
          </div>
          <ComposeButton onCreated={() => loadFeed(profile?.id)} />
        </div>
      )}

      {/* فید */}
      {loading && reports === null ? (
        <div className="space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : reports && reports.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 p-8 text-center">
            <ImagePlus className="size-8 text-brand-600/60" aria-hidden />
            <p className="text-sm font-medium">هنوز گزارشی ثبت نشده است</p>
            <p className="text-xs text-muted-foreground">
              مدیران پروژه با دکمه «گزارش جدید» روزانه گزارش می‌دهند
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {(reports ?? []).map((r) => (
            <ReportCard
              key={r.id}
              report={r}
              canSuperLike={canSuperLike}
              myUserId={myUserId}
              myRole={myRole}
              onLike={(isSuper) => toggleLike(r, isSuper)}
              onDelete={() => setDeleteTarget(r)}
              onOpenProfile={() => loadFeed(r.authorId)}
            />
          ))}
        </div>
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => { if (!open) setDeleteTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف این پست گزارش؟</AlertDialogTitle>
            <AlertDialogDescription>
              عکس‌ها، لایک‌ها و کامنت‌های این پست هم حذف می‌شوند و قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel disabled={deleting}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); deleteReport() }}
              disabled={deleting}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deleting && <Loader2 className="size-4 animate-spin" aria-hidden />}
              حذف کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  )
}

// ─── هدر پروفایل نویسنده ─────────────────────────────────────────────

function ProfileHeader({ profile, onBack }: { profile: ReportAuthorProfile; onBack: () => void }) {
  return (
    <Card className="border-brand-100 dark:border-brand-900/60">
      <CardContent className="space-y-3 p-4">
        <Button variant="ghost" size="sm" className="-ms-2 gap-1" onClick={onBack}>
          <ChevronRight className="size-4" aria-hidden />
          بازگشت به فید
        </Button>
        <div className="flex items-center gap-3">
          <span className="flex size-14 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xl font-bold text-brand-700 dark:bg-brand-950 dark:text-brand-300">
            {profile.fullName.trim().charAt(0)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-bold">{profile.fullName}</p>
            <p className="text-xs text-muted-foreground">
              {profile.roleLabel}
              {profile.position ? ` — ${profile.position}` : ''}
            </p>
            {profile.projectName && (
              <p className="text-xs text-muted-foreground">پروژه: {profile.projectName}</p>
            )}
          </div>
          <div className="text-center">
            <p className="text-lg font-bold text-brand-700 dark:text-brand-300">{faNum(profile.postCount)}</p>
            <p className="text-[11px] text-muted-foreground">پست</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// ─── دکمه + دیالوگ پست جدید ──────────────────────────────────────────

function ComposeButton({ onCreated }: { onCreated: () => void }) {
  const [open, setOpen] = useState(false)
  const [body, setBody] = useState('')
  const [isPublic, setIsPublic] = useState(true)
  const [files, setFiles] = useState<File[]>([])
  const [saving, setSaving] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  function addFiles(list: FileList | null) {
    if (!list) return
    const imgs = Array.from(list).filter((f) => f.type.startsWith('image/'))
    setFiles((prev) => {
      const next = [...prev, ...imgs]
      if (next.length > MAX_PHOTOS) {
        toast.error(`حداکثر ${MAX_PHOTOS} عکس در هر پست`)
        return next.slice(0, MAX_PHOTOS)
      }
      for (const f of imgs) {
        if (f.size > 5 * 1024 * 1024) {
          toast.error(`عکس «${f.name}» بزرگ‌تر از ۵ مگابایت است`)
          return prev
        }
      }
      return next
    })
    if (inputRef.current) inputRef.current.value = ''
  }

  async function submit() {
    if (!body.trim() && files.length === 0) {
      toast.error('توضیحات بنویسید یا عکس اضافه کنید')
      return
    }
    setSaving(true)
    try {
      const form = new FormData()
      form.append('body', body.trim())
      form.append('isPublic', String(isPublic))
      for (const f of files) form.append('photos', f)
      const res = await fetch('/api/reports', { method: 'POST', body: form })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت پست ناموفق بود'); return }
      toast.success('گزارش ثبت شد')
      setOpen(false)
      setBody(''); setFiles([]); setIsPublic(true)
      onCreated()
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <Button onClick={() => setOpen(true)} className="bg-brand-600 text-white hover:bg-brand-700">
        <ImagePlus className="size-4" aria-hidden />
        گزارش جدید
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>گزارش پروژه جدید</DialogTitle>
            <DialogDescription>
              توضیحات بنویسید و تا {faDigits(MAX_PHOTOS)} عکس اضافه کنید؛ سپس عمومی یا خصوصی بودن را انتخاب کنید.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-1">
            <div className="grid gap-1.5">
              <Label htmlFor="rp-body">توضیحات گزارش</Label>
              <Textarea
                id="rp-body" value={body} rows={4}
                placeholder="مثلاً: امروز عملیات خاکریزی جاده اصلی انجام شد…"
                onChange={(e) => setBody(e.target.value)}
              />
            </div>

            <div className="grid gap-1.5">
              <Label>عکس‌ها (تا {faDigits(MAX_PHOTOS)} عکس، هر کدام حداکثر ۵ مگابایت)</Label>
              <Input
                ref={inputRef} type="file" accept="image/*" multiple
                aria-label="انتخاب عکس‌های گزارش"
                className="cursor-pointer file:cursor-pointer"
                onChange={(e) => addFiles(e.target.files)}
              />
              {files.length > 0 && (
                <div className="grid grid-cols-4 gap-2 sm:grid-cols-5">
                  {files.map((f, i) => (
                    <div key={`${f.name}-${i}`} className="group relative aspect-square overflow-hidden rounded-md border">
                      <img src={URL.createObjectURL(f)} alt={`پیش‌نمایش ${f.name}`} className="size-full object-cover" />
                      <button
                        type="button"
                        aria-label={`حذف عکس ${f.name}`}
                        className="absolute left-1 top-1 flex size-6 items-center justify-center rounded-full bg-black/60 text-white"
                        onClick={() => setFiles((prev) => prev.filter((_, j) => j !== i))}
                      >
                        <X className="size-3.5" aria-hidden />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label htmlFor="rp-public" className="cursor-pointer">پست عمومی</Label>
                <p className="text-xs text-muted-foreground">
                  {isPublic ? 'همه دارندگان بخش گزارش می‌بینند' : 'فقط مدیریت و ادمین می‌بینند'}
                </p>
              </div>
              <Switch
                id="rp-public" checked={isPublic} onCheckedChange={setIsPublic}
                aria-label="عمومی یا خصوصی بودن پست"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>انصراف</Button>
            <Button onClick={submit} disabled={saving} className="bg-brand-600 text-white hover:bg-brand-700">
              {saving && <Loader2 className="size-4 animate-spin" aria-hidden />}
              انتشار گزارش
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

// ─── کارت پست گزارش ──────────────────────────────────────────────────

function ReportCard({
  report: r, canSuperLike, myUserId, myRole, onLike, onDelete, onOpenProfile,
}: {
  report: ReportDTO
  canSuperLike: boolean
  myUserId: string
  myRole: Role
  onLike: (isSuper: boolean) => void
  onDelete: () => void
  onOpenProfile: () => void
}) {
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState<ReportCommentDTO[] | null>(null)
  const [commentsLoading, setCommentsLoading] = useState(false)
  const [commentText, setCommentText] = useState('')
  const [sendingComment, setSendingComment] = useState(false)
  const [lightbox, setLightbox] = useState<string | null>(null)

  const canDeletePost = r.authorId === myUserId || myRole === 'MANAGEMENT' || myRole === 'ADMIN'

  const loadComments = useCallback(async () => {
    setCommentsLoading(true)
    try {
      const res = await fetch(`/api/reports/${r.id}/comments`)
      if (res.ok) setComments(await res.json())
      else toast.error('دریافت کامنت‌ها ناموفق بود')
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setCommentsLoading(false)
    }
  }, [r.id])

  async function toggleComments() {
    const next = !showComments
    setShowComments(next)
    if (next && comments === null) await loadComments()
  }

  async function sendComment() {
    const text = commentText.trim()
    if (!text) return
    setSendingComment(true)
    try {
      const res = await fetch(`/api/reports/${r.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'ثبت کامنت ناموفق بود'); return }
      setComments((prev) => [...(prev ?? []), data])
      setCommentText('')
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSendingComment(false)
    }
  }

  async function deleteComment(cid: string) {
    try {
      const res = await fetch(`/api/reports/${r.id}/comments/${cid}`, { method: 'DELETE' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) { toast.error(data.error || 'حذف ناموفق بود'); return }
      setComments((prev) => (prev ?? []).filter((c) => c.id !== cid))
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  return (
    <Card className="border-brand-100 dark:border-brand-900/60">
      <CardContent className="space-y-3 p-4">
        {/* هدر پست: نویسنده + تاریخ + حریم */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenProfile}
            aria-label={`مشاهده پروفایل ${r.authorName}`}
            className="flex size-10 shrink-0 items-center justify-center rounded-full bg-brand-100 font-bold text-brand-700 transition-transform hover:scale-105 dark:bg-brand-950 dark:text-brand-300"
          >
            {r.authorName.trim().charAt(0)}
          </button>
          <div className="min-w-0 flex-1">
            <button
              onClick={onOpenProfile}
              className="block max-w-full truncate text-sm font-bold hover:text-brand-700 hover:underline dark:hover:text-brand-300"
            >
              {r.authorName}
            </button>
            <p className="truncate text-xs text-muted-foreground">
              {r.authorRoleLabel ?? ROLE_LABELS[r.authorRole as Role] ?? r.authorRole}
              {r.authorPosition ? ` — ${r.authorPosition}` : ''}
              {' · '}
              {faDate(r.createdAt)}
            </p>
          </div>
          {!r.isPublic && (
            <Badge variant="outline" className="shrink-0 gap-1 border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300">
              <Lock className="size-3" aria-hidden />
              خصوصی
            </Badge>
          )}
          {canDeletePost && (
            <Button
              variant="ghost" size="icon" className="size-8 shrink-0 text-red-600 hover:text-red-700"
              aria-label="حذف پست"
              onClick={onDelete}
            >
              <Trash2 className="size-4" aria-hidden />
            </Button>
          )}
        </div>

        {/* متن پست */}
        {r.body && r.body !== '—' && (
          <p className="whitespace-pre-wrap text-sm leading-6">{r.body}</p>
        )}

        {/* گالری عکس‌ها */}
        {r.photoIds.length > 0 && (
          <div className={`grid gap-1.5 ${r.photoIds.length === 1 ? 'grid-cols-1' : 'grid-cols-2 sm:grid-cols-3'}`}>
            {r.photoIds.map((pid, i) => (
              <button
                key={pid}
                onClick={() => setLightbox(`/api/reports/photos/${pid}`)}
                aria-label={`نمایش عکس ${faDigits(i + 1)}`}
                className={`overflow-hidden rounded-lg border ${r.photoIds.length === 1 ? 'max-h-80' : 'aspect-square'}`}
              >
                <img
                  src={`/api/reports/photos/${pid}`}
                  alt={`عکس گزارش — تصویر ${faDigits(i + 1)}`}
                  loading="lazy"
                  className="size-full object-cover transition-transform hover:scale-[1.02]"
                />
              </button>
            ))}
          </div>
        )}

        {/* لایک + سوپر لایک + کامنت */}
        <div className="flex flex-wrap items-center gap-2 border-t pt-2.5">
          <Button
            variant="ghost" size="sm"
            className={r.likedByMe && !r.myLikeIsSuper ? 'gap-1.5 text-red-600 hover:text-red-700' : 'gap-1.5 text-muted-foreground'}
            onClick={() => onLike(false)}
            aria-pressed={r.likedByMe && !r.myLikeIsSuper}
            aria-label="لایک"
          >
            <Heart className={`size-4 ${r.likedByMe && !r.myLikeIsSuper ? 'fill-red-600' : ''}`} aria-hidden />
            {faNum(r.likeCount)}
          </Button>

          {canSuperLike && (
            <Button
              variant="ghost" size="sm"
              className={r.myLikeIsSuper ? 'gap-1.5 text-amber-500 hover:text-amber-600' : 'gap-1.5 text-muted-foreground'}
              onClick={() => onLike(true)}
              aria-pressed={r.myLikeIsSuper}
              aria-label="سوپر لایک مدیریت"
              title="سوپر لایک مدیریت"
            >
              <Star className={`size-4 ${r.myLikeIsSuper ? 'fill-amber-400' : ''}`} aria-hidden />
              {faNum(r.superLikeCount)}
              <span className="text-xs">لایک مدیریت</span>
            </Button>
          )}

          {r.superLikeCount > 0 && (
            <Badge variant="outline" className="gap-1 border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300">
              <Star className="size-3 fill-amber-400 text-amber-500" aria-hidden />
              لایک مدیریت
            </Badge>
          )}

          <div className="grow" />
          <Button
            variant="ghost" size="sm" className="gap-1.5 text-muted-foreground"
            onClick={toggleComments}
            aria-expanded={showComments}
            aria-label="کامنت‌ها"
          >
            <MessageCircle className="size-4" aria-hidden />
            {faNum(r.commentCount)}
          </Button>
        </div>

        {/* کامنت‌ها */}
        {showComments && (
          <div className="space-y-2 border-t pt-2.5">
            {commentsLoading ? (
              <div className="flex justify-center py-3" role="status" aria-label="در حال دریافت کامنت‌ها">
                <Loader2 className="size-4 animate-spin text-brand-600" />
              </div>
            ) : (comments ?? []).length === 0 ? (
              <p className="text-xs text-muted-foreground">اولین کامنت را شما بنویسید…</p>
            ) : (
              <div className="max-h-64 space-y-2 overflow-y-auto pe-1">
                {(comments ?? []).map((c) => (
                  <div key={c.id} className="rounded-lg bg-muted/60 p-2.5 text-sm">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-xs font-bold">{c.userName}</p>
                      {(c.userId === myUserId || myRole === 'MANAGEMENT' || myRole === 'ADMIN') && (
                        <Button
                          variant="ghost" size="icon" className="size-6 text-muted-foreground hover:text-red-600"
                          aria-label="حذف کامنت"
                          onClick={() => deleteComment(c.id)}
                        >
                          <Trash2 className="size-3.5" aria-hidden />
                        </Button>
                      )}
                    </div>
                    <p className="mt-0.5 whitespace-pre-wrap text-sm">{c.body}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">{faDate(c.createdAt)}</p>
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-center gap-2">
              <Input
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="کامنت بنویسید…"
                aria-label="متن کامنت"
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendComment() } }}
              />
              <Button
                size="icon" className="size-9 shrink-0 bg-brand-600 text-white hover:bg-brand-700"
                onClick={sendComment} disabled={sendingComment || !commentText.trim()}
                aria-label="ارسال کامنت"
              >
                {sendingComment ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Send className="size-4" aria-hidden />}
              </Button>
            </div>
          </div>
        )}
      </CardContent>

      {/* لایت‌باکس عکس */}
      <Dialog open={!!lightbox} onOpenChange={(open) => { if (!open) setLightbox(null) }}>
        <DialogContent className="max-h-[95dvh] p-2 sm:max-w-2xl">
          <DialogHeader className="sr-only">
            <DialogTitle>نمایش عکس گزارش</DialogTitle>
            <DialogDescription>برای بستن، دکمه بستن را بزنید</DialogDescription>
          </DialogHeader>
          {lightbox && (
            <img src={lightbox} alt="نمایش عکس گزارش" className="max-h-[80dvh] w-full rounded-lg object-contain" />
          )}
          <DialogFooter className="justify-center">
            <Button variant="outline" onClick={() => setLightbox(null)}>بستن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
