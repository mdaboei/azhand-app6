import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { faNum } from '@/lib/persian'

/** چاپ لیست ماشین‌آلات */
export default async function PrintMachinesPage() {
  const machines = await db.machine.findMany({
    orderBy: { name: 'asc' },
    include: {
      _count: { select: { policies: { where: { status: 'ACTIVE' } } } },
      fuelCard: {
        select: {
          cardNumber: true,
          assignedAt: true,
          holder: { select: { fullName: true } },
          project: { select: { name: true } },
        },
      },
    },
  })

  return (
    <PrintShell
      title="فهرست ماشین‌آلات"
      subtitle={`تعداد: ${faNum(machines.length)} دستگاه`}
      roles={['MACHINERY', 'INSURANCE', 'MANAGEMENT', 'ADMIN']}
      panels={['MACHINERY']}
    >
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-zinc-100 print:bg-zinc-100">
            {['ردیف', 'نام ماشین', 'شماره دستگاه', 'نام صاحب خودرو', 'شماره شاسی', 'مدل/تیپ', 'شماره پلاک', 'سال ساخت', 'وضعیت', 'بیمه‌نامه فعال'].map((h) => (
              <th key={h} className="border border-zinc-400 px-2 py-1.5 text-right font-bold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {machines.map((m, i) => (
            <tr key={m.id}>
              <td className="border border-zinc-400 px-2 py-1.5 text-center">{faNum(i + 1)}</td>
              <td className="border border-zinc-400 px-2 py-1.5 font-medium">{m.name}</td>
              <td className="border border-zinc-400 px-2 py-1.5">{m.deviceNumber || '—'}</td>
              <td className="border border-zinc-400 px-2 py-1.5">{m.ownerName || '—'}</td>
              <td className="border border-zinc-400 px-2 py-1.5" dir="ltr">{m.chassisNumber || '—'}</td>
              <td className="border border-zinc-400 px-2 py-1.5">{m.model || '—'}</td>
              <td className="border border-zinc-400 px-2 py-1.5">{m.plateNumber || '—'}</td>
              <td className="border border-zinc-400 px-2 py-1.5">{m.year || '—'}</td>
              <td className="border border-zinc-400 px-2 py-1.5">
                {m.status === 'ACTIVE' ? 'فعال' : 'خارج از سرویس'}
              </td>
              <td className="border border-zinc-400 px-2 py-1.5 text-center">{faNum(m._count.policies)}</td>
            </tr>
          ))}
          {machines.length === 0 && (
            <tr>
              <td colSpan={10} className="border border-zinc-400 px-2 py-4 text-center text-zinc-500">
                ماشینی ثبت نشده است
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {machines.some((m) => m.fuelCard) && (
        <section className="mt-6">
          <h2 className="mb-2 text-sm font-bold">کارت‌های سوخت تحویل‌شده</h2>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-zinc-100 print:bg-zinc-100">
                {['ردیف', 'ماشین', 'شماره کارت سوخت', 'تحویل به کارمند', 'پروژه', 'تاریخ تحویل'].map((h) => (
                  <th key={h} className="border border-zinc-400 px-2 py-1.5 text-right font-bold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {machines
                .filter((m) => m.fuelCard)
                .map((m, i) => (
                  <tr key={m.id}>
                    <td className="border border-zinc-400 px-2 py-1.5 text-center">{faNum(i + 1)}</td>
                    <td className="border border-zinc-400 px-2 py-1.5 font-medium">{m.name}</td>
                    <td className="border border-zinc-400 px-2 py-1.5" dir="ltr">{m.fuelCard!.cardNumber}</td>
                    <td className="border border-zinc-400 px-2 py-1.5">
                      {m.fuelCard!.holder?.fullName || 'در انبار (تحویل نشده)'}
                    </td>
                    <td className="border border-zinc-400 px-2 py-1.5">{m.fuelCard!.project?.name || '—'}</td>
                    <td className="border border-zinc-400 px-2 py-1.5">{m.fuelCard!.assignedAt || '—'}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </section>
      )}
    </PrintShell>
  )
}
