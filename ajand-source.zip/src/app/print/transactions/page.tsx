import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { faMoney, faNum, padJalali } from '@/lib/persian'

/** چاپ فهرست تراکنش‌های مالی — با بازهٔ تاریخ یا ماه اختیاری */
export default async function PrintTransactionsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; month?: string }>
}) {
  const sp = await searchParams
  const from = sp.month ? `${sp.month}/01` : sp.from
  const to = sp.month ? `${sp.month}/31` : sp.to
  const where: Record<string, unknown> = {}
  if (from && to) where.date = { gte: padJalali(from), lte: padJalali(to) }
  else if (from) where.date = { gte: padJalali(from) }
  else if (to) where.date = { lte: padJalali(to) }

  const txs = await db.transaction.findMany({
    where,
    orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
    include: { bankAccount: { select: { name: true } } },
    take: 500,
  })

  const receive = txs.filter((t) => t.kind === 'RECEIVE').reduce((s, t) => s + t.amount, 0)
  const pay = txs.filter((t) => t.kind === 'PAY').reduce((s, t) => s + t.amount, 0)

  return (
    <PrintShell
      title="گزارش تراکنش‌های مالی"
      subtitle={`${sp.month ? `ماه: ${sp.month} — ` : ''}${sp.from || sp.to ? `بازه: ${sp.from || '...'} تا ${sp.to || '...'} — ` : ''}تعداد: ${faNum(txs.length)} تراکنش`}
      roles={['FINANCE', 'MANAGEMENT', 'ADMIN']}
      panels={['FINANCE']}
    >
      <div className="mb-3 grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-lg border border-zinc-300 p-3">
          <p className="text-xs text-zinc-500">جمع دریافت‌ها</p>
          <p className="font-bold">{faMoney(receive)}</p>
        </div>
        <div className="rounded-lg border border-zinc-300 p-3">
          <p className="text-xs text-zinc-500">جمع پرداخت‌ها</p>
          <p className="font-bold">{faMoney(pay)}</p>
        </div>
      </div>

      <table className="w-full border-collapse text-xs">
        <thead>
          <tr className="bg-zinc-100 print:bg-zinc-100">
            {['ردیف', 'نوع', 'مبلغ (تومان)', 'تاریخ', 'بابت', 'بانک/حساب'].map((h) => (
              <th key={h} className="border border-zinc-400 px-1.5 py-1.5 text-right font-bold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {txs.map((t, i) => (
            <tr key={t.id}>
              <td className="border border-zinc-400 px-1.5 py-1.5 text-center">{faNum(i + 1)}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{t.kind === 'RECEIVE' ? 'دریافت' : 'پرداخت'}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{faMoney(t.amount)}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{t.date}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{t.title}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{t.bankAccount?.name || '—'}</td>
            </tr>
          ))}
          {txs.length === 0 && (
            <tr>
              <td colSpan={6} className="border border-zinc-400 px-2 py-4 text-center text-zinc-500">
                تراکنشی با این بازه پیدا نشد
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </PrintShell>
  )
}
