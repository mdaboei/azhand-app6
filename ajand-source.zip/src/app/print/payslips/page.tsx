import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { requireRolePage } from '@/lib/guard'
import { faMoney, periodLabel } from '@/lib/persian'
import { parseItems } from '@/lib/payslip'
import type { Role } from '@/lib/types'

/**
 * چاپ فیش‌های حقوقی یک دوره — هر فیش یک برگه (شکست صفحه بین فیش‌ها)
 *  - کارمند: فقط فیش خودش
 *  - منابع انسانی/مدیریت/ادمین: دورهٔ کامل یا فیش یک نفر (?userId=)
 * ?period=1404/08 الزامی برای واحد منابع انسانی؛ کارمند بدون period آخرین فیش خودش را می‌بیند.
 */
export default async function PrintPayslipsPage({
  searchParams,
}: {
  searchParams: Promise<{ period?: string; userId?: string }>
}) {
  const sp = await searchParams

  const roles: Role[] = ['HR', 'MANAGEMENT', 'ADMIN', 'EMPLOYEE']
  // اعتبارسنجی نقش + مجوز — کاربر غیرمجاز به پنل خودش هدایت می‌شود
  const { session } = await requireRolePage(roles, ['HR'])
  const isEmployee = session.role === 'EMPLOYEE'

  const userId = isEmployee ? session.userId : sp.userId || undefined
  const period = sp.period

  const slips = await db.payslip.findMany({
    where: { ...(period ? { period } : {}), ...(userId ? { userId } : {}) },
    orderBy: [{ period: 'desc' }, { createdAt: 'asc' }],
    include: {
      user: { select: { fullName: true, username: true, nationalId: true, position: true } },
      issuer: { select: { fullName: true } },
    },
    take: 100,
  })

  return (
    <PrintShell
      title={slips.length === 1 ? `فیش حقوقی ${slips[0].user.fullName}` : 'فیش‌های حقوقی'}
      subtitle={period ? `دوره: ${periodLabel(period)}` : undefined}
      roles={roles}
    >
      {slips.length === 0 && (
        <p className="rounded-lg border border-dashed p-6 text-center text-sm text-zinc-500">
          فیشی برای چاپ پیدا نشد
        </p>
      )}

      {slips.map((s, idx) => {
        const items = parseItems(s.items)
        const benefits = items.filter((i) => i.kind === 'BENEFIT')
        const deductions = items.filter((i) => i.kind === 'DEDUCTION')
        return (
          <article
            key={s.id}
            className={idx < slips.length - 1 ? 'break-after-page pb-6' : ''}
          >
            {/* شناسنامهٔ فیش */}
            <div className="mb-3 grid grid-cols-2 gap-x-6 gap-y-1.5 rounded-lg border border-zinc-300 p-3 text-sm">
              <p>
                <span className="text-zinc-500">نام و نام خانوادگی: </span>
                <span className="font-bold">{s.user.fullName}</span>
              </p>
              <p>
                <span className="text-zinc-500">دوره: </span>
                <span className="font-bold">{periodLabel(s.period)}</span>
              </p>
              <p>
                <span className="text-zinc-500">کد ملی: </span>
                {s.user.nationalId || '—'}
              </p>
              <p>
                <span className="text-zinc-500">سمت: </span>
                {s.user.position || '—'}
              </p>
            </div>

            {/* مزایا */}
            <p className="mb-1 mt-4 text-sm font-bold">مزایا</p>
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-zinc-100 print:bg-zinc-100">
                  <th className="border border-zinc-400 px-2 py-1 text-right">شرح</th>
                  <th className="border border-zinc-400 px-2 py-1 text-right">مبلغ (تومان)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-zinc-400 px-2 py-1">حقوق پایه</td>
                  <td className="border border-zinc-400 px-2 py-1">{faMoney(s.baseSalary)}</td>
                </tr>
                {benefits.map((b) => (
                  <tr key={b.title}>
                    <td className="border border-zinc-400 px-2 py-1">{b.title}</td>
                    <td className="border border-zinc-400 px-2 py-1">{faMoney(b.amount)}</td>
                  </tr>
                ))}
                {benefits.length === 0 && s.baseSalary === 0 && (
                  <tr>
                    <td colSpan={2} className="border border-zinc-400 px-2 py-1 text-center text-zinc-400">
                      —
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

            {/* کسورات */}
            <p className="mb-1 mt-4 text-sm font-bold">کسورات</p>
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-zinc-100 print:bg-zinc-100">
                  <th className="border border-zinc-400 px-2 py-1 text-right">شرح</th>
                  <th className="border border-zinc-400 px-2 py-1 text-right">مبلغ (تومان)</th>
                </tr>
              </thead>
              <tbody>
                {deductions.map((d) => (
                  <tr key={d.title}>
                    <td className="border border-zinc-400 px-2 py-1">{d.title}</td>
                    <td className="border border-zinc-400 px-2 py-1">{faMoney(d.amount)}</td>
                  </tr>
                ))}
                {deductions.length === 0 && (
                  <tr>
                    <td className="border border-zinc-400 px-2 py-1 text-center text-zinc-400" colSpan={2}>
                      کسوری ثبت نشده
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

            {/* خالص پرداختی */}
            <div className="mt-4 flex items-center justify-between rounded-lg border-2 border-zinc-700 bg-zinc-100 print:bg-zinc-100 px-4 py-2.5">
              <span className="text-sm font-bold">خالص پرداختی</span>
              <span className="text-lg font-black">{faMoney(s.netPay)}</span>
            </div>

            {s.note ? <p className="mt-2 text-xs text-zinc-600">یادداشت: {s.note}</p> : null}

            <div className="mt-4 flex justify-between text-xs text-zinc-500">
              <span>صادرکننده: {s.issuer.fullName}</span>
              <span>امضای کارمند: ....................................</span>
            </div>
          </article>
        )
      })}
    </PrintShell>
  )
}
