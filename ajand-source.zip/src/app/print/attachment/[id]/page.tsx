import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { faDate } from '@/lib/persian'

/**
 * چاپ پیوست — پیوست بیمه‌نامه، سند ماشین یا رسید تحویل کارت سوخت؛
 * تصویر به‌صورت کامل در کاغذ؛ برای PDF، فایل در قاب نمایش داده می‌شود و
 * از خود نمایش‌دهندهٔ PDF مرورگر هم می‌توان چاپ کرد.
 */
export default async function PrintAttachmentPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params

  // اول پیوست بیمه‌نامه، بعد سند ماشین، بعد رسید کارت سوخت
  const insuranceAtt = await db.insuranceAttachment.findUnique({
    where: { id },
    select: {
      fileName: true,
      mimeType: true,
      createdAt: true,
      policy: { select: { policyNumber: true, machine: { select: { name: true } } } },
    },
  })

  const machineAtt = insuranceAtt
    ? null
    : await db.machineAttachment.findUnique({
        where: { id },
        select: {
          fileName: true,
          mimeType: true,
          createdAt: true,
          machineId: true,
          machine: { select: { name: true, deviceNumber: true } },
        },
      })

  const fuelAtt =
    insuranceAtt || machineAtt
      ? null
      : await db.fuelCardAttachment.findUnique({
          where: { id },
          select: {
            fileName: true,
            mimeType: true,
            createdAt: true,
            card: {
              select: {
                cardNumber: true,
                machine: { select: { name: true } },
              },
            },
          },
        })

  if (!insuranceAtt && !machineAtt && !fuelAtt) {
    return (
      <PrintShell title="چاپ پیوست" roles={['INSURANCE', 'MACHINERY', 'ADMIN', 'MANAGEMENT']} panels={['MACHINERY']}>
        <p className="rounded-lg border border-dashed p-6 text-center text-sm text-zinc-500">
          پیوست پیدا نشد یا حذف شده است
        </p>
      </PrintShell>
    )
  }

  const isImage = (insuranceAtt ?? machineAtt ?? fuelAtt)!.mimeType.startsWith('image/')
  const isPdf = (insuranceAtt ?? machineAtt ?? fuelAtt)!.mimeType === 'application/pdf'
  const fileName = (insuranceAtt ?? machineAtt ?? fuelAtt)!.fileName
  const createdAt = (insuranceAtt ?? machineAtt ?? fuelAtt)!.createdAt.toISOString()

  const src = insuranceAtt
    ? `/api/insurance/attachments/${id}?mode=inline`
    : machineAtt
      ? `/api/machines/${machineAtt.machineId}/attachments/${id}?mode=inline`
      : `/api/machines/${fuelAtt!.card.machine.id}/fuel-card/attachments/${id}?mode=inline`

  const title = insuranceAtt
    ? `پیوست بیمه‌نامه ${insuranceAtt.policy.policyNumber}`
    : machineAtt
      ? `سند ماشین ${machineAtt.machine.name}`
      : `رسید تحویل کارت سوخت ${fuelAtt!.card.cardNumber}`

  const subtitle = insuranceAtt
    ? `ماشین: ${insuranceAtt.policy.machine.name} — بارگذاری: ${faDate(createdAt)}`
    : machineAtt
      ? `ماشین: ${machineAtt.machine.name}${machineAtt.machine.deviceNumber ? ` (${machineAtt.machine.deviceNumber})` : ''} — بارگذاری: ${faDate(createdAt)}`
      : `ماشین: ${fuelAtt!.card.machine.name} — کارت سوخت: ${fuelAtt!.card.cardNumber} — بارگذاری: ${faDate(createdAt)}`

  return (
    <PrintShell title={title} subtitle={subtitle} roles={['INSURANCE', 'MACHINERY', 'ADMIN', 'MANAGEMENT']} panels={['MACHINERY']}>
      <p className="mb-3 text-sm text-zinc-600">نام فایل: {fileName}</p>

      {isImage ? (
        <img src={src} alt={`پیوست ${fileName}`} className="mx-auto max-w-full rounded-lg border" />
      ) : isPdf ? (
        <div>
          <p className="mb-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800 print:hidden">
            برای چاپ PDF از دکمهٔ نمایش‌دهندهٔ پایین (آیکون چاپ) یا دکمهٔ بالای صفحه استفاده کنید.
          </p>
          <iframe src={src} title={`پیوست ${fileName}`} className="h-[75vh] w-full rounded-lg border print:h-[85vh]" />
        </div>
      ) : (
        <p className="rounded-lg border border-dashed p-6 text-center text-sm text-zinc-500">
          این نوع فایل برای چاپ پشتیبانی نمی‌شود — آن را دانلود و جداگانه چاپ کنید
        </p>
      )}
    </PrintShell>
  )
}
