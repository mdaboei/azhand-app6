import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { computePeriods, computeStats, syncProfitAccount, todayJalali, type AccountCore, type ProfitCalcMethod, type ProfitPartialRule } from '@/lib/profit-engine'
import { PROFIT_METHOD_LABELS, PROFIT_PAYTYPE_LABELS, type ProfitPayType } from '@/lib/types'
import { faMoney, faNum, padJalali } from '@/lib/persian'

const REPORT_TITLES: Record<string, string> = {
  INTEREST_PAID: 'گزارش سود پرداخت‌شده در بازه زمانی',
  INTEREST_UNPAID: 'گزارش سود پرداخت‌نشده (معوق)',
  PRINCIPAL_REMAINING: 'گزارش اصل سرمایه باقی‌مانده',
  MATURITY_UPCOMING: 'گزارش سررسیدهای پیش رو',
  OVERALL: 'گزارش کلی بدهی شرکت به اشخاص',
}

/** چاپ گزارش‌های کلی حساب‌های سوددار — ?type=&from=&to=&days= */
export default async function PrintProfitReportPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string; from?: string; to?: string; days?: string }>
}) {
  const sp = await searchParams
  const type = sp.type ?? 'OVERALL'
  const title = REPORT_TITLES[type] ?? 'گزارش حساب‌های سوددار'
  const today = todayJalali()

  // برای صحت گزارش، ابتدا دوره‌های قطعی همهٔ حساب‌ها همگام می‌شود
  const all = await db.profitAccount.findMany({ orderBy: [{ status: 'asc' }, { createdAt: 'desc' }] })
  for (const a of all) await syncProfitAccount(a.id)
  const accounts = await db.profitAccount.findMany({ orderBy: [{ status: 'asc' }, { createdAt: 'desc' }] })

  const rows: {
    acc: NonNullable<(typeof accounts)[number]>
    accrued: number
    capitalized: number
    paidInterest: number
    paidPrincipal: number
    currentPrincipal: number
    unpaidInterest: number
    totalDebt: number
    monthsElapsed: number
    maturityReached: boolean
    daysToMaturity: number | null
  }[] = []
  for (const acc of accounts) {
    const core: AccountCore = {
      principal: acc.principal,
      startDate: acc.startDate,
      monthlyRate: acc.monthlyRate,
      calcMethod: acc.calcMethod as ProfitCalcMethod,
      partialRule: acc.partialRule as ProfitPartialRule,
      maturityDate: acc.maturityDate,
      status: acc.status as 'ACTIVE' | 'CLOSED',
      closedAt: acc.closedAt,
    }
    const pays = await db.profitPayment.findMany({ where: { accountId: acc.id } })
    const payCores = pays.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart }))
    const s = computeStats(core, computePeriods(core, payCores, today), payCores, today)
    rows.push({ acc, ...s })
  }

  return (
    <PrintShell
      title={title}
      subtitle={
        type === 'INTEREST_PAID'
          ? `بازه: ${sp.from ?? '…'} تا ${sp.to ?? '…'}`
          : type === 'MATURITY_UPCOMING'
            ? `تا ${faNum(Number(sp.days ?? '30') || 30)} روز آینده (و سررسیدهای گذشته)`
            : `تعداد: ${faNum(accounts.length)} حساب`
      }
      roles={['FINANCE', 'MANAGEMENT', 'ADMIN']}
      panels={['FINANCE']}
    >
      {/* ── سود پرداخت‌شده در بازه ── */}
      {type === 'INTEREST_PAID' ? (
        <InterestPaidTable from={sp.from} to={sp.to} />
      ) : (
        <>
          {type === 'INTEREST_UNPAID' && (
            <OverallTable
              rows={rows.filter((r) => r.unpaidInterest > 0)}
              columns={['accrued', 'paidInterest', 'unpaidInterest', 'monthsElapsed']}
              totalKey="unpaidInterest"
              totalLabel="جمع سود پرداخت‌نشده"
            />
          )}
          {type === 'PRINCIPAL_REMAINING' && (
            <OverallTable
              rows={rows.filter((r) => r.currentPrincipal > 0)}
              columns={['principal', 'paidPrincipal', 'currentPrincipal', 'monthsElapsed']}
              totalKey="currentPrincipal"
              totalLabel="جمع مانده اصل سرمایه"
            />
          )}
          {type === 'MATURITY_UPCOMING' && (
            <MaturityTable rows={rows.filter((r) => (r.daysToMaturity ?? 99999) <= (Number(sp.days ?? '30') || 30))} />
          )}
          {type === 'OVERALL' && (
            <OverallTable
              rows={rows}
              columns={['currentPrincipal', 'unpaidInterest', 'totalDebt']}
              totalKey="totalDebt"
              totalLabel="جمع کل بدهی شرکت به اشخاص"
              showMethod
            />
          )}
        </>
      )}
    </PrintShell>
  )
}

// ─── جدول سود پرداخت‌شده در بازه ────────────────────────────────────

async function InterestPaidTable({ from, to }: { from?: string; to?: string }) {
  const all = await db.profitPayment.findMany({
    where: { interestPart: { gt: 0 } },
    orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
    include: { account: { select: { personName: true, contractNo: true } } },
  })
  const filtered = all.filter((p) => {
    const d = padJalali(p.date)
    if (from && d < padJalali(from)) return false
    if (to && d > padJalali(to)) return false
    return true
  })
  const total = filtered.reduce((s, p) => s + p.interestPart, 0)
  return (
    <table className="w-full border-collapse text-[10px]">
      <thead>
        <tr className="bg-zinc-100 print:bg-zinc-100">
          {['ردیف', 'تاریخ', 'نام شخص', 'بابت', 'سود پرداخت‌شده', 'بخش اصل همان پرداخت', 'مبلغ کل', 'توضیح'].map((h) => (
            <th key={h} className="border border-zinc-400 px-1 py-1 text-right font-bold">{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {filtered.map((p, i) => (
          <tr key={p.id}>
            <td className="border border-zinc-400 px-1 py-1 text-center">{faNum(i + 1)}</td>
            <td className="border border-zinc-400 px-1 py-1 text-center">{p.date}</td>
            <td className="border border-zinc-400 px-1 py-1">{p.account.personName}</td>
            <td className="border border-zinc-400 px-1 py-1">{PROFIT_PAYTYPE_LABELS[p.payType as ProfitPayType] ?? p.payType}</td>
            <td className="border border-zinc-400 px-1 py-1 font-bold">{faMoney(p.interestPart)}</td>
            <td className="border border-zinc-400 px-1 py-1">{p.principalPart > 0 ? faMoney(p.principalPart) : '—'}</td>
            <td className="border border-zinc-400 px-1 py-1">{faMoney(p.amount)}</td>
            <td className="border border-zinc-400 px-1 py-1">{p.note ?? '—'}</td>
          </tr>
        ))}
        {filtered.length === 0 && (
          <tr>
            <td colSpan={8} className="border border-zinc-400 px-2 py-4 text-center text-zinc-500">
              در این بازه، سودی پرداخت نشده است
            </td>
          </tr>
        )}
        {filtered.length > 0 && (
          <tr className="bg-zinc-100 font-bold">
            <td colSpan={4} className="border border-zinc-400 px-1 py-1">جمع کل</td>
            <td className="border border-zinc-400 px-1 py-1">{faMoney(total)}</td>
            <td colSpan={3} className="border border-zinc-400 px-1 py-1"></td>
          </tr>
        )}
      </tbody>
    </table>
  )
}

// ─── جدول کلی استاندارد ────────────────────────────────────────────

type ReportRow = {
  acc: NonNullable<Awaited<ReturnType<typeof db.profitAccount.findFirst>>>
  accrued: number
  capitalized: number
  paidInterest: number
  paidPrincipal: number
  currentPrincipal: number
  unpaidInterest: number
  totalDebt: number
  monthsElapsed: number
  maturityReached: boolean
  daysToMaturity: number | null
}

function OverallTable({
  rows,
  columns,
  totalKey,
  totalLabel,
  showMethod = false,
}: {
  rows: ReportRow[]
  columns: ('principal' | 'accrued' | 'paidInterest' | 'unpaidInterest' | 'paidPrincipal' | 'currentPrincipal' | 'totalDebt' | 'monthsElapsed')[]
  totalKey: 'unpaidInterest' | 'currentPrincipal' | 'totalDebt'
  totalLabel: string
  showMethod?: boolean
}) {
  const headers: Record<string, string> = {
    principal: 'اصل اولیه',
    accrued: 'سود ایجادشده',
    paidInterest: 'سود پرداخت‌شده',
    unpaidInterest: 'سود پرداخت‌نشده',
    paidPrincipal: 'اصل بازپرداخت‌شده',
    currentPrincipal: 'مانده اصل سرمایه',
    totalDebt: 'بدهی کل شرکت',
    monthsElapsed: 'ماه‌های سپری‌شده',
  }
  const values: Record<string, (r: ReportRow) => string> = {
    principal: (r) => faMoney(r.acc.principal),
    accrued: (r) => faMoney(r.accrued),
    paidInterest: (r) => faMoney(r.paidInterest),
    unpaidInterest: (r) => faMoney(r.unpaidInterest),
    paidPrincipal: (r) => faMoney(r.paidPrincipal),
    currentPrincipal: (r) => faMoney(r.currentPrincipal),
    totalDebt: (r) => faMoney(r.totalDebt),
    monthsElapsed: (r) => `${faNum(r.monthsElapsed)} ماه`,
  }
  const total = rows.reduce((s, r) => s + r[totalKey], 0)
  const colCount = 2 + (showMethod ? 1 : 0) + columns.length

  return (
    <>
      <table className="w-full border-collapse text-[10px]">
        <thead>
          <tr className="bg-zinc-100 print:bg-zinc-100">
            <th className="border border-zinc-400 px-1 py-1 text-right font-bold">نام شخص</th>
            {showMethod && <th className="border border-zinc-400 px-1 py-1 text-right font-bold">روش محاسبه</th>}
            {columns.map((c) => (
              <th key={c} className="border border-zinc-400 px-1 py-1 text-right font-bold">{headers[c]}</th>
            ))}
            <th className="border border-zinc-400 px-1 py-1 text-right font-bold">وضعیت</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.acc.id}>
              <td className="border border-zinc-400 px-1 py-1">{r.acc.personName}</td>
              {showMethod && (
                <td className="border border-zinc-400 px-1 py-1">
                  {PROFIT_METHOD_LABELS[r.acc.calcMethod as ProfitCalcMethod] ?? r.acc.calcMethod}
                </td>
              )}
              {columns.map((c) => (
                <td key={c} className="border border-zinc-400 px-1 py-1">{values[c](r)}</td>
              ))}
              <td className="border border-zinc-400 px-1 py-1">
                {r.acc.status === 'ACTIVE' ? 'فعال' : `بسته — ${r.acc.closedAt ?? ''}`}
              </td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={colCount + 1} className="border border-zinc-400 px-2 py-4 text-center text-zinc-500">
                موردی برای این گزارش پیدا نشد
              </td>
            </tr>
          )}
          {rows.length > 0 && (
            <tr className="bg-zinc-100 font-black">
              <td colSpan={colCount - 1} className="border border-zinc-400 px-1 py-1">{totalLabel}</td>
              <td className="border border-zinc-400 px-1 py-1">{faMoney(total)}</td>
              <td className="border border-zinc-400 px-1 py-1"></td>
            </tr>
          )}
        </tbody>
      </table>
      <p className="mt-3 text-[10px] leading-5 text-zinc-500">
        همهٔ مبالغ به تومان است و بر مبنای دفتر دوره‌های قطعی سامانه در تاریخ گزارش محاسبه شده است.
      </p>
    </>
  )
}

// ─── جدول سررسیدها ─────────────────────────────────────────────────

function MaturityTable({ rows }: { rows: ReportRow[] }) {
  const sorted = [...rows].sort((a, b) => (a.daysToMaturity ?? 0) - (b.daysToMaturity ?? 0))
  return (
    <table className="w-full border-collapse text-[10px]">
      <thead>
        <tr className="bg-zinc-100 print:bg-zinc-100">
          {['نام شخص', 'تاریخ سررسید', 'روز تا سررسید', 'وضعیت', 'مانده اصل', 'سود پرداخت‌نشده', 'بدهی کل'].map((h) => (
            <th key={h} className="border border-zinc-400 px-1 py-1 text-right font-bold">{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {sorted.map((r) => (
          <tr key={r.acc.id}>
            <td className="border border-zinc-400 px-1 py-1">{r.acc.personName}</td>
            <td className="border border-zinc-400 px-1 py-1 text-center">{r.acc.maturityDate ?? '—'}</td>
            <td className="border border-zinc-400 px-1 py-1 text-center">
              {(r.daysToMaturity ?? 0) < 0 ? `گذشته (${faNum(Math.abs(r.daysToMaturity ?? 0))} روز)` : faNum(r.daysToMaturity ?? 0)}
            </td>
            <td className="border border-zinc-400 px-1 py-1">
              {r.maturityReached ? 'رسیده به سررسید' : r.acc.status === 'ACTIVE' ? 'فعال' : 'بسته'}
            </td>
            <td className="border border-zinc-400 px-1 py-1">{faMoney(r.currentPrincipal)}</td>
            <td className="border border-zinc-400 px-1 py-1">{faMoney(r.unpaidInterest)}</td>
            <td className="border border-zinc-400 px-1 py-1 font-bold">{faMoney(r.totalDebt)}</td>
          </tr>
        ))}
        {sorted.length === 0 && (
          <tr>
            <td colSpan={7} className="border border-zinc-400 px-2 py-4 text-center text-zinc-500">
              سررسیدی در این بازه وجود ندارد
            </td>
          </tr>
        )}
      </tbody>
    </table>
  )
}
