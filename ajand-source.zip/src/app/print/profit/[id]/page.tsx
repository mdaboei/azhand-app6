import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { syncProfitAccount, todayJalali, computePeriods, computeStats, type AccountCore, type PaymentCore } from '@/lib/profit-engine'
import { PROFIT_METHOD_LABELS, PROFIT_PAYTYPE_LABELS, PROFIT_RULE_LABELS, type ProfitCalcMethod, type ProfitPayType, type ProfitPartialRule } from '@/lib/types'
import { faMoney, faNum, padJalali } from '@/lib/persian'

/** چاپ گزارش کامل حساب سوددار یک شخص */
export default async function PrintProfitAccountPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  await syncProfitAccount(id)
  const acc = await db.profitAccount.findUnique({ where: { id } })
  if (!acc) {
    return (
      <PrintShell title="گزارش حساب سوددار" roles={['FINANCE', 'MANAGEMENT', 'ADMIN']} panels={['FINANCE']}>
        <p className="py-10 text-center text-sm text-zinc-500">حساب موردنظر پیدا نشد.</p>
      </PrintShell>
    )
  }
  const paymentsRaw = await db.profitPayment.findMany({
    where: { accountId: id },
    orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
  })
  const periodsRaw = await db.profitPeriod.findMany({ where: { accountId: id }, orderBy: { idx: 'asc' } })

  const today = todayJalali()
  const core: AccountCore = {
    principal: acc.principal,
    startDate: acc.startDate,
    monthlyRate: acc.monthlyRate,
    calcMethod: acc.calcMethod as ProfitCalcMethod,
    partialRule: acc.partialRule as ProfitPartialRule,
    maturityDate: acc.maturityDate,
    status: acc.status as 'ACTIVE' | 'CLOSED',
    closedAt: acc.closedAt,
  }
  const payCores: PaymentCore[] = paymentsRaw.map((p) => ({ date: p.date, interestPart: p.interestPart, principalPart: p.principalPart }))
  const stats = computeStats(core, computePeriods(core, payCores, today), payCores, today)
  const isCompound = acc.calcMethod === 'COMPOUND'

  // پرداخت‌های هر دوره برای جدول ماهانه
  const inRange = (d: string, from: string, to: string) => {
    const x = padJalali(d)
    return x >= padJalali(from) && x <= padJalali(to)
  }

  return (
    <PrintShell
      title="گزارش حساب سوددار شخص"
      subtitle={`${acc.personName}${acc.contractNo ? ` — سند ${acc.contractNo}` : ''}`}
      roles={['FINANCE', 'MANAGEMENT', 'ADMIN']}
      panels={['FINANCE']}
    >
      {/* مشخصات و خلاصه */}
      <table className="mb-4 w-full border-collapse text-xs">
        <tbody>
          <tr>
            <td className="w-1/4 border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">نام شخص</td>
            <td className="border border-zinc-400 px-2 py-1.5">{acc.personName}</td>
            <td className="w-1/4 border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">اصل سرمایه اولیه</td>
            <td className="border border-zinc-400 px-2 py-1.5">{faMoney(acc.principal)}</td>
          </tr>
          <tr>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">درصد سود ماهانه</td>
            <td className="border border-zinc-400 px-2 py-1.5">{faNum(acc.monthlyRate)}٪</td>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">روش محاسبه سود</td>
            <td className="border border-zinc-400 px-2 py-1.5">
              {PROFIT_METHOD_LABELS[acc.calcMethod as ProfitCalcMethod] ?? acc.calcMethod}
            </td>
          </tr>
          <tr>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">تاریخ شروع</td>
            <td className="border border-zinc-400 px-2 py-1.5">{acc.startDate}</td>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">تاریخ سررسید</td>
            <td className="border border-zinc-400 px-2 py-1.5">{acc.maturityDate ?? '—'}</td>
          </tr>
          <tr>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">قاعده ماه ناقص</td>
            <td className="border border-zinc-400 px-2 py-1.5">
              {PROFIT_RULE_LABELS[acc.partialRule as ProfitPartialRule] ?? acc.partialRule}
            </td>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">ماه‌های سپری‌شده</td>
            <td className="border border-zinc-400 px-2 py-1.5">{faNum(stats.monthsElapsed)} ماه</td>
          </tr>
          <tr>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">وضعیت حساب</td>
            <td className="border border-zinc-400 px-2 py-1.5">
              {acc.status === 'ACTIVE' ? 'فعال' : `بسته — ${acc.closedAt ?? ''}`}
            </td>
            <td className="border border-zinc-400 bg-zinc-100 px-2 py-1.5 font-bold">شماره قرارداد</td>
            <td className="border border-zinc-400 px-2 py-1.5">{acc.contractNo ?? '—'}</td>
          </tr>
        </tbody>
      </table>

      <div className="mb-4 grid grid-cols-3 gap-2 text-xs">
        <div className="rounded border border-zinc-400 p-2">
          <p className="text-zinc-500">مانده اصل سرمایه</p>
          <p className="font-bold">{faMoney(stats.currentPrincipal)}</p>
        </div>
        <div className="rounded border border-zinc-400 p-2">
          <p className="text-zinc-500">{isCompound ? 'سود پرداخت‌نشده (خارج از اصل)' : 'سود معوق و پرداخت‌نشده'}</p>
          <p className="font-bold">{faMoney(stats.unpaidInterest)}</p>
        </div>
        <div className="rounded border-2 border-zinc-700 bg-zinc-100 p-2">
          <p className="text-zinc-500">مجموع کل بدهی شرکت به شخص</p>
          <p className="font-black">{faMoney(stats.totalDebt)}</p>
        </div>
      </div>

      <div className="mb-2 grid grid-cols-4 gap-2 text-[11px]">
        <div className="rounded border border-zinc-300 p-1.5">
          <span className="text-zinc-500">سود ایجادشده: </span>
          <span className="font-bold">{faMoney(stats.accrued)}</span>
        </div>
        <div className="rounded border border-zinc-300 p-1.5">
          <span className="text-zinc-500">سود پرداخت‌شده: </span>
          <span className="font-bold">{faMoney(stats.paidInterest)}</span>
        </div>
        <div className="rounded border border-zinc-300 p-1.5">
          <span className="text-zinc-500">اصل بازپرداخت‌شده: </span>
          <span className="font-bold">{faMoney(stats.paidPrincipal)}</span>
        </div>
        <div className="rounded border border-zinc-300 p-1.5">
          <span className="text-zinc-500">{isCompound ? 'سود مرکب‌شده: ' : '—'}</span>
          <span className="font-bold">{isCompound ? faMoney(stats.capitalized) : ''}</span>
        </div>
      </div>

      {/* جدول ماهانه */}
      <h2 className="mb-1 mt-4 text-sm font-black">تاریخچهٔ ماهانهٔ محاسبات</h2>
      <table className="w-full border-collapse text-[10px]">
        <thead>
          <tr className="bg-zinc-100 print:bg-zinc-100">
            {['دوره', 'بازه', 'روز', 'اصل ابتدای دوره', 'سود دوره', ...(isCompound ? ['مرکب‌شده'] : []), 'بازپرداخت اصل', 'اصل پایان دوره'].map((h) => (
              <th key={h} className="border border-zinc-400 px-1 py-1 text-right font-bold">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {periodsRaw.map((p) => {
            const paid = paymentsRaw
              .filter((x) => inRange(x.date, p.startDate, p.endDate))
              .reduce((s, x) => s + x.amount, 0)
            return (
              <tr key={p.id}>
                <td className="border border-zinc-400 px-1 py-1 text-center">{faNum(p.idx)}</td>
                <td className="border border-zinc-400 px-1 py-1 text-center whitespace-nowrap">{p.startDate} — {p.endDate}</td>
                <td className="border border-zinc-400 px-1 py-1 text-center">{faNum(p.days)}</td>
                <td className="border border-zinc-400 px-1 py-1">{faMoney(p.opening)}</td>
                <td className="border border-zinc-400 px-1 py-1 font-bold">{faMoney(p.interest)}</td>
                {isCompound && <td className="border border-zinc-400 px-1 py-1">{p.capitalized > 0 ? faMoney(p.capitalized) : '—'}</td>}
                <td className="border border-zinc-400 px-1 py-1">{p.principalPaid > 0 ? faMoney(p.principalPaid) : '—'}</td>
                <td className="border border-zinc-400 px-1 py-1">{faMoney(p.closing)}</td>
              </tr>
            )
          })}
          {stats.ongoing && (
            <tr className="bg-zinc-50">
              <td className="border border-zinc-400 px-1 py-1 text-center">{faNum(stats.ongoing.idx)}</td>
              <td className="border border-zinc-400 px-1 py-1 text-center whitespace-nowrap">
                {stats.ongoing.startDate} — {stats.ongoing.endDate}
              </td>
              <td className="border border-zinc-400 px-1 py-1 text-center">{faNum(stats.ongoing.daysElapsed)}</td>
              <td className="border border-zinc-400 px-1 py-1">
                {faMoney(periodsRaw.length > 0 ? periodsRaw[periodsRaw.length - 1].closing : acc.principal)}
              </td>
              <td className="border border-zinc-400 px-1 py-1 font-bold">~{faMoney(stats.ongoing.accruedSoFar)}</td>
              {isCompound && <td className="border border-zinc-400 px-1 py-1">—</td>}
              <td className="border border-zinc-400 px-1 py-1">—</td>
              <td className="border border-zinc-400 px-1 py-1 text-zinc-500">در جریان</td>
            </tr>
          )}
          {periodsRaw.length === 0 && !stats.ongoing && (
            <tr>
              <td colSpan={isCompound ? 8 : 7} className="border border-zinc-400 px-2 py-3 text-center text-zinc-500">
                هنوز دوره‌ای قطعی نشده است
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* پرداخت‌ها */}
      <h2 className="mb-1 mt-4 text-sm font-black">تاریخچهٔ پرداخت‌ها</h2>
      <table className="w-full border-collapse text-[10px]">
        <thead>
          <tr className="bg-zinc-100 print:bg-zinc-100">
            {['ردیف', 'تاریخ', 'بابت', 'بخش سود', 'بخش اصل', 'مبلغ کل', 'توضیحات'].map((h) => (
              <th key={h} className="border border-zinc-400 px-1 py-1 text-right font-bold">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {paymentsRaw.map((p, i) => (
            <tr key={p.id}>
              <td className="border border-zinc-400 px-1 py-1 text-center">{faNum(i + 1)}</td>
              <td className="border border-zinc-400 px-1 py-1 text-center">{p.date}</td>
              <td className="border border-zinc-400 px-1 py-1">
                {PROFIT_PAYTYPE_LABELS[p.payType as ProfitPayType] ?? p.payType}
              </td>
              <td className="border border-zinc-400 px-1 py-1">{p.interestPart > 0 ? faMoney(p.interestPart) : '—'}</td>
              <td className="border border-zinc-400 px-1 py-1">{p.principalPart > 0 ? faMoney(p.principalPart) : '—'}</td>
              <td className="border border-zinc-400 px-1 py-1 font-bold">{faMoney(p.amount)}</td>
              <td className="border border-zinc-400 px-1 py-1">{p.note ?? '—'}</td>
            </tr>
          ))}
          {paymentsRaw.length === 0 && (
            <tr>
              <td colSpan={7} className="border border-zinc-400 px-2 py-3 text-center text-zinc-500">
                پرداختی ثبت نشده است
              </td>
            </tr>
          )}
          {paymentsRaw.length > 0 && (
            <tr className="bg-zinc-100 font-bold">
              <td colSpan={5} className="border border-zinc-400 px-1 py-1">جمع کل پرداخت‌ها</td>
              <td colSpan={2} className="border border-zinc-400 px-1 py-1">
                {faMoney(paymentsRaw.reduce((s, p) => s + p.amount, 0))}
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <p className="mt-3 text-[10px] leading-5 text-zinc-500">
        بدهی کل = اصل اولیه − بازپرداخت اصل + سود ایجادشده − سود پرداخت‌شده. مبالغ به تومان و بر اساس دفتر دوره‌های قطعی این سامانه است.
      </p>
    </PrintShell>
  )
}
