import { db } from '@/lib/db'
import { PrintShell } from '@/components/print/print-shell'
import { faNum, jalaliToday, padJalali } from '@/lib/persian'

/** چاپ فهرست بیمه‌نامه‌ها — با فیلتر ماشین و وضعیت از کوئری‌استرینگ */
export default async function PrintInsurancePage({
  searchParams,
}: {
  searchParams: Promise<{ machineId?: string; status?: string }>
}) {
  const sp = await searchParams
  const today = padJalali(jalaliToday())

  const where: Record<string, unknown> = {}
  if (sp.machineId) where.machineId = sp.machineId
  if (sp.status && sp.status !== 'all') where.status = sp.status

  const policies = await db.insurancePolicy.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    include: {
      machine: { select: { name: true, deviceNumber: true } },
      type: { select: { name: true } },
    },
    take: 500,
  })

  // وضعیت مؤثر: منقضی فقط از روی تاریخ
  const effective = (p: { status: string; endDate: string }) => {
    if (p.status === 'CANCELED') return 'لغو شده'
    if (p.endDate && padJalali(p.endDate) < today) return 'منقضی'
    return 'فعال'
  }

  const machineName = sp.machineId
    ? (await db.machine.findUnique({ where: { id: sp.machineId } }))?.name ?? null
    : null

  return (
    <PrintShell
      title="فهرست بیمه‌نامه‌ها"
      subtitle={`${machineName ? `ماشین: ${machineName} — ` : ''}تعداد: ${faNum(policies.length)} بیمه‌نامه`}
      roles={['INSURANCE', 'MACHINERY', 'MANAGEMENT', 'ADMIN']}
      panels={['MACHINERY']}
    >
      <table className="w-full border-collapse text-xs">
        <thead>
          <tr className="bg-zinc-100 print:bg-zinc-100">
            {['ردیف', 'ماشین', 'شماره دستگاه', 'نوع بیمه', 'بیمه‌گر', 'شماره بیمه‌نامه', 'از', 'تا', 'وضعیت'].map((h) => (
              <th key={h} className="border border-zinc-400 px-1.5 py-1.5 text-right font-bold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {policies.map((p, i) => (
            <tr key={p.id}>
              <td className="border border-zinc-400 px-1.5 py-1.5 text-center">{faNum(i + 1)}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5 font-medium">{p.machine.name}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{p.machine.deviceNumber || '—'}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{p.type.name}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{p.company}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{p.policyNumber}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{p.startDate}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{p.endDate}</td>
              <td className="border border-zinc-400 px-1.5 py-1.5">{effective(p)}</td>
            </tr>
          ))}
          {policies.length === 0 && (
            <tr>
              <td colSpan={9} className="border border-zinc-400 px-2 py-4 text-center text-zinc-500">
                بیمه‌نامه‌ای با این فیلترها پیدا نشد
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </PrintShell>
  )
}
