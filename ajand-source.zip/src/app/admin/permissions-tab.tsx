'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import { Loader2, Lock, RotateCcw, Save, ShieldCheck } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { PANEL_LABELS, type Panel } from '@/lib/types'
import { faDigits } from '@/lib/persian'

interface PermsData {
  panels: Panel[]
  roles: string[]
  roleLabels: Record<string, string>
  map: Record<string, Panel[]>
  userCounts: Record<string, number>
}

/** تب «دسترسی‌ها» — ماتریس نقش × پنل؛ نقش ADMIN همیشه کامل است */
export function PermissionsTab() {
  const [data, setData] = useState<PermsData | null>(null)
  const [draft, setDraft] = useState<Record<string, Panel[]> | null>(null)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const r = await fetch('/api/admin/permissions')
    if (!r.ok) { toast.error('دریافت دسترسی‌ها ناموفق بود'); return }
    const j: PermsData = await r.json()
    setData(j)
    setDraft(j.map)
  }, [])

  useEffect(() => { (async () => { await load() })() }, [load])

  const dirtyRoles = useMemo<string[]>(() => {
    if (!data || !draft) return []
    return data.roles.filter(
      (role) => role !== 'ADMIN' &&
        JSON.stringify([...(draft[role] ?? [])].sort()) !== JSON.stringify([...(data.map[role] ?? [])].sort()),
    )
  }, [data, draft])

  function toggle(role: string, panel: Panel) {
    if (!draft || role === 'ADMIN') return
    setDraft((prev) => {
      const cur = prev?.[role] ?? []
      const next = cur.includes(panel) ? cur.filter((p) => p !== panel) : [...cur, panel]
      return { ...prev!, [role]: next }
    })
  }

  async function save() {
    if (!draft || dirtyRoles.length === 0) return
    setSaving(true)
    try {
      for (const role of dirtyRoles) {
        const r = await fetch('/api/admin/permissions', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role, panels: draft[role] ?? [] }),
        })
        if (!r.ok) {
          const j = await r.json().catch(() => null)
          toast.error(j?.error || `ذخیرهٔ دسترسی ${data?.roleLabels[role] ?? role} ناموفق بود`)
          return
        }
      }
      toast.success('دسترسی‌ها ذخیره شد — از دفعهٔ بعد که کاربران صفحه را باز کنند اعمال می‌شود')
      await load()
    } finally {
      setSaving(false)
    }
  }

  if (!data || !draft) return <Skeleton className="h-64 w-full" />

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <ShieldCheck className="size-5 text-brand-600" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold">پیش‌فرض نقش‌ها</p>
              <p className="text-xs text-muted-foreground">
                پیش‌فرض هر نقش را مشخص کنید — برای تخصیص اختصاصی به هر کاربر، از «ویرایش کاربر» در تب کاربران استفاده کنید. نقش ادمین همیشه به همه‌جا دسترسی دارد.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] border-separate border-spacing-0 text-sm">
              <thead>
                <tr>
                  <th className="sticky right-0 z-10 bg-card pb-2 pl-2 text-right text-xs text-muted-foreground">نقش</th>
                  {data.panels.map((panel) => (
                    <th key={panel} className="pb-2 text-center text-xs text-muted-foreground">
                      {PANEL_LABELS[panel].replace('پنل ', '')}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.roles.map((role) => {
                  const locked = role === 'ADMIN'
                  const allowed = locked ? data.panels : (draft[role] ?? [])
                  return (
                    <tr key={role} className="border-t">
                      <td className="sticky right-0 z-10 bg-card py-2 pl-2">
                        <p className="font-medium whitespace-nowrap">{data.roleLabels[role] ?? role}</p>
                        <p className="text-xs text-muted-foreground">
                          {faDigits(data.userCounts[role] ?? 0)} کاربر
                        </p>
                      </td>
                      {data.panels.map((panel) => (
                        <td key={panel} className="py-2 text-center">
                          {locked ? (
                            <Lock className="mx-auto size-4 text-muted-foreground/50" aria-label="همیشه فعال" />
                          ) : (
                            <Switch
                              checked={allowed.includes(panel)}
                              onCheckedChange={() => toggle(role, panel)}
                              aria-label={`${data.roleLabels[role] ?? role} — ${panel}`}
                            />
                          )}
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap items-center gap-2 border-t pt-3">
            <Button size="sm" className="gap-1" onClick={save} disabled={saving || dirtyRoles.length === 0}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              ذخیره تغییرات {dirtyRoles.length > 0 && `(${faDigits(dirtyRoles.length)} نقش)`}
            </Button>
            {dirtyRoles.length > 0 && (
              <Button size="sm" variant="outline" className="gap-1" onClick={() => setDraft(data.map)}>
                <RotateCcw className="size-4" /> برگرداندن
              </Button>
            )}
            {dirtyRoles.length > 0 && (
              <Badge variant="secondary">تغییرات ذخیره‌نشده</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      <p className="px-1 text-xs text-muted-foreground">
        نکته: اگر نقشی هیچ پنلی نداشته باشد، کاربرانش فقط صفحهٔ اصلی (اطلاعیه‌ها) را می‌بینند.
      </p>
    </div>
  )
}
