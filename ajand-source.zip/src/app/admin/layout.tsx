import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('ADMIN')
  return (
    <PanelShell
      fullName={user.fullName}
      role="ADMIN"
      roleLabel={roleLabel}
      unitLabel="مدیریت سامانه"
      panels={panels}
    >
      {children}
    </PanelShell>
  )
}
