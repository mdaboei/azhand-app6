'use client'

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Loader2, RotateCcw, Save, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { PANEL_DESCRIPTIONS, PANEL_LABELS, type Panel, type Role } from '@/lib/types'
import { faDigits } from '@/lib/persian'

interface UserPanelsData {
  panels: Panel[]
  user: {
    id: string
    username: string
    fullName: string
    role: Role
    panels: Panel[]
    isCustom: boolean
  }
}

/**
 * ویرایشگر دسترسی ریزدانهٔ یک کاربر:
 * تیک هر بخش = تخصیص اختصاصی (مقدم بر پیش‌فرض نقش)؛
 * «حذف تخصیص» = بازگشت به پیش‌فرض نقش.
 */
export function UserPanelsEditor({ userId }: { userId: string }) {
  const [data, setData] = useState<UserPanelsData | null>(null)
  const [selected, setSelected] = useState<Set<Panel>>(new Set())
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const r = await fetch(`/api/admin/user-panels?userId=${userId}`)
    if (!r.ok) { toast.error('دریافت دسترسی‌ها ناموفق بود'); return }
    const j: UserPanelsData = await r.json()
    setData(j)
    setSelected(new Set(j.user.panels))
  }, [userId])

  useEffect(() => { (async () => { await load() })() }, [load])

  function toggle(p: Panel) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(p)) next.delete(p)
      else next.add(p)
      return next
    })
  }

  async function save() {
    if (!data) return
    setSaving(true)
    try {
      const r = await fetch('/api/admin/user-panels', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, panels: [...selected] }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(j?.error || 'ذخیره ناموفق بود'); return }
      toast.success('دسترسی‌های کاربر ذخیره شد')
      await load()
    } finally {
      setSaving(false)
    }
  }

  async function resetToRole() {
    setSaving(true)
    try {
      const r = await fetch('/api/admin/user-panels', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, reset: true }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { toast.error(j?.error || 'بازنشانی ناموفق بود'); return }
      toast.success('تخصیص اختصاصی حذف شد — پیش‌فرض نقش اعمال می‌شود')
      await load()
    } finally {
      setSaving(false)
    }
  }

  if (!data) return <Skeleton className="h-40 w-full" />

  const dirty = selected.size !== data.user.panels.length ||
    [...selected].some((p) => !data.user.panels.includes(p))

  return (
    <div className="space-y-3 rounded-lg border p-3">
      <div className="flex flex-wrap items-center gap-2">
        <ShieldCheck className="size-4 text-brand-600" aria-hidden />
        <p className="flex-1 text-sm font-bold">دسترسی بخش‌ها</p>
        {data.user.isCustom ? (
          <span className="rounded bg-brand-50 px-1.5 py-0.5 text-[11px] font-bold text-brand-700 dark:bg-brand-950 dark:text-brand-300">
            تخصیص اختصاصی
          </span>
        ) : (
          <span className="rounded bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground">
            پیش‌فرض نقش
          </span>
        )}
      </div>
      <p className="text-xs text-muted-foreground">
        بخش‌هایی که این کاربر می‌تواند وارد شود. بخش‌های فعال در منوی همبرگری پنل او نمایش داده می‌شوند.
        {faDigits(selected.size)} بخش انتخاب شده.
      </p>

      <div className="grid gap-2 sm:grid-cols-2">
        {data.panels.map((p) => (
          <div key={p} className="flex items-start gap-2 rounded-md border p-2">
            <Checkbox
              id={`panel-${userId}-${p}`}
              checked={selected.has(p)}
              onCheckedChange={() => toggle(p)}
              className="mt-0.5"
            />
            <Label htmlFor={`panel-${userId}-${p}`} className="cursor-pointer space-y-0.5">
              <span className="block text-sm font-medium leading-5">{PANEL_LABELS[p]}</span>
              <span className="block text-xs text-muted-foreground">{PANEL_DESCRIPTIONS[p]}</span>
            </Label>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" className="gap-1" onClick={save} disabled={saving || !dirty}>
          {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
          ذخیره دسترسی‌ها
        </Button>
        {data.user.isCustom && (
          <Button size="sm" variant="outline" className="gap-1" onClick={resetToRole} disabled={saving}>
            <RotateCcw className="size-4" /> حذف تخصیص (پیش‌فرض نقش)
          </Button>
        )}
      </div>
    </div>
  )
}
