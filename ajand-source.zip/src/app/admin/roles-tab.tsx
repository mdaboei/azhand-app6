'use client'

import { useState } from 'react'
import { toast } from 'sonner'
import { Loader2, Lock, Pencil, Plus, Tags, Trash2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { RoleInfoDTO } from '@/lib/types'
import { useRoles } from '@/hooks/use-roles'
import { faDigits } from '@/lib/persian'

/** سلکت نقش — با نقش‌های داینامیک؛ نقش فعلیِ خارج از فهرست هم حفظ می‌شود */
export function RoleSelect({
  roles, value, onChange, ariaLabel = 'نقش', exclude,
}: {
  roles: RoleInfoDTO[] | null
  value: string
  onChange: (v: string) => void
  ariaLabel?: string
  exclude?: string[]
}) {
  const list = (roles ?? []).filter((r) => !exclude || !exclude.includes(r.key))
  const known = list.some((r) => r.key === value)
  return (
    <select
      className="h-9 w-full rounded-md border bg-background px-3 text-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      aria-label={ariaLabel}
    >
      {!known && value ? <option value={value}>{value} (حذف‌شده)</option> : null}
      {(roles ?? []).length === 0 ? <option value="EMPLOYEE">کارمند</option> : null}
      {list.map((r) => (
        <option key={r.key} value={r.key}>{r.label}</option>
      ))}
    </select>
  )
}

/** تب «نقش‌ها» — افزودن نقش سفارشی + تغییرنام + حذف (نقش‌های پایه قفل‌اند) */
export function RolesTab() {
  const { roles, reload } = useRoles()
  const [label, setLabel] = useState('')
  const [adding, setAdding] = useState(false)
  const [renaming, setRenaming] = useState<RoleInfoDTO | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [savingRename, setSavingRename] = useState(false)
  const [deleting, setDeleting] = useState<RoleInfoDTO | null>(null)
  const [deletingBusy, setDeletingBusy] = useState(false)

  async function add() {
    const name = label.trim()
    if (name.length < 2) { toast.error('نام نقش حداقل ۲ نویسه است'); return }
    setAdding(true)
    try {
      const r = await fetch('/api/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ label: name }),
      })
      const j = await r.json()
      if (!r.ok) { toast.error(j.error || 'افزودن نقش ناموفق بود'); return }
      toast.success(`نقش «${name}» ساخته شد — حالا دسترسی‌هایش را در تب «دسترسی‌ها» تنظیم کنید`)
      setLabel('')
      await reload()
    } finally {
      setAdding(false)
    }
  }

  async function saveRename() {
    if (!renaming) return
    const name = renameValue.trim()
    if (name.length < 2) { toast.error('نام نقش حداقل ۲ نویسه است'); return }
    setSavingRename(true)
    try {
      const r = await fetch(`/api/roles/${renaming.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ label: name }),
      })
      const j = await r.json()
      if (!r.ok) { toast.error(j.error || 'ذخیره ناموفق بود'); return }
      toast.success('نام نقش عوض شد')
      setRenaming(null)
      await reload()
    } finally {
      setSavingRename(false)
    }
  }

  async function doDelete() {
    if (!deleting) return
    setDeletingBusy(true)
    try {
      const r = await fetch(`/api/roles/${deleting.id}`, { method: 'DELETE' })
      const j = await r.json().catch(() => null)
      if (!r.ok) { toast.error(j?.error || 'حذف ناموفق بود'); return }
      toast.success(`نقش «${deleting.label}» حذف شد`)
      setDeleting(null)
      await reload()
    } finally {
      setDeletingBusy(false)
    }
  }

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <Tags className="size-5 text-brand-600" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold">نقش جدید</p>
              <p className="text-xs text-muted-foreground">
                نقش سفارشی بسازید (مثل «مدیر پروژه»)، بعد در تب «دسترسی‌ها» مشخص کنید به کدام بخش‌ها وارد می‌شود.
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="نام نقش — مثلاً: سرپرست کارگاه"
              onKeyDown={(e) => { if (e.key === 'Enter') add() }}
            />
            <Button onClick={add} disabled={adding} className="gap-1 shrink-0">
              {adding ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} افزودن
            </Button>
          </div>
        </CardContent>
      </Card>

      {!roles ? (
        <Skeleton className="h-48 w-full" />
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="divide-y">
              {roles.map((r) => (
                <div key={r.id ?? r.key} className="flex items-center gap-3 p-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-bold">{r.label}</p>
                      {r.isSystem
                        ? <Badge variant="secondary" className="gap-1"><Lock className="size-3" /> پایه</Badge>
                        : <Badge variant="outline">سفارشی</Badge>}
                    </div>
                    <p className="dir-ltr text-right text-[11px] text-muted-foreground">
                      {faDigits(r.userCount)} کاربر
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1"
                    onClick={() => { setRenaming(r); setRenameValue(r.label) }}
                  >
                    <Pencil className="size-4" /> تغییر نام
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-9 text-destructive"
                    aria-label={`حذف نقش ${r.label}`}
                    disabled={r.isSystem}
                    onClick={() => setDeleting(r)}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <p className="px-1 text-xs text-muted-foreground">
        نکته: نقش‌های پایه ستون برنامه‌اند و حذف نمی‌شوند، ولی نامشان را می‌توانید عوض کنید.
        نقش سفارشی فقط وقتی حذف می‌شود که هیچ کاربری آن را نداشته باشد.
      </p>

      {/* تغییر نام */}
      <Dialog open={!!renaming} onOpenChange={(v) => !v && setRenaming(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تغییر نام نقش — {renaming?.label}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs">نام نمایشی نقش</Label>
              <Input
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') saveRename() }}
              />
              {renaming && !renaming.isSystem && (
                <p className="text-xs text-muted-foreground">
                  شناسه داخلی نقش <span className="dir-ltr">{renaming.key}</span> تغییر نمی‌کند.
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button onClick={saveRename} disabled={savingRename} className="gap-1">
              {savingRename ? <Loader2 className="size-4 animate-spin" /> : <Pencil className="size-4" />} ذخیره
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* حذف */}
      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف نقش «{deleting?.label}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              ماتریس دسترسی این نقش هم پاک می‌شود. اگر کاربری با این نقش باقی مانده باشد، حذف انجام نمی‌شود.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); doDelete() }}
              disabled={deletingBusy}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deletingBusy ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />} حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
