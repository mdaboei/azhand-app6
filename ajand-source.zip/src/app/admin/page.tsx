'use client'

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import {
  FolderKanban, KeyRound, Loader2, Plus, ShieldCheck, ShieldOff, Tags, Trash2, UserCog, UsersRound,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { UserDTO, ProjectDTO } from '@/lib/types'
import { faDigits } from '@/lib/persian'
import { PermissionsTab } from './permissions-tab'
import { RolesTab, RoleSelect } from './roles-tab'
import { useRoles } from '@/hooks/use-roles'
import { UserPanelsEditor } from './user-panels-editor'

export default function AdminPage() {
  const [users, setUsers] = useState<UserDTO[] | null>(null)
  const [projects, setProjects] = useState<ProjectDTO[] | null>(null)

  const loadUsers = useCallback(async () => {
    const r = await fetch('/api/users')
    if (r.ok) setUsers(await r.json())
    else toast.error('دریافت کاربران ناموفق بود')
  }, [])
  const loadProjects = useCallback(async () => {
    const r = await fetch('/api/projects')
    if (r.ok) setProjects(await r.json())
  }, [])

  useEffect(() => {
    ;(async () => {
      await loadUsers()
      await loadProjects()
    })()
  }, [loadUsers, loadProjects])

  return (
    <div className="space-y-4">
      <Tabs defaultValue="users">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="users" className="gap-1"><UsersRound className="size-4" /> کاربران</TabsTrigger>
          <TabsTrigger value="projects" className="gap-1"><FolderKanban className="size-4" /> پروژه‌ها</TabsTrigger>
          <TabsTrigger value="permissions" className="gap-1"><ShieldCheck className="size-4" /> دسترسی‌ها</TabsTrigger>
          <TabsTrigger value="roles" className="gap-1"><Tags className="size-4" /> نقش‌ها</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-4">
          <UsersTab users={users} reload={loadUsers} />
        </TabsContent>

        <TabsContent value="projects" className="mt-4">
          <ProjectsTab projects={projects} reload={loadProjects} />
        </TabsContent>

        <TabsContent value="permissions" className="mt-4">
          <PermissionsTab />
        </TabsContent>

        <TabsContent value="roles" className="mt-4">
          <RolesTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// ─── کاربران ───────────────────────────────────────────────────────

function UsersTab({ users, reload }: { users: UserDTO[] | null; reload: () => Promise<void> }) {
  const { roles } = useRoles()
  const [openAdd, setOpenAdd] = useState(false)
  const [editing, setEditing] = useState<UserDTO | null>(null)
  const [roleFilter, setRoleFilter] = useState('')

  const filtered = (users ?? []).filter((u) => !roleFilter || u.role === roleFilter)
  const roleLabel = (key: string) => roles?.find((r) => r.key === key)?.label ?? key

  async function toggleActive(u: UserDTO) {
    const r = await fetch(`/api/users/${u.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive: !u.isActive }),
    })
    const data = await r.json()
    if (!r.ok) { toast.error(data.error || 'خطا'); return }
    toast.success(u.isActive ? 'حساب غیرفعال شد' : 'حساب فعال شد')
    await reload()
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <select
          className="h-9 rounded-md border bg-background px-3 text-sm"
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          aria-label="فیلتر نقش"
        >
          <option value="">همه نقش‌ها</option>
          {(roles ?? []).map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}
        </select>
        <p className="text-xs text-muted-foreground">{faDigits(filtered.length)} کاربر</p>
        <div className="flex-1" />
        <Button size="sm" className="gap-1" onClick={() => setOpenAdd(true)}>
          <Plus className="size-4" /> کاربر جدید
        </Button>
      </div>

      {!users ? (
        <Skeleton className="h-48 w-full" />
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">کاربری نیست</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="max-h-[30rem] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">کاربر</TableHead>
                    <TableHead className="text-right">نقش</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">اقدامات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="text-right">
                        <p className="font-medium">{u.fullName}</p>
                        <p className="dir-ltr text-xs text-muted-foreground">{u.username}</p>
                      </TableCell>
                      <TableCell className="text-right"><Badge variant="outline">{roleLabel(u.role)}</Badge></TableCell>
                      <TableCell className="text-center">
                        {u.isActive
                          ? <Badge className="bg-emerald-600 hover:bg-emerald-600">فعال</Badge>
                          : <Badge variant="secondary">غیرفعال</Badge>}
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="outline" size="sm" onClick={() => setEditing(u)}>
                            <UserCog className="size-4" /> ویرایش
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8"
                            aria-label={u.isActive ? 'غیرفعال‌سازی' : 'فعال‌سازی'}
                            onClick={() => toggleActive(u)}
                            disabled={u.role === 'ADMIN'}
                          >
                            {u.isActive
                              ? <ShieldOff className="size-4 text-red-500" />
                              : <ShieldCheck className="size-4 text-emerald-600" />}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <AddUserDialog open={openAdd} onOpenChange={setOpenAdd} reload={reload} roles={roles} />
      <EditUserDialog user={editing} onClose={() => setEditing(null)} reload={reload} roles={roles} />
    </div>
  )
}

function AddUserDialog({
  open, onOpenChange, reload, roles,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  reload: () => Promise<void>
  roles: ReturnType<typeof useRoles>['roles']
}) {
  const [form, setForm] = useState({ username: '', fullName: '', role: 'EMPLOYEE', password: '' })
  const [saving, setSaving] = useState(false)

  async function submit() {
    setSaving(true)
    try {
      const r = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: form.username.trim(),
          fullName: form.fullName.trim(),
          role: form.role,
          password: form.password || undefined,
        }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success('کاربر ساخته شد' + (form.password ? '' : ' — رمز پیش‌فرض: 12345678'))
      onOpenChange(false)
      setForm({ username: '', fullName: '', role: 'EMPLOYEE', password: '' })
      await reload()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>کاربر جدید</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs">نام کاربری (لاتین) *</Label>
            <Input dir="ltr" className="text-left" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="finance2" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نام و نام خانوادگی *</Label>
            <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نقش *</Label>
            <RoleSelect roles={roles} value={form.role} onChange={(v) => setForm({ ...form, role: v })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">رمز عبور (خالی = 12345678)</Label>
            <Input dir="ltr" className="text-left" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving} className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} ساخت
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function EditUserDialog({
  user, onClose, reload, roles,
}: {
  user: UserDTO | null
  onClose: () => void
  reload: () => Promise<void>
  roles: ReturnType<typeof useRoles>['roles']
}) {
  const [fullName, setFullName] = useState('')
  const [role, setRole] = useState('EMPLOYEE')
  const [password, setPassword] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (user) {
      setFullName(user.fullName)
      setRole(user.role)
      setPassword('')
    }
  }, [user])

  async function submit() {
    if (!user) return
    setSaving(true)
    try {
      const payload: Record<string, unknown> = { fullName, role }
      if (password) payload.password = password
      const r = await fetch(`/api/users/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ذخیره ناموفق بود'); return }
      toast.success('تغییرات ذخیره شد' + (password ? ' — رمز عوض شد' : ''))
      onClose()
      await reload()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={!!user} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-lg">
        <DialogHeader><DialogTitle>ویرایش کاربر — {user?.username}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs">نام و نام خانوادگی</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نقش</Label>
            <RoleSelect roles={roles} value={role} onChange={setRole} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">بازنشانی رمز عبور (خالی = بدون تغییر)</Label>
            <div className="flex gap-2">
              <Input dir="ltr" className="text-left" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="رمز جدید" />
            </div>
            <p className="text-xs text-muted-foreground">
              <KeyRound className="mb-0.5 inline size-3" /> رمز جدید را وارد کنید و ذخیره بزنید
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving} className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <UserCog className="size-4" />} ذخیره
          </Button>
        </DialogFooter>
        {user && user.role !== 'ADMIN' && (
          <div className="border-t pt-3">
            <UserPanelsEditor userId={user.id} />
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

// ─── پروژه‌ها ───────────────────────────────────────────────────────

function ProjectsTab({ projects, reload }: { projects: ProjectDTO[] | null; reload: () => Promise<void> }) {
  const [name, setName] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  async function submit() {
    setSaving(true)
    try {
      const r = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, note: note || null }),
      })
      const data = await r.json()
      if (!r.ok) { toast.error(data.error || 'ثبت ناموفق بود'); return }
      toast.success('پروژه ساخته شد')
      setName(''); setNote('')
      await reload()
    } finally {
      setSaving(false)
    }
  }

  async function remove(p: ProjectDTO) {
    // حذف نرم: غیرفعال کردن (چون کارمندان ممکن است بهش وصل باشند)
    const r = await fetch(`/api/projects/${p.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive: false }),
    })
    if (r.ok) { toast.success('پروژه غیرفعال شد'); await reload() }
  }

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="space-y-3 p-4">
          <p className="text-sm font-bold">پروژه جدید</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label className="text-xs">نام پروژه *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">توضیح (اختیاری)</Label>
              <Input value={note} onChange={(e) => setNote(e.target.value)} />
            </div>
          </div>
          <Button onClick={submit} disabled={saving} size="sm" className="gap-1">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} ساخت پروژه
          </Button>
        </CardContent>
      </Card>

      {!projects ? (
        <Skeleton className="h-24 w-full" />
      ) : projects.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">پروژه‌ای نیست</CardContent></Card>
      ) : (
        projects.map((p) => (
          <Card key={p.id}>
            <CardContent className="flex items-center gap-3 p-4">
              <FolderKanban className="size-5 text-brand-600" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.note || '—'}</p>
              </div>
              <Badge variant="secondary">{faDigits(p.employeeCount ?? 0)} کارمند</Badge>
              {p.isActive
                ? <Button variant="outline" size="sm" onClick={() => remove(p)}><Trash2 className="size-4" /> بستن</Button>
                : <Badge variant="secondary">بسته شده</Badge>}
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )
}
