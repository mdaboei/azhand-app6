import { requirePanelPage } from '@/lib/guard'
import { PanelShell } from '@/components/panel-shell'

export default async function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const { session, user, roleLabel, panels } = await requirePanelPage('EMPLOYEE')
  return (
    <PanelShell fullName={user.fullName}
      roleLabel={roleLabel}
      role="EMPLOYEE"
      unitLabel="پنل شخصی" panels={panels}>
      {children}
    </PanelShell>
  )
}
