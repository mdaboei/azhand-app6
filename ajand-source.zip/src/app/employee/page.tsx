'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  CalendarClock, Coins, FileText, IdCard, Loader2, Printer, Star, Timer, Wallet,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { WorkLogDTO, ScoreEntryDTO } from '@/lib/types'
import {
  faDigits, faMoney, faNum, formatJalaliPeriodInput, jalaliMonthNow, periodLabel,
} from '@/lib/persian'

interface MyProfile {
  fullName: string
  nationalId: string | null
  phone: string | null
  position: string | null
  hireDate: string | null
  baseSalary: number | null
  projectName: string | null
}

/** آیتم داخل فیش (مزایا/کسورات) */
interface SlipItemDTO {
  title: string
  kind: 'BENEFIT' | 'DEDUCTION'
  amount: number
}

/** فیش حقوقی — ساختار آیتمی جدید */
interface SlipDTO {
  id: string
  userId: string
  userName: string
  period: string
  baseSalary: number
  items: SlipItemDTO[]
  netPay: number
  note: string | null
  issuedByName: string
  createdAt: string
}

export default function EmployeePage() {
  const [logs, setLogs] = useState<WorkLogDTO[] | null>(null)
  const [slips, setSlips] = useState<SlipDTO[] | null>(null)
  const [scores, setScores] = useState<ScoreEntryDTO[] | null>(null)
  const [profile, setProfile] = useState<MyProfile | null>(null)
  const [month, setMonth] = useState(jalaliMonthNow())
  const [openSlip, setOpenSlip] = useState<string | null>(null)

  useEffect(() => {
    ;(async () => {
      try {
        const [r1, r2, r3, r4] = await Promise.all([
          fetch('/api/worklogs'),
          fetch('/api/payslips'),
          fetch('/api/scores'),
          fetch('/api/auth/me'),
        ])
        if (r1.ok) setLogs(await r1.json())
        if (r2.ok) setSlips(await r2.json())
        if (r3.ok) setScores(await r3.json())
        if (r4.ok) {
          const data = await r4.json()
          setProfile(data.profile ?? null)
        }
        if (!r1.ok || !r2.ok || !r3.ok) toast.error('دریافت اطلاعات ناموفق بود')
      } catch {
        toast.error('ارتباط با سرور برقرار نشد')
        setLogs([]); setSlips([]); setScores([])
      }
    })()
  }, [])

  const monthLogs = useMemo(
    () => (logs ?? []).filter((l) => l.date.startsWith(month)),
    [logs, month]
  )
  const totalHours = monthLogs.reduce((s, l) => s + l.hours, 0)
  const totalOvertime = monthLogs.reduce((s, l) => s + l.overtime, 0)
  const latestSlip = slips && slips.length > 0 ? slips[0] : null
  const avgScore =
    scores && scores.length > 0
      ? Math.round(scores.reduce((s, x) => s + x.score, 0) / scores.length)
      : null

  return (
    <div className="space-y-5">
      {/* خلاصه این ماه */}
      <section className="grid grid-cols-3 gap-3" aria-label="خلاصه این ماه">
        <Card>
          <CardContent className="space-y-1 p-4 text-center">
            <CalendarClock className="mx-auto size-5 text-brand-600" />
            <p className="text-lg font-bold">{faNum(totalHours)}</p>
            <p className="text-xs text-muted-foreground">ساعت کارکرد</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-1 p-4 text-center">
            <Timer className="mx-auto size-5 text-amber-600" />
            <p className="text-lg font-bold">{faNum(totalOvertime)}</p>
            <p className="text-xs text-muted-foreground">ساعت اضافه‌کاری</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-1 p-4 text-center">
            <Wallet className="mx-auto size-5 text-emerald-600" />
            <p className="truncate text-sm font-bold">{latestSlip ? faMoney(latestSlip.netPay) : '—'}</p>
            <p className="text-xs text-muted-foreground">آخرین خالص دریافتی</p>
          </CardContent>
        </Card>
      </section>

      <Tabs defaultValue="worklog">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="worklog" className="gap-1"><CalendarClock className="size-4" /> کارکرد</TabsTrigger>
          <TabsTrigger value="payslip" className="gap-1"><FileText className="size-4" /> فیش</TabsTrigger>
          <TabsTrigger value="score" className="gap-1"><Star className="size-4" /> امتیاز</TabsTrigger>
          <TabsTrigger value="info" className="gap-1"><IdCard className="size-4" /> اطلاعات من</TabsTrigger>
        </TabsList>

        {/* ─── کارکرد ─── */}
        <TabsContent value="worklog" className="mt-4 space-y-3">
          <div className="flex items-center gap-2">
            <Input
              dir="ltr"
              className="w-32 text-left"
              value={month}
              onChange={(e) => setMonth(formatJalaliPeriodInput(e.target.value))}
              placeholder="1404/08"
              inputMode="numeric"
              aria-label="ماه به شمسی مثل 1404/08"
            />
            <p className="text-xs text-muted-foreground">
              نمایش {faDigits(monthLogs.length)} رکورد — فیلتر ماه (مثل 1404/08)
            </p>
          </div>

          <Card>
            <CardContent className="p-0">
              {!logs ? (
                <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
                  <Loader2 className="size-4 animate-spin" /> در حال بارگذاری…
                </div>
              ) : monthLogs.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted-foreground">
                  برای این ماه رکوردی ثبت نشده است
                </p>
              ) : (
                <div className="max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">تاریخ</TableHead>
                        <TableHead className="text-center">کارکرد (ساعت)</TableHead>
                        <TableHead className="text-center">اضافه‌کاری</TableHead>
                        <TableHead className="text-right">توضیح</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {monthLogs.map((l) => (
                        <TableRow key={l.id}>
                          <TableCell className="text-right font-medium">{faDigits(l.date)}</TableCell>
                          <TableCell className="text-center">{faNum(l.hours)}</TableCell>
                          <TableCell className="text-center">
                            {l.overtime > 0 ? (
                              <Badge variant="secondary">{faNum(l.overtime)}</Badge>
                            ) : (
                              '—'
                            )}
                          </TableCell>
                          <TableCell className="text-right text-xs text-muted-foreground">
                            {l.note || '—'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── فیش حقوقی ─── */}
        <TabsContent value="payslip" className="mt-4 space-y-3">
          {!slips ? (
            <Card>
              <CardContent className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
                <Loader2 className="size-4 animate-spin" /> در حال بارگذاری…
              </CardContent>
            </Card>
          ) : slips.length === 0 ? (
            <Card>
              <CardContent className="py-10 text-center text-sm text-muted-foreground">
                هنوز فیشی برای شما صادر نشده است
              </CardContent>
            </Card>
          ) : (
            slips.map((s) => (
              <Card key={s.id}>
                <CardContent className="p-4">
                  <button
                    type="button"
                    className="flex w-full items-center gap-3 text-right"
                    onClick={() => setOpenSlip(openSlip === s.id ? null : s.id)}
                  >
                    <Coins className="size-5 text-emerald-600" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold">{periodLabel(s.period)}</p>
                      <p className="text-xs text-muted-foreground">
                        خالص پرداختی: {faMoney(s.netPay)}
                      </p>
                    </div>
                    <Badge variant={openSlip === s.id ? 'default' : 'secondary'}>
                      {openSlip === s.id ? 'بستن' : 'جزئیات'}
                    </Badge>
                  </button>

                  {openSlip === s.id && (
                    <div className="mt-4 space-y-3 rounded-xl border bg-muted/30 p-4" id={`slip-${s.id}`}>
                      <p className="text-center text-sm font-bold">فیش حقوقی {periodLabel(s.period)}</p>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <Row label="حقوق پایه" value={faMoney(s.baseSalary)} />
                        {s.items.map((it, i) => (
                          <Row
                            key={`${it.title}-${i}`}
                            label={it.title}
                            value={faMoney(it.amount)}
                            valueClass={
                              it.kind === 'BENEFIT'
                                ? 'text-emerald-700 dark:text-emerald-400'
                                : 'text-red-600'
                            }
                          />
                        ))}
                      </div>
                      <div className="flex items-center justify-between rounded-lg bg-emerald-600/10 px-3 py-2 text-sm font-bold text-emerald-700 dark:text-emerald-400">
                        <span>خالص پرداختی</span>
                        <span>{faMoney(s.netPay)}</span>
                      </div>
                      {s.note && <p className="text-xs text-muted-foreground">یادداشت: {s.note}</p>}
                      <p className="text-xs text-muted-foreground">
                        صادرکننده: {s.issuedByName}
                      </p>
                      <Button asChild variant="outline" size="sm" className="gap-1">
                        <Link href={`/print/payslips?period=${encodeURIComponent(s.period)}`}>
                          <Printer className="size-4" /> چاپ / ذخیره PDF
                        </Link>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* ─── امتیاز من ─── */}
        <TabsContent value="score" className="mt-4 space-y-3">
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <Star className="size-6 text-amber-500" />
              <div className="flex-1">
                <p className="text-sm font-bold">
                  {avgScore != null ? `میانگین امتیاز شما: ${faNum(avgScore)} از ۱۰۰` : 'هنوز امتیازی ثبت نشده'}
                </p>
                <p className="text-xs text-muted-foreground">امتیازها را واحد منابع انسانی ثبت می‌کند</p>
              </div>
            </CardContent>
          </Card>

          {!scores ? (
            <Skeleton className="h-24 w-full" />
          ) : scores.length === 0 ? (
            <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">هنوز امتیازی برای شما ثبت نشده است</CardContent></Card>
          ) : (
            scores.map((s) => (
              <Card key={s.id}>
                <CardContent className="flex items-center gap-3 p-4">
                  <Star className="size-5 text-amber-500" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold">{periodLabel(s.period)}</p>
                    <p className="text-xs text-muted-foreground">{s.note || '—'}</p>
                  </div>
                  <Badge
                    className={
                      s.score >= 90
                        ? 'bg-emerald-600 hover:bg-emerald-600'
                        : s.score >= 70
                          ? 'bg-amber-600 hover:bg-amber-600'
                          : 'bg-brand-600 hover:bg-brand-600'
                    }
                  >
                    {faNum(s.score)}
                  </Badge>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* ─── اطلاعات من ─── */}
        <TabsContent value="info" className="mt-4 space-y-3">
          {!profile ? (
            <Card>
              <CardContent className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
                <Loader2 className="size-4 animate-spin" /> در حال بارگذاری…
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="space-y-2 p-4">
                <p className="mb-3 text-sm font-bold">اطلاعات ثبت‌شده من</p>
                <Row label="نام و نام خانوادگی" value={profile.fullName} />
                <Row label="سمت" value={profile.position || '—'} />
                <Row label="کد ملی" value={profile.nationalId ? faDigits(profile.nationalId) : '—'} />
                <Row label="تلفن" value={profile.phone ? faDigits(profile.phone) : '—'} />
                <Row label="تاریخ استخدام" value={profile.hireDate ? faDigits(profile.hireDate) : '—'} />
                <Row label="پروژه" value={profile.projectName || '—'} />
                <Row label="حقوق پایه" value={profile.baseSalary != null ? faMoney(profile.baseSalary) : '—'} />
                <p className="pt-2 text-xs text-muted-foreground">
                  اگر اطلاعاتی اشتباه است به واحد منابع انسانی اطلاع دهید.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

function Row({ label, value, valueClass }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg border bg-background px-3 py-2">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-medium ${valueClass ?? ''}`}>{value}</span>
    </div>
  )
}
