'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { AlertTriangle, BellRing, X } from 'lucide-react'
import { faNum } from '@/lib/persian'
import type { ExpiringPolicyDTO } from '@/lib/types'

const STORAGE_KEY = 'ajand-insurance-alert-dismiss'

/**
 * نوتیف بیمه‌نامه‌های نزدیک انقضا — بالای گوشی، زیر هدر برنامه:
 * هر بیمه‌نامه‌ای که ۲ روز یا کمتر تا پایانش مانده باشد (و هنوز منقضی نشده)
 * با نوار هشدار قرمز/زرد نمایش داده می‌شود؛ روزانه یک‌بار و قابل بستن.
 */
export function InsuranceNotifier() {
  const router = useRouter()
  const [items, setItems] = useState<ExpiringPolicyDTO[]>([])
  const [loaded, setLoaded] = useState(false)
  const [dismissedKey, setDismissedKey] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    const load = async () => {
      try {
        const res = await fetch('/api/insurance/expiring')
        if (!res.ok) return
        const data: ExpiringPolicyDTO[] = await res.json()
        if (alive) {
          setItems(data)
          setLoaded(true)
          try {
            setDismissedKey(localStorage.getItem(STORAGE_KEY))
          } catch {
            setDismissedKey(null)
          }
        }
      } catch {
        // بی‌صدا — نوتیف اختیاری است
      }
    }
    load()
    const timer = setInterval(load, 5 * 60 * 1000) // هر ۵ دقیقه دوباره چک می‌شود
    return () => {
      alive = false
      clearInterval(timer)
    }
  }, [])

  // کلید بستن: تاریخ امروز + شناسه بیمه‌نامه‌ها — فردا دوباره هشدار می‌آید
  const dismissKey = useMemo(
    () => `${new Date().toISOString().slice(0, 10)}|${items.map((i) => i.id).sort().join(',')}`,
    [items]
  )

  const dismissed = loaded && dismissedKey === dismissKey

  function dismiss() {
    setDismissedKey(dismissKey)
    try {
      localStorage.setItem(STORAGE_KEY, dismissKey)
    } catch {
      // نادیده — فقط تا رفرش بعدی پنهان می‌ماند
    }
  }

  if (!loaded || dismissed || items.length === 0) return null

  const first = items[0]
  const urgent = items.some((i) => i.daysLeft <= 1)
  const daysLabel = (d: number) =>
    d === 0 ? 'امروز آخرین روز' : d === 1 ? '۱ روز مانده' : `${faNum(d)} روز مانده`

  return (
    <div
      role="alert"
      aria-live="polite"
      className={`border-t ${
        urgent
          ? 'border-red-200 bg-red-50 text-red-800 dark:border-red-900 dark:bg-red-950/70 dark:text-red-200'
          : 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-900 dark:bg-amber-950/70 dark:text-amber-200'
      }`}
    >
      <div className="mx-auto flex w-full max-w-3xl items-start gap-2 px-3 py-2.5 sm:px-4">
        {urgent ? (
          <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
        ) : (
          <BellRing className="mt-0.5 size-4 shrink-0" aria-hidden />
        )}
        <button
          type="button"
          onClick={() => router.push('/machinery')}
          className="min-w-0 flex-1 text-right"
          aria-label="رفتن به پنل ماشین‌آلات و بیمه"
        >
          <p className="text-sm font-bold leading-5">
            {items.length === 1
              ? 'یک بیمه‌نامه به‌زودی منقضی می‌شود'
              : `${faNum(items.length)} بیمه‌نامه به‌زودی منقضی می‌شوند`}
          </p>
          <p className="mt-0.5 truncate text-xs leading-5">
            {first.typeName} — {first.machineName} ({daysLabel(first.daysLeft)})
            {items.length > 1 ? ` و ${faNum(items.length - 1)} مورد دیگر…` : ''}
          </p>
        </button>
        <button
          type="button"
          onClick={dismiss}
          aria-label="بستن هشدار بیمه"
          className="mt-0.5 shrink-0 rounded-full p-1 transition-colors hover:bg-black/10 dark:hover:bg-white/10"
        >
          <X className="size-4" aria-hidden />
        </button>
      </div>
    </div>
  )
}
