'use client'

import { useEffect } from 'react'

/**
 * تضمین «آپدیت بدون حذف و نصب دوباره»:
 * هر بار اپ باز می‌شود، سرویس‌ورکرها و کش‌های قدیمی پاک می‌شوند تا
 * همیشه آخرین نسخه مستقیم از سرور لود شود — نه نسخه کش‌شده.
 * نتیجه: با هر آپدیت سرور، کاربر بدون هیچ کاری (و بدون نصب دوباره)
 * نسخه جدید را می‌بیند. این هم برای PWA گوشی و هم مرورگر کار می‌کند.
 * (پوسته اندروید هم فقط یک وب‌ویو است و محتوا را زنده از سرور می‌گیرد.)
 */
export function PwaRegister() {
  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return

    const cleanup = async () => {
      try {
        const regs = await navigator.serviceWorker.getRegistrations()
        for (const reg of regs) {
          await reg.unregister()
        }
      } catch {
        /* ignore */
      }
      try {
        const keys = await caches.keys()
        await Promise.all(keys.map((k) => caches.delete(k)))
      } catch {
        /* ignore */
      }
    }

    if (document.readyState === 'complete') {
      void cleanup()
    } else {
      window.addEventListener('load', () => void cleanup())
    }
  }, [])

  return null
}
