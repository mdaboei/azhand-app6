'use client'

import { useRouter, usePathname } from 'next/navigation'
import { useState } from 'react'
import {
  ArrowRight,
  Banknote,
  Check,
  ClipboardList,
  Flower2,
  FolderKanban,
  Home,
  Leaf,
  LogOut,
  Menu,
  Moon,
  ShieldCheck,
  Sun,
  Tractor,
  UserRound,
  UsersRound,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { useTheme } from 'next-themes'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { InsuranceNotifier } from '@/components/insurance-notifier'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { ROLE_LABELS, PANEL_DESCRIPTIONS, PANEL_LABELS, PANEL_PATHS, type Panel, type Role } from '@/lib/types'
import { faDigits } from '@/lib/persian'

/** آیکون هر بخش برای منوی همبرگری */
const PANEL_ICONS: Record<Panel, LucideIcon> = {
  ADMIN: ShieldCheck,
  FINANCE: Banknote,
  HR: UsersRound,
  PR: ClipboardList,
  MACHINERY: Tractor,
  MANAGEMENT: FolderKanban,
  EMPLOYEE: UserRound,
  REPORTS: ClipboardList,
}

/** چهار تم برنامه — با دات رنگی در منو */
const THEME_OPTIONS = [
  { value: 'light', label: 'روشن (کرم)', icon: Sun, dot: '#efe6de', dotRing: true },
  { value: 'dark', label: 'تیره', icon: Moon, dot: '#211a16', dotRing: false },
  { value: 'emerald', label: 'زمردی', icon: Leaf, dot: '#147a4e', dotRing: false },
  { value: 'violet', label: 'یاسی', icon: Flower2, dot: '#6d3fae', dotRing: false },
] as const

interface PanelShellProps {
  fullName: string
  role: Role
  /** برچسب فارسی نقش — از سرور می‌آید (نقش سفارشی هم درست نمایش داده می‌شود) */
  roleLabel?: string | null
  /** برچسب واحد/بخش زیر نام کاربر */
  unitLabel?: string | null
  /** بخش‌های فعال این کاربر — در منوی همبرگری نمایش داده می‌شوند */
  panels: Panel[]
  children: React.ReactNode
}

/** پوسته مشترک همه پنل‌ها: منوی همبرگری بخش‌ها + بازگشت + تم + خروج */
export function PanelShell({ fullName, role, roleLabel, unitLabel, panels, children }: PanelShellProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()
  const [loading, setLoading] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  async function logout() {
    setLoading(true)
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      toast.success('خارج شدید')
      router.push('/login')
      router.refresh()
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="safe-top sticky top-0 z-10 border-b bg-background/90 backdrop-blur">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-1.5 px-3 py-3 sm:px-4">
          {/* منوی همبرگری بخش‌های فعال کاربر */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-9 shrink-0 rounded-full"
                aria-label="منوی بخش‌ها"
              >
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 p-0">
              <SheetHeader className="border-b p-4 text-right">
                <SheetTitle className="text-base">{fullName}</SheetTitle>
                <SheetDescription className="text-xs">
                  {roleLabel ?? ROLE_LABELS[role] ?? role}
                  {unitLabel ? ` — ${unitLabel}` : ''}
                </SheetDescription>
              </SheetHeader>
              <nav aria-label="ناوبری بخش‌ها" className="flex max-h-[calc(100dvh-8rem)] flex-col gap-1 overflow-y-auto p-3">
                <MenuItemRow
                  icon={Home}
                  label="صفحه اصلی (اطلاعیه‌ها)"
                  desc="فید اخبار شرکت"
                  active={false}
                  onClick={() => { setMenuOpen(false); router.push('/') }}
                />
                <p className="px-2 pb-1 pt-3 text-[11px] font-bold text-muted-foreground">
                  بخش‌های من ({faDigits(panels.length)})
                </p>
                {panels.length === 0 ? (
                  <p className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
                    هنوز بخشی برای شما فعال نشده است — از مدیریت دسترسی بخواهید.
                  </p>
                ) : (
                  panels.map((p) => {
                    const Icon = PANEL_ICONS[p]
                    const active = pathname === PANEL_PATHS[p]
                    return (
                      <MenuItemRow
                        key={p}
                        icon={Icon}
                        label={PANEL_LABELS[p]}
                        desc={PANEL_DESCRIPTIONS[p]}
                        active={active}
                        onClick={() => { setMenuOpen(false); router.push(PANEL_PATHS[p]) }}
                      />
                    )
                  })
                )}
                <div className="mt-3 border-t pt-3">
                  <p className="px-2 pb-1 text-[11px] font-bold text-muted-foreground">تم برنامه</p>
                  {THEME_OPTIONS.map((t) => (
                    <button
                      key={t.value}
                      onClick={() => setTheme(t.value)}
                      className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-accent"
                    >
                      <t.icon className="size-4 text-muted-foreground" aria-hidden />
                      <span
                        className="size-3.5 shrink-0 rounded-full border"
                        style={{
                          backgroundColor: t.dot,
                          borderColor: t.dotRing ? 'rgb(0 0 0 / 0.25)' : 'transparent',
                        }}
                        aria-hidden
                      />
                      <span className="flex-1 text-right">{t.label}</span>
                      {theme === t.value ? <Check className="size-4 text-primary" aria-hidden /> : null}
                    </button>
                  ))}
                </div>
                <div className="mt-3 border-t pt-3">
                  <button
                    onClick={logout}
                    disabled={loading}
                    className="flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-right text-destructive transition-colors hover:bg-destructive/10 disabled:opacity-50"
                  >
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-destructive/10">
                      <LogOut className="size-4" aria-hidden />
                    </span>
                    <span className="text-sm font-medium">خروج از حساب</span>
                  </button>
                </div>
              </nav>
            </SheetContent>
          </Sheet>

          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold leading-6">{fullName}</p>
            <p className="truncate text-xs text-muted-foreground">
              {roleLabel ?? ROLE_LABELS[role] ?? role}
              {unitLabel ? ` — ${unitLabel}` : ''}
            </p>
          </div>

          {/* بازگشت به صفحه قبل — لبه چپ هدر */}
          <Button
            variant="ghost"
            size="icon"
            className="size-9 shrink-0 rounded-full"
            aria-label="بازگشت به صفحه قبل"
            onClick={() => router.back()}
          >
            <ArrowRight className="size-5" />
          </Button>
        </div>

        {/* نوتیف بیمه‌نامه‌های نزدیک انقضا — فقط برای دارندگان بخش ماشین‌آلات */}
        {panels.includes('MACHINERY') && <InsuranceNotifier />}
      </header>

      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-5">{children}</main>

      <footer className="safe-bottom mt-auto border-t py-3 text-center text-xs text-muted-foreground">
        آژند اپ — شرکت آژند همت توس | نسخه {faDigits('3.11')}
      </footer>
    </div>
  )
}

/** ردیف آیتم منوی همبرگری */
function MenuItemRow({
  icon: Icon,
  label,
  desc,
  active,
  onClick,
}: {
  icon: LucideIcon
  label: string
  desc: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-right transition-colors hover:bg-accent ${
        active ? 'bg-accent' : ''
      }`}
      aria-current={active ? 'page' : undefined}
    >
      <span className={`flex size-9 shrink-0 items-center justify-center rounded-full ${active ? 'bg-brand-100 text-brand-700 dark:bg-brand-950 dark:text-brand-300' : 'bg-muted text-muted-foreground'}`}>
        <Icon className="size-4" aria-hidden />
      </span>
      <span className="min-w-0 flex-1">
        <span className={`block truncate text-sm font-medium ${active ? 'text-brand-700 dark:text-brand-300' : ''}`}>{label}</span>
        <span className="block truncate text-xs text-muted-foreground">{desc}</span>
      </span>
      {active ? <Check className="size-4 shrink-0 text-brand-600" aria-hidden /> : null}
    </button>
  )
}
