'use client'

import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

/**
 * دکمهٔ بازگشت در صفحهٔ چاپ — به صفحهٔ قبلی برمی‌گردد.
 *
 * اگر صفحهٔ چاپ در همان اپ باز شده باشد، مثل دکمهٔ بازگشت گوشی کار می‌کند؛
 * اگر تاریخچه‌ای نبود (مثلاً تب تازه)، به صفحهٔ اصلی پنل می‌رود.
 */
export function PrintBackButton({ className }: { className?: string }) {
  return (
    <Button
      variant="outline"
      onClick={() => {
        if (window.history.length > 1) {
          window.history.back()
        } else {
          window.location.href = '/'
        }
      }}
      className={`print:hidden gap-2 ${className ?? ''}`}
      aria-label="بازگشت به صفحه قبل"
    >
      <ArrowRight className="size-4" aria-hidden />
      بازگشت
    </Button>
  )
}
