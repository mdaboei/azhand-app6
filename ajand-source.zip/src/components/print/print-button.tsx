'use client'

import { Printer } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface PrintButtonProps {
  label?: string
  className?: string
}

/** دکمهٔ چاپ — در خود چاپ نمایش داده نمی‌شود */
export function PrintButton({ label = 'چاپ / ذخیره PDF', className }: PrintButtonProps) {
  return (
    <Button
      onClick={() => window.print()}
      className={`print:hidden bg-brand-600 text-white hover:bg-brand-700 ${className ?? ''}`}
      aria-label={label}
    >
      <Printer className="size-4" aria-hidden />
      {label}
    </Button>
  )
}
