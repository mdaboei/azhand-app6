import type { ReactNode } from 'react'
import { requireRolePage } from '@/lib/guard'
import type { Panel, Role } from '@/lib/types'
import { jalaliToday } from '@/lib/persian'
import { PrintButton } from './print-button'
import { PrintBackButton } from './print-back-button'

/**
 * پوستهٔ مشترک صفحات چاپ — خارج از پنل‌ها، مخصوص کاغذ A4.
 * نقش‌ها در خود صفحه‌ها تعیین و از اینجا اعمال می‌شود.
 */

interface PrintShellProps {
  title: string
  subtitle?: string
  children: ReactNode
  /** نقش‌های مجاز این صفحهٔ چاپی */
  roles: Role[]
  /** بخش‌های مجاز (سیستم دو لایه) — کاربر با دسترسی به این بخش‌ها هم وارد می‌شود */
  panels?: Panel[]
}

export async function PrintShell({ title, subtitle, children, roles, panels }: PrintShellProps) {
  await requireRolePage(roles, panels)
  const today = jalaliToday()

  return (
    <div className="safe-top safe-bottom min-h-screen bg-zinc-100 print:bg-white">
      <div className="mx-auto max-w-[820px] px-4 py-6 print:max-w-none print:p-0">
        {/* نوار ابزار — فقط روی صفحه، نه در چاپ */}
        <div className="print:hidden mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-white p-4 shadow-sm">
          <div>
            <p className="text-sm font-bold">پیش‌نمایش چاپ</p>
            <p className="text-xs text-muted-foreground">
              برای گرفتن PDF هم از همین دکمه استفاده کنید و مقصد را «Save as PDF» بگذارید.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <PrintBackButton />
            <PrintButton />
          </div>
        </div>

        {/* برگهٔ چاپ */}
        <div className="rounded-xl bg-white p-8 shadow-sm print:rounded-none print:p-0 print:shadow-none">
          {/* سربرگ شرکت */}
          <header className="mb-5 border-b-2 border-brand-600 pb-3">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="text-xl font-black tracking-tight">شرکت آژند همت توس</h1>
                <p className="mt-0.5 text-sm text-zinc-600">{title}</p>
              </div>
              <div className="text-left text-xs text-zinc-500">
                <p>تاریخ چاپ: {today}</p>
                {subtitle ? <p className="mt-0.5">{subtitle}</p> : null}
              </div>
            </div>
          </header>

          {children}

          <footer className="mt-8 flex items-end justify-between border-t pt-3 text-xs text-zinc-500 print:mt-10">
            <span>آژند اپ — سامانه داخلی کارکنان</span>
            <span>امضای مسئول: ....................................</span>
          </footer>
        </div>
      </div>
    </div>
  )
}
