'use client'

// ─── داشبورد حساب‌های سوددار اشخاص — تب پنل مالی ────────────────────
// کارت‌های آماری، جستجو/فیلتر/مرتب‌سازی، فهرست حساب‌ها،
// ثبت و ویرایش حساب و مرکز گزارش‌ها (اکسل + چاپ/PDF).

import { useCallback, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  ArrowRight,
  FileDown,
  Landmark,
  Loader2,
  Pencil,
  PiggyBank,
  Plus,
  Printer,
  Search,
  Trash2,
  Wallet,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import type {
  ProfitAccountDTO,
  ProfitCalcMethod,
  ProfitPartialRule,
} from '@/lib/types'
import {
  PROFIT_METHOD_HINTS,
  PROFIT_METHOD_LABELS,
  PROFIT_RULE_LABELS,
} from '@/lib/types'
import {
  faDigits,
  faMoney,
  faNum,
  formatJalaliDateInput,
  isValidJalaliDate,
  jalaliToday,
} from '@/lib/persian'

// ─── کمک‌ها ─────────────────────────────────────────────────────────

async function sendJSON(url: string, method: string, body?: unknown): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
    const data = (await res.json().catch(() => ({}))) as { error?: string }
    if (!res.ok) return { ok: false, error: data.error || 'عملیات ناموفق بود' }
    return { ok: true }
  } catch {
    return { ok: false, error: 'ارتباط با سرور برقرار نشد' }
  }
}

const Spinner = ({ text }: { text: string }) => (
  <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
    <Loader2 className="size-4 animate-spin" />
    {text}
  </div>
)

const EmptyState = ({ icon, text }: { icon: React.ReactNode; text: string }) => (
  <Card>
    <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
      {icon}
      <p className="text-sm text-muted-foreground">{text}</p>
    </CardContent>
  </Card>
)

/** پیش‌نمایش عددی زیر فیلد مبلغ */
function AmountHint({ value }: { value: string }) {
  const n = Number(value.replace(/[,\s]/g, ''))
  if (!value.trim() || !Number.isFinite(n) || n <= 0) return null
  return <p className="mt-1 text-xs text-muted-foreground">{faMoney(n)}</p>
}

// ─── گزارش‌ها ───────────────────────────────────────────────────────

const REPORT_TYPES = [
  { value: 'STATEMENT', label: 'گزارش حساب هر شخص', needAccount: true },
  { value: 'INTEREST_PAID', label: 'گزارش سود پرداخت‌شده در بازه زمانی', needRange: true },
  { value: 'INTEREST_UNPAID', label: 'گزارش سود پرداخت‌نشده (معوق)' },
  { value: 'PRINCIPAL_REMAINING', label: 'گزارش اصل سرمایه باقی‌مانده' },
  { value: 'MATURITY_UPCOMING', label: 'گزارش سررسیدهای پیش رو', needDays: true },
  { value: 'OVERALL', label: 'گزارش کلی بدهی شرکت به اشخاص' },
] as const

function ReportsDialog({ open, onOpenChange, accounts }: { open: boolean; onOpenChange: (v: boolean) => void; accounts: ProfitAccountDTO[] }) {
  const [type, setType] = useState<string>('OVERALL')
  const [accountId, setAccountId] = useState<string>('none')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [days, setDays] = useState('30')

  const def = REPORT_TYPES.find((r) => r.value === type)
  const params = new URLSearchParams({ type })
  if (def?.needAccount && accountId !== 'none') params.set('id', accountId)
  if (def?.needRange && from.trim()) params.set('from', from.trim())
  if (def?.needRange && to.trim()) params.set('to', to.trim())
  if (def?.needDays) params.set('days', days)
  const qs = params.toString()

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>گزارش‌های حساب‌های سوددار</DialogTitle>
          <DialogDescription>گزارش را انتخاب کنید و خروجی اکسل یا نسخهٔ چاپی (PDF) بگیرید.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>نوع گزارش</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger aria-label="نوع گزارش">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {REPORT_TYPES.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {def?.needAccount && (
            <div className="space-y-1">
              <Label>شخص</Label>
              <Select value={accountId} onValueChange={setAccountId}>
                <SelectTrigger aria-label="انتخاب شخص">
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— انتخاب کنید —</SelectItem>
                  {accounts.map((a) => (
                    <SelectItem key={a.id} value={a.id}>
                      {a.personName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          {def?.needRange && (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="rep-from">از تاریخ (شمسی)</Label>
                <Input
                  id="rep-from"
                  dir="ltr"
                  className="text-right"
                  value={from}
                  onChange={(e) => setFrom(formatJalaliDateInput(e.target.value))}
                  placeholder="1405/01/01"
                  inputMode="numeric"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="rep-to">تا تاریخ (شمسی)</Label>
                <Input
                  id="rep-to"
                  dir="ltr"
                  className="text-right"
                  value={to}
                  onChange={(e) => setTo(formatJalaliDateInput(e.target.value))}
                  placeholder="1405/12/29"
                  inputMode="numeric"
                />
              </div>
            </div>
          )}
          {def?.needDays && (
            <div className="space-y-1">
              <Label>بازه سررسید</Label>
              <Select value={days} onValueChange={setDays}>
                <SelectTrigger aria-label="بازه سررسید">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">۱۵ روز آینده</SelectItem>
                  <SelectItem value="30">۳۰ روز آینده</SelectItem>
                  <SelectItem value="60">۶۰ روز آینده</SelectItem>
                  <SelectItem value="90">۹۰ روز آینده</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            className="gap-1"
            asChild
            disabled={def?.needAccount && accountId === 'none'}
          >
            <a href={`/api/finance/profit-accounts/export?${qs}`}>
              <FileDown className="size-4" /> اکسل
            </a>
          </Button>
          <Button className="gap-1" asChild disabled={def?.needAccount && accountId === 'none'}>
            <Link href={`/print/profit/report?${qs}`}>
              <Printer className="size-4" /> نسخه چاپی (PDF)
            </Link>
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ─── فرم حساب (ثبت/ویرایش) ──────────────────────────────────────────

interface AccountFormState {
  personName: string
  principal: string
  startDate: string
  monthlyRate: string
  calcMethod: ProfitCalcMethod
  partialRule: ProfitPartialRule
  maturityDate: string
  contractNo: string
  note: string
}

const emptyForm: AccountFormState = {
  personName: '',
  principal: '',
  startDate: jalaliToday(),
  monthlyRate: '',
  calcMethod: 'SIMPLE_MONTHLY',
  partialRule: 'PRO_RATA',
  maturityDate: '',
  contractNo: '',
  note: '',
}

/** فرم ثبت/ویرایش حساب سوددار — هم در داشبورد و هم در صفحهٔ جزئیات استفاده می‌شود */
export function AccountDialog({
  open,
  onOpenChange,
  editing,
  onDone,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  editing: ProfitAccountDTO | null
  onDone: () => Promise<void> | void
}) {
  const [form, setForm] = useState<AccountFormState>(emptyForm)
  const [saving, setSaving] = useState(false)

  // بازنشانی فرم هنگام باز شدن دیالوگ — الگوی رسمی «تنظیم state هنگام رندر»
  const [wasOpen, setWasOpen] = useState(false)
  if (open !== wasOpen) {
    setWasOpen(open)
    if (open) {
      setForm(
        editing
          ? {
              personName: editing.personName,
              principal: String(editing.principal),
              startDate: editing.startDate,
              monthlyRate: String(editing.monthlyRate),
              calcMethod: editing.calcMethod,
              partialRule: editing.partialRule,
              maturityDate: editing.maturityDate ?? '',
              contractNo: editing.contractNo ?? '',
              note: editing.note ?? '',
            }
          : emptyForm,
      )
    }
  }

  const set = <K extends keyof AccountFormState>(k: K, v: AccountFormState[K]) =>
    setForm((f) => ({ ...f, [k]: v }))

  const principalNum = Number(form.principal.replace(/[,\s]/g, ''))
  const rateNum = Number(form.monthlyRate.replace(/[,\s]/g, ''))
  const monthlyInterest =
    Number.isFinite(principalNum) && principalNum > 0 && Number.isFinite(rateNum)
      ? Math.round(principalNum * rateNum) / 100
      : null

  async function submit() {
    if (form.personName.trim().length < 2) {
      toast.error('نام شخص را کامل وارد کنید')
      return
    }
    if (!isValidJalaliDate(form.startDate.trim())) {
      toast.error('تاریخ شروع باید شمسی و مثل 1405/08/15 باشد')
      return
    }
    if (form.maturityDate.trim() && !isValidJalaliDate(form.maturityDate.trim())) {
      toast.error('تاریخ سررسید باید شمسی و مثل 1405/08/15 باشد')
      return
    }
    if (!Number.isFinite(principalNum) || principalNum <= 0) {
      toast.error('مبلغ اولیه باید بیشتر از صفر باشد')
      return
    }
    if (!Number.isFinite(rateNum) || rateNum < 0 || rateNum > 100) {
      toast.error('درصد سود ماهانه بین ۰ تا ۱۰۰ باشد')
      return
    }
    setSaving(true)
    const result = await sendJSON(
      editing ? `/api/finance/profit-accounts/${editing.id}` : '/api/finance/profit-accounts',
      editing ? 'PATCH' : 'POST',
      {
        personName: form.personName.trim(),
        principal: principalNum,
        startDate: form.startDate.trim(),
        monthlyRate: rateNum,
        calcMethod: form.calcMethod,
        partialRule: form.partialRule,
        maturityDate: form.maturityDate.trim() || null,
        contractNo: form.contractNo.trim() || null,
        note: form.note.trim() || null,
      },
    )
    setSaving(false)
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success(editing ? 'مشخصات حساب ذخیره شد' : 'حساب سوددار ثبت شد')
    onOpenChange(false)
    await onDone()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{editing ? 'ویرایش حساب سوددار' : 'حساب سوددار جدید'}</DialogTitle>
          <DialogDescription>
            {editing
              ? 'تغییر اصل، تاریخ شروع، نرخ یا روش محاسبه، همهٔ دوره‌ها را از نو محاسبه می‌کند.'
              : 'با ثبت مبلغ اولیه، تاریخ شروع و درصد سود، محاسبهٔ سودها و بدهی به‌صورت خودکار انجام می‌شود.'}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="pa-name">نام شخص</Label>
            <Input
              id="pa-name"
              value={form.personName}
              onChange={(e) => set('personName', e.target.value)}
              placeholder="مثلاً: جهان منش"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="pa-principal">مبلغ اولیه سرمایه (تومان)</Label>
              <Input
                id="pa-principal"
                dir="ltr"
                className="text-right"
                value={form.principal}
                onChange={(e) => set('principal', e.target.value)}
                placeholder="100000000"
                inputMode="decimal"
              />
              <AmountHint value={form.principal} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="pa-rate">درصد سود ماهانه</Label>
              <Input
                id="pa-rate"
                dir="ltr"
                className="text-right"
                value={form.monthlyRate}
                onChange={(e) => set('monthlyRate', e.target.value)}
                placeholder="3"
                inputMode="decimal"
              />
              {monthlyInterest !== null && (
                <p className="mt-1 text-xs text-muted-foreground">
                  سود ماهانهٔ تقریبی: {faMoney(monthlyInterest)}
                </p>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="pa-start">تاریخ شروع حساب (شمسی)</Label>
              <Input
                id="pa-start"
                dir="ltr"
                className="text-right"
                value={form.startDate}
                onChange={(e) => set('startDate', formatJalaliDateInput(e.target.value))}
                placeholder="1405/08/15"
                inputMode="numeric"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="pa-maturity">تاریخ سررسید (اختیاری)</Label>
              <Input
                id="pa-maturity"
                dir="ltr"
                className="text-right"
                value={form.maturityDate}
                onChange={(e) => set('maturityDate', formatJalaliDateInput(e.target.value))}
                placeholder="1406/08/15"
                inputMode="numeric"
              />
            </div>
          </div>
          <div className="space-y-1">
            <Label>نوع محاسبه سود</Label>
            <Select value={form.calcMethod} onValueChange={(v) => set('calcMethod', v as ProfitCalcMethod)}>
              <SelectTrigger aria-label="نوع محاسبه سود">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(PROFIT_METHOD_LABELS) as ProfitCalcMethod[]).map((m) => (
                  <SelectItem key={m} value={m}>
                    {PROFIT_METHOD_LABELS[m]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="rounded-lg bg-muted/50 p-2 text-xs leading-6 text-muted-foreground">
              {PROFIT_METHOD_HINTS[form.calcMethod]}
            </p>
          </div>
          <div className="space-y-1">
            <Label>قاعدهٔ ماه ناقص</Label>
            <Select value={form.partialRule} onValueChange={(v) => set('partialRule', v as ProfitPartialRule)}>
              <SelectTrigger aria-label="قاعده ماه ناقص">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(PROFIT_RULE_LABELS) as ProfitPartialRule[]).map((r) => (
                  <SelectItem key={r} value={r}>
                    {PROFIT_RULE_LABELS[r]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label htmlFor="pa-contract">شماره قرارداد / سند</Label>
            <Input
              id="pa-contract"
              value={form.contractNo}
              onChange={(e) => set('contractNo', e.target.value)}
              placeholder="اختیاری — مثل: قرارداد ۱۴۰۵/۰۸۷"
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="pa-note">توضیحات</Label>
            <Textarea
              id="pa-note"
              rows={2}
              value={form.note}
              onChange={(e) => set('note', e.target.value)}
              placeholder="اختیاری"
            />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={saving} className="gap-1">
            {saving && <Loader2 className="size-4 animate-spin" />}
            {editing ? 'ذخیره تغییرات' : 'ثبت حساب'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ─── کارت آماری ─────────────────────────────────────────────────────

function StatCard({
  label,
  value,
  hint,
  tone = 'default',
  active = false,
  onClick,
}: {
  label: string
  value: string
  hint?: string
  tone?: 'default' | 'brand' | 'positive' | 'warning' | 'negative'
  active?: boolean
  onClick?: () => void
}) {
  const tones: Record<string, string> = {
    default: 'text-foreground',
    brand: 'text-brand-600',
    positive: 'text-emerald-600 dark:text-emerald-400',
    warning: 'text-amber-600 dark:text-amber-400',
    negative: 'text-red-600 dark:text-red-400',
  }
  const Comp = onClick ? 'button' : 'div'
  return (
    <Comp
      {...(onClick ? { type: 'button' as const, onClick } : {})}
      className={`rounded-xl border bg-card p-3 text-right shadow-sm transition-all sm:p-4 ${
        onClick ? 'hover:border-brand-400' : ''
      } ${active ? 'border-brand-500 ring-1 ring-brand-500' : ''}`}
      aria-label={onClick ? `${label}: ${value}` : undefined}
    >
      <p className="truncate text-xs text-muted-foreground">{label}</p>
      <p className={`mt-1 truncate text-sm font-black sm:text-base ${tones[tone]}`}>{value}</p>
      {hint && <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{hint}</p>}
    </Comp>
  )
}

// ─── داشبورد اصلی ───────────────────────────────────────────────────

export function ProfitDashboard() {
  const [accounts, setAccounts] = useState<ProfitAccountDTO[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [methodFilter, setMethodFilter] = useState<'all' | ProfitCalcMethod>('all')
  const [statusFilter, setStatusFilter] = useState<'all' | 'ACTIVE' | 'CLOSED'>('all')
  const [nearMaturityOnly, setNearMaturityOnly] = useState(false)
  const [sort, setSort] = useState<'newest' | 'maturity' | 'debt' | 'name'>('newest')

  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<ProfitAccountDTO | null>(null)
  const [reportsOpen, setReportsOpen] = useState(false)

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/finance/profit-accounts')
      setAccounts(res.ok ? ((await res.json()) as ProfitAccountDTO[]) : [])
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  // ── جمع کل‌ها ──
  const totals = useMemo(() => {
    const t = {
      count: accounts.length,
      activeCount: 0,
      principal: 0,
      currentPrincipal: 0,
      accrued: 0,
      paidInterest: 0,
      unpaidInterest: 0,
      totalDebt: 0,
      nearMaturity: 0,
    }
    for (const a of accounts) {
      if (a.status === 'ACTIVE') t.activeCount += 1
      t.principal += a.principal
      t.currentPrincipal += a.stats.currentPrincipal
      t.accrued += a.stats.accrued
      t.paidInterest += a.stats.paidInterest
      t.unpaidInterest += a.stats.unpaidInterest
      t.totalDebt += a.stats.totalDebt
      if (a.status === 'ACTIVE' && a.maturityDate && (a.stats.daysToMaturity ?? 9999) <= 30) {
        t.nearMaturity += 1
      }
    }
    return t
  }, [accounts])

  // ── فیلتر و مرتب‌سازی ──
  const visible = useMemo(() => {
    let list = [...accounts]
    const q = search.trim()
    if (q) list = list.filter((a) => a.personName.includes(q) || (a.contractNo ?? '').includes(q))
    if (methodFilter !== 'all') list = list.filter((a) => a.calcMethod === methodFilter)
    if (statusFilter !== 'all') list = list.filter((a) => a.status === statusFilter)
    if (nearMaturityOnly) {
      list = list.filter(
        (a) => a.status === 'ACTIVE' && a.maturityDate && (a.stats.daysToMaturity ?? 9999) <= 30,
      )
    }
    if (sort === 'maturity') {
      list.sort((a, b) => (a.stats.daysToMaturity ?? 99999) - (b.stats.daysToMaturity ?? 99999))
    } else if (sort === 'debt') {
      list.sort((a, b) => b.stats.totalDebt - a.stats.totalDebt)
    } else if (sort === 'name') {
      list.sort((a, b) => a.personName.localeCompare(b.personName, 'fa'))
    }
    return list
  }, [accounts, search, methodFilter, statusFilter, nearMaturityOnly, sort])

  async function deleteAccount(a: ProfitAccountDTO) {
    const result = await sendJSON(`/api/finance/profit-accounts/${a.id}`, 'DELETE')
    if (!result.ok) {
      toast.error(result.error)
      return
    }
    toast.success(`حساب «${a.personName}» حذف شد`)
    await load()
  }

  return (
    <div className="space-y-4">
      {/* ── کارت‌های آماری ── */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3 lg:grid-cols-4">
        <StatCard label="تعداد کل حساب‌ها" value={`${faNum(totals.count)} حساب`} hint={`فعال: ${faNum(totals.activeCount)} — بسته: ${faNum(totals.count - totals.activeCount)}`} />
        <StatCard label="مجموع اصل سرمایه دریافتی" value={faMoney(totals.principal)} tone="brand" />
        <StatCard label="مجموع اصل سرمایه باقی‌مانده" value={faMoney(totals.currentPrincipal)} />
        <StatCard label="مجموع سود محاسبه‌شده" value={faMoney(totals.accrued)} tone="positive" />
        <StatCard label="مجموع سود پرداخت‌شده" value={faMoney(totals.paidInterest)} tone="positive" />
        <StatCard label="مجموع سود معوق" value={faMoney(totals.unpaidInterest)} tone="warning" />
        <StatCard label="مجموع بدهی فعلی شرکت" value={faMoney(totals.totalDebt)} tone="negative" />
        <StatCard
          label="حساب‌های نزدیک به سررسید"
          value={`${faNum(totals.nearMaturity)} حساب`}
          hint="سررسید در ۳۰ روز آینده یا گذشته"
          tone="warning"
          active={nearMaturityOnly}
          onClick={() => setNearMaturityOnly((v) => !v)}
        />
      </div>

      {/* ── نوار ابزار ── */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-40 flex-1">
          <Search className="pointer-events-none absolute right-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="جستجو بر اساس نام شخص یا شماره قرارداد…"
            className="pr-8"
            aria-label="جستجوی حساب"
          />
        </div>
        <Select value={methodFilter} onValueChange={(v) => setMethodFilter(v as 'all' | ProfitCalcMethod)}>
          <SelectTrigger className="w-40" aria-label="فیلتر نوع محاسبه">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همهٔ روش‌ها</SelectItem>
            {(Object.keys(PROFIT_METHOD_LABELS) as ProfitCalcMethod[]).map((m) => (
              <SelectItem key={m} value={m}>
                {PROFIT_METHOD_LABELS[m]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as 'all' | 'ACTIVE' | 'CLOSED')}>
          <SelectTrigger className="w-32" aria-label="فیلتر وضعیت">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همهٔ وضعیت‌ها</SelectItem>
            <SelectItem value="ACTIVE">فعال</SelectItem>
            <SelectItem value="CLOSED">بسته</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={(v) => setSort(v as typeof sort)}>
          <SelectTrigger className="w-44" aria-label="مرتب‌سازی">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">جدیدترین</SelectItem>
            <SelectItem value="maturity">نزدیک‌ترین سررسید</SelectItem>
            <SelectItem value="debt">بیشترین بدهی</SelectItem>
            <SelectItem value="name">نام شخص</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" className="gap-1" onClick={() => setReportsOpen(true)}>
          <FileDown className="size-4" /> گزارش‌ها
        </Button>
        <Button
          size="sm"
          className="gap-1"
          onClick={() => {
            setEditing(null)
            setFormOpen(true)
          }}
        >
          <Plus className="size-4" /> حساب جدید
        </Button>
      </div>

      {/* ── فهرست حساب‌ها ── */}
      {loading ? (
        <Spinner text="در حال بارگذاری حساب‌ها…" />
      ) : visible.length === 0 ? (
        <EmptyState
          icon={<PiggyBank className="size-10 text-muted-foreground/40" />}
          text={
            accounts.length === 0
              ? 'هنوز حساب سودداری ثبت نشده است — با دکمه «حساب جدید» اولین حساب را اضافه کنید'
              : 'حسابی با این فیلترها پیدا نشد'
          }
        />
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {visible.map((a) => (
            <Card key={a.id} className="transition-colors hover:border-brand-300">
              <CardContent className="space-y-3 p-4">
                <div className="flex items-start justify-between gap-2">
                  <Link href={`/finance/profit/${a.id}`} className="group flex min-w-0 flex-1 items-start gap-2" aria-label={`جزئیات حساب ${a.personName}`}>
                    <Wallet className="mt-0.5 size-5 shrink-0 text-brand-600" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-bold leading-6 group-hover:text-brand-700">{a.personName}</p>
                      <p className="text-xs text-muted-foreground">
                        {PROFIT_METHOD_LABELS[a.calcMethod]}
                        {a.contractNo ? ` — سند ${a.contractNo}` : ''}
                      </p>
                    </div>
                  </Link>
                  <div className="flex shrink-0 items-center gap-1">
                    {a.status === 'ACTIVE' ? (
                      a.stats.maturityReached ? (
                        <Badge variant="destructive">رسیده به سررسید</Badge>
                      ) : a.maturityDate && (a.stats.daysToMaturity ?? 999) <= 30 ? (
                        <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                          {faNum(a.stats.daysToMaturity ?? 0)} روز تا سررسید
                        </Badge>
                      ) : (
                        <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">فعال</Badge>
                      )
                    ) : (
                      <Badge variant="secondary">بسته {a.closedAt ? `— ${faDigits(a.closedAt)}` : ''}</Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8"
                      aria-label={`ویرایش ${a.personName}`}
                      onClick={() => {
                        setEditing(a)
                        setFormOpen(true)
                      }}
                    >
                      <Pencil className="size-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8 text-destructive"
                          aria-label={`حذف ${a.personName}`}
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>حذف حساب «{a.personName}»؟</AlertDialogTitle>
                          <AlertDialogDescription>
                            همهٔ دوره‌های محاسبه‌شده، پرداخت‌ها و تاریخچهٔ این حساب حذف می‌شود و قابل بازگشت نیست.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>انصراف</AlertDialogCancel>
                          <AlertDialogAction className="bg-destructive text-white hover:bg-destructive/90" onClick={() => deleteAccount(a)}>
                            حذف کامل
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>

                <Link href={`/finance/profit/${a.id}`} className="block" aria-label={`مشاهده جزئیات ${a.personName}`}>
                  <div className="rounded-lg border bg-muted/30 p-3">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-xs text-muted-foreground">بدهی فعلی شرکت به این شخص</span>
                      <span className="text-sm font-black text-red-600 dark:text-red-400">{faMoney(a.stats.totalDebt)}</span>
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                      <span className="text-muted-foreground">اصل اولیه:</span>
                      <span className="font-bold">{faMoney(a.principal)}</span>
                      <span className="text-muted-foreground">اصل سرمایه فعلی:</span>
                      <span className="font-bold">{faMoney(a.stats.currentPrincipal)}</span>
                      <span className="text-muted-foreground">سود ماهانه:</span>
                      <span className="font-bold">{faNum(a.monthlyRate)}٪</span>
                      <span className="text-muted-foreground">سود معوق:</span>
                      <span className="font-bold text-amber-600 dark:text-amber-400">{faMoney(a.stats.unpaidInterest)}</span>
                      <span className="text-muted-foreground">تاریخ شروع:</span>
                      <span dir="ltr" className="text-right">{faDigits(a.startDate)}</span>
                      <span className="text-muted-foreground">سررسید:</span>
                      <span dir="ltr" className="text-right">{a.maturityDate ? faDigits(a.maturityDate) : '—'}</span>
                      <span className="text-muted-foreground">ماه‌های سپری‌شده:</span>
                      <span className="font-bold">{faNum(a.stats.monthsElapsed)} ماه</span>
                    </div>
                  </div>
                </Link>

                <div className="flex items-center justify-between">
                  <Link
                    href={`/finance/profit/${a.id}`}
                    className="flex items-center gap-1 text-xs font-bold text-brand-600 hover:underline"
                  >
                    <ArrowRight className="size-3.5" />
                    جزئیات، تاریخچه ماهانه و پرداخت‌ها
                  </Link>
                  <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                    <Landmark className="size-3" />
                    {PROFIT_RULE_LABELS[a.partialRule]}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ── دیالوگ‌ها ── */}
      <AccountDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        onDone={load}
      />
      <ReportsDialog open={reportsOpen} onOpenChange={setReportsOpen} accounts={accounts} />
    </div>
  )
}
