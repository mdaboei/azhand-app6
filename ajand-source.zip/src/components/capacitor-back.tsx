'use client'

import { useEffect } from 'react'

/**
 * دکمهٔ بازگشت سخت‌افزاری اندروید داخل اپ «آژند اپ».
 *
 * رفتار پیش‌فرض Capacitor بدون listener: خروج کامل از برنامه — که تجربهٔ
 * بدی است (کاربر در صفحهٔ چاپ می‌زد و کل اپ می‌رفت بیرون!). این کامپوننت
 * با پلاگین App کاپاسیتور (بخش core اندروید — نیاز به پکیج اضافه ندارد)
 * دکمهٔ back را هندل می‌کند:
 *   - اگر تاریخچه دارد → مثل مرورگر یک قدم عقب (پنل ← چاپ ← پنل ...)
 *   - اگر نبود (اولین صفحه) → خروج استاندارد اندروید
 *
 * پل Capacitor فقط داخل WebView اپ تزریق می‌شود؛ در مرورگر/PWA بی‌اثر است.
 */

interface CapacitorBridge {
  isNativePlatform?: () => boolean
  getPlugin?: (name: string) => unknown
  Plugins?: Record<string, unknown>
}

interface BackButtonEvent {
  canGoBack: boolean
}

interface AppPluginLike {
  addListener?: (
    eventName: 'backButton',
    handler: (event: BackButtonEvent) => void,
  ) => Promise<{ remove: () => void }> | { remove: () => void }
  exitApp?: () => void
}

declare global {
  interface Window {
    Capacitor?: CapacitorBridge
  }
}

export function CapacitorBack() {
  useEffect(() => {
    if (typeof window === 'undefined') return

    // جلوگیری از ثبت تکراری (مثلاً با ناوبری سخت بین صفحه‌ها)
    const w = window as Window & { __ajandBackRegistered?: boolean }
    if (w.__ajandBackRegistered) return

    const cap = window.Capacitor
    if (!cap?.isNativePlatform?.()) return

    const raw = (cap.getPlugin?.('App') ?? cap.Plugins?.App) as AppPluginLike | undefined
    if (!raw?.addListener) return

    let cancelled = false
    let handle: { remove: () => void } | null = null

    try {
      const result = raw.addListener('backButton', (event) => {
        if (event?.canGoBack) {
          window.history.back()
        } else {
          // اولین صفحهٔ اپ — خروج استاندارد (رفتار طبیعی اندروید)
          raw.exitApp?.()
        }
      })
      // addListener در پل بومی هم ممکن است handle sync بدهد هم Promise
      Promise.resolve(result)
        .then((h) => {
          if (cancelled) h?.remove?.()
          else handle = h ?? null
        })
        .catch(() => {
          /* پل در دسترس نبود — مثل مرورگر عادی عمل می‌شود */
        })
      w.__ajandBackRegistered = true
    } catch {
      /* ignore */
    }

    return () => {
      cancelled = true
      handle?.remove?.()
      w.__ajandBackRegistered = false
    }
  }, [])

  return null
}
