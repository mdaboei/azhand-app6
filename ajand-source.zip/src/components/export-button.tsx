'use client'

import { useState } from 'react'
import { FileDown, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'

interface ExportButtonProps {
  /** آدرس API خروجی اکسل، مثل /api/machines/export */
  url: string
  /** نام فایل هنگام دانلود، مثل machines.xlsx */
  filename: string
  label?: string
  className?: string
}

/** دکمهٔ مشترک «خروجی اکسل» — فایل را از سرور می‌گیرد و دانلود می‌کند */
export function ExportButton({ url, filename, label = 'خروجی اکسل', className }: ExportButtonProps) {
  const [busy, setBusy] = useState(false)

  async function run() {
    setBusy(true)
    try {
      const res = await fetch(url)
      if (!res.ok) {
        let msg = 'خروجی اکسل ناموفق بود'
        try {
          const d = await res.json()
          if (d?.error) msg = d.error
        } catch {
          /* پاسخ json نبود */
        }
        toast.error(msg)
        return
      }
      const blob = await res.blob()
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(objectUrl)
    } catch {
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={run}
      disabled={busy}
      className={className}
      aria-label={label}
    >
      {busy ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <FileDown className="size-4" aria-hidden />}
      {label}
    </Button>
  )
}
