'use client'

import { useCallback, useEffect, useState } from 'react'
import type { RoleInfoDTO } from '@/lib/types'

/** فهرست نقش‌ها (پایه + سفارشی) از سرور — برای سلکت‌های نقش در فرم‌ها */
export function useRoles() {
  const [roles, setRoles] = useState<RoleInfoDTO[] | null>(null)

  const reload = useCallback(async () => {
    const r = await fetch('/api/roles')
    if (r.ok) {
      const j = await r.json()
      setRoles(j.roles as RoleInfoDTO[])
    }
  }, [])

  useEffect(() => { (async () => { await reload() })() }, [reload])

  return { roles, reload }
}
