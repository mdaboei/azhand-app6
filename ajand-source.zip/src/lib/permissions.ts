import { db } from '@/lib/db'
import type { Panel, Role } from '@/lib/types'
import { PANELS, PANEL_PATHS } from '@/lib/types'

/**
 * سیستم دسترسی دو لایه:
 *  ۱) پیش‌فرض نقش — ماتریس Permission (نقش × پنل) که ادمین از تب «دسترسی‌ها» می‌سازد.
 *  ۲) تخصیص ریزدانه هر کاربر — جدول UserPanel که مقدم بر پیش‌فرض نقش است.
 *     اگر برای کاربر ردیفی در UserPanel باشد، دقیقاً همان پنل‌ها برایش فعال است؛
 *     اگر هیچ ردیفی نداشته باشد، پیش‌فرض نقشش اعمال می‌شود.
 *  نقش ADMIN همیشه به همهٔ بخش‌ها دسترسی دارد (قابل حذف نیست).
 */

export type { Panel }

/** پنل‌های معتبر — ردیف‌های قدیمی (مثل پنل حذف‌شدهٔ بیمه) بی‌اثر می‌مانند */
export const VALID_PANELS = PANELS

function isValidPanel(p: string): p is Panel {
  return (PANELS as readonly string[]).includes(p)
}

/** پیش‌فرض امن — نگاشت قدیمی نقش→پنل (پنل INSURANCE داخل MACHINERY ادغام شد) */
export const DEFAULT_PANEL_MAP: Record<Role, Panel[]> = {
  ADMIN: [...PANELS],
  FINANCE: ['FINANCE'],
  HR: ['HR'],
  PR: ['PR'],
  INSURANCE: ['MACHINERY'],
  MACHINERY: ['MACHINERY'],
  MANAGEMENT: ['MANAGEMENT', 'REPORTS'],
  EMPLOYEE: ['EMPLOYEE'],
}

type Cache = { at: number; map: Partial<Record<Role, Panel[]>> }
const g = globalThis as unknown as { __ajandPermCache?: Cache; __ajandUserPanelCache?: Map<string, { at: number; panels: Panel[] | null }> }
const TTL_MS = 15_000

function invalidate() {
  g.__ajandPermCache = undefined
  g.__ajandUserPanelCache = undefined
}

// ─── لایه ۱: پیش‌فرض نقش‌ها ─────────────────────────────────────────

/** نقشهٔ کامل نقش→پنل‌ها از دیتابیس (با کش) — کلیدهای بدون ردیف = پیش‌فرض */
export async function getPanelMap(): Promise<Record<Role, Panel[]>> {
  const now = Date.now()
  if (g.__ajandPermCache && now - g.__ajandPermCache.at < TTL_MS) {
    return withDefaults(g.__ajandPermCache.map)
  }
  const rows = await db.permission.findMany()
  const map: Partial<Record<Role, Panel[]>> = {}
  for (const row of rows) {
    if (!isValidPanel(row.panel)) continue
    ;(map[row.role as Role] ??= []).push(row.panel as Panel)
  }
  g.__ajandPermCache = { at: now, map }
  return withDefaults(map)
}

/** پنل‌های پیش‌فرض یک نقش — نقش‌های سفارشی فقط از ماتریس دیتابیس */
export async function getRolePanels(role: Role | string): Promise<Panel[]> {
  if (role === 'ADMIN') return [...PANELS]
  const map = await getPanelMap()
  return map[role as Role] ?? DEFAULT_PANEL_MAP[role as Role] ?? []
}

/** ذخیرهٔ پنل‌های یک نقش (جایگزینی کامل) — ADMIN همیشه کامل می‌ماند */
export async function setRolePanels(role: Role | string, panels: Panel[]): Promise<void> {
  const clean = role === 'ADMIN'
    ? [...PANELS]
    : PANELS.filter((p) => panels.includes(p))
  await db.$transaction([
    db.permission.deleteMany({ where: { role } }),
    db.permission.createMany({
      data: clean.map((panel) => ({ role, panel })),
    }),
  ])
  g.__ajandPermCache = undefined
}

function withDefaults(map: Partial<Record<Role, Panel[]>>): Record<Role, Panel[]> {
  const out = {} as Record<Role, Panel[]>
  for (const role of Object.keys(DEFAULT_PANEL_MAP) as Role[]) {
    out[role] = role === 'ADMIN' ? [...PANELS] : (map[role] ?? DEFAULT_PANEL_MAP[role])
  }
  // نقش‌های سفارشی — پنل‌هایشان فقط از ماتریس دیتابیس می‌آید
  for (const [role, panels] of Object.entries(map)) {
    if (!(role in out) && Array.isArray(panels)) out[role as Role] = panels
  }
  return out
}

// ─── لایه ۲: تخصیص ریزدانه هر کاربر ─────────────────────────────────

function orderPanels(panels: Panel[]): Panel[] {
  return PANELS.filter((p) => panels.includes(p))
}

/**
 * بخش‌های فعال یک کاربر (با کش ۱۵ ثانیه‌ای):
 *  - ادمین → همهٔ بخش‌ها
 *  - اگر UserPanel داشته باشد → همان (ترتیب‌شده)
 *  - وگرنه → پیش‌فرض نقش
 */
export async function getUserPanelList(userId: string, role: Role | string): Promise<Panel[]> {
  if (role === 'ADMIN') return [...PANELS]
  const now = Date.now()
  const cached = g.__ajandUserPanelCache?.get(userId)
  if (cached && now - cached.at < TTL_MS) {
    return cached.panels ?? (await getRolePanels(role))
  }
  const rows = await db.userPanel.findMany({ where: { userId } })
  const explicit = rows.map((r) => r.panel as Panel).filter((p) => isValidPanel(p))
  const panels = explicit.length > 0 ? orderPanels(explicit) : null
  if (!g.__ajandUserPanelCache) g.__ajandUserPanelCache = new Map()
  g.__ajandUserPanelCache.set(userId, { at: now, panels })
  return panels ?? (await getRolePanels(role))
}

/** آیا این کاربر حق ورود به این بخش را دارد؟ */
export async function hasUserPanelAccess(userId: string, role: Role | string, panel: Panel): Promise<boolean> {
  if (role === 'ADMIN') return true
  const panels = await getUserPanelList(userId, role)
  return panels.includes(panel)
}

/** آیا کاربر تخصیص اختصاصی (UserPanel) دارد؟ */
export async function hasExplicitPanels(userId: string): Promise<boolean> {
  const count = await db.userPanel.count({ where: { userId } })
  return count > 0
}

/**
 * ذخیرهٔ پنل‌های یک کاربر (جایگزینی کامل) — آرایهٔ خالی یعنی همه را ببند؛
 * reset=true یعنی حذف تخصیص اختصاصی و بازگشت به پیش‌فرض نقش.
 */
export async function setUserPanels(userId: string, panels: Panel[], reset = false): Promise<void> {
  const clean = orderPanels(panels.filter((p) => isValidPanel(p)))
  await db.$transaction([
    db.userPanel.deleteMany({ where: { userId } }),
    ...(reset || clean.length === 0
      ? []
      : [db.userPanel.createMany({ data: clean.map((panel) => ({ userId, panel })) })]),
  ])
  g.__ajandUserPanelCache?.delete(userId)
}

export { PANEL_PATHS }
