// ─── موتور محاسبهٔ حساب‌های سوددار اشخاص ────────────────────────────
// سه روش محاسبه:
//  ۱) SIMPLE_MONTHLY — سود ماهانه با اصل ثابت: سود هر دوره از اصل ابتدای همان
//     دوره محاسبه می‌شود؛ سود پرداخت‌نشده «معوق» می‌ماند و به اصل اضافه نمی‌شود.
//  ۲) MATURITY_LUMP  — سود ساده تجمیعی در سررسید: سودها تجمیع و در سررسید
//     تسویه می‌شود؛ پرداخت زودتر از سررسید هم مجاز است.
//  ۳) COMPOUND       — سود مرکب ماهانه: در پایان هر دوره، سود به اصل اضافه
//     می‌شود و سود دورهٔ بعد از اصل جدید محاسبه می‌شود.
//
// تضمین‌های مهم:
//  - دوره‌ها بر مبنای «سالروز شروع حساب» ساخته می‌شوند (نه ماه تقویمی) تا
//    شروع وسط ماه، دورهٔ کوتاه/جبران‌ناپذیر نسازد.
//  - هر دوره فقط با کلید یگانه (حساب، شمارهٔ دوره) یک بار در دیتابیس ثبت
//    می‌شود؛ ورودهای مکرر به برنامه هیچ سودی دوبار اضافه نمی‌کنند.
//  - بازسازی کامل دوره‌ها فقط پس از تغییر داده (پرداخت/مشخصات) انجام می‌شود.
//  - همهٔ محاسبات با گردکردن تا ۲ رقم اعشار (سانتی‌تومان) انجام می‌شود.
//
// قواعد ماه ناقص (partialRule):
//  - IGNORE    : ماه ناقص هیچ سودی ندارد.
//  - FULL_MONTH: ماه شروع‌شده کامل محسوب می‌شود (بلافاصله قطعی می‌شود).
//  - PRO_RATA  : روزشمار — سود به نسبت روزهای سپری‌شده از آن دوره.
//
// اثر بازپرداخت اصل: پرداخت اصل طی یک دوره از «اصل دورهٔ بعد» کم می‌شود؛
// بنابراین ویرایش پرداخت‌ها هرگز اعداد دوره‌های قطعی‌شدهٔ قبل از خود را
// تغییر نمی‌دهد مگر با بازسازی صریح (که خودش در تاریخچه ثبت می‌شود).

import { db } from '@/lib/db'
import { padJalali } from '@/lib/persian'

// ─── تبدیل تقویم شمسی ↔ میلادی (الگوریتم استاندارد jalaali) ─────────

function div(a: number, b: number): number {
  return Math.trunc(a / b)
}
function mod(a: number, b: number): number {
  return a - Math.trunc(a / b) * b
}

const BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
  2192, 2262, 2324, 2394, 2456, 3178,
]

function jalCal(jy: number): { leap: number; gy: number; march: number } {
  const bl = BREAKS.length
  const gy = jy + 621
  let leapJ = -14
  let jp = BREAKS[0]
  let jump = 0
  for (let i = 1; i < bl; i += 1) {
    const jm = BREAKS[i]
    jump = jm - jp
    if (jy < jm) break
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4)
    jp = jm
  }
  let n = jy - jp
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4)
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150
  const march = 20 + leapJ - leapG
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33
  let leap = mod(mod(n + 1, 33) - 1, 4)
  if (leap === -1) leap = 4
  return { leap, gy, march }
}

/** عدد روز مطلق میلادی از سال/ماه/روز میلادی */
function g2d(gy: number, gm: number, gd: number): number {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752
  return d
}

/** سال/ماه/روز میلادی از عدد روز مطلق */
function d2g(jdn: number): { gy: number; gm: number; gd: number } {
  let j = 4 * jdn + 139361631
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
  const i = div(mod(j, 1461), 4) * 5 + 308
  const gd = div(mod(i, 153), 5) + 1
  const gm = mod(div(i, 153), 12) + 1
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6)
  return { gy, gm, gd }
}

/** عدد روز مطلق از تاریخ شمسی */
function j2d(jy: number, jm: number, jd: number): number {
  const r = jalCal(jy)
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1
}

/** تاریخ شمسی از عدد روز مطلق */
function d2j(jdn: number): { jy: number; jm: number; jd: number } {
  const gy = d2g(jdn).gy
  let jy = gy - 621
  const r = jalCal(jy)
  const jdn1f = g2d(gy, 3, r.march)
  let k = jdn - jdn1f
  if (k >= 0) {
    if (k <= 185) {
      return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 }
    }
    k -= 186
  } else {
    jy -= 1
    k += 179
    if (r.leap === 1) k += 1
  }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 }
}

export function jalaaliMonthLength(jy: number, jm: number): number {
  if (jm <= 6) return 31
  if (jm <= 11) return 30
  return jalCal(jy).leap === 1 ? 30 : 29
}

export function parseJalali(s: string): { jy: number; jm: number; jd: number } {
  const [y, m, d] = padJalali(s).split('/').map(Number)
  return { jy: y, jm: m, jd: d }
}

export function isValidJalali(s: string): boolean {
  if (!/^\d{4}\/\d{2}\/\d{2}$/.test(padJalali(s))) return false
  const { jy, jm, jd } = parseJalali(s)
  if (jy < 1300 || jy > 1500) return false
  if (jm < 1 || jm > 12) return false
  return jd >= 1 && jd <= jalaaliMonthLength(jy, jm)
}

/** عدد روز مطلق یک تاریخ شمسی — مبنای مقایسه و اختلاف روزها */
function dayNo(s: string): number {
  const { jy, jm, jd } = parseJalali(s)
  return j2d(jy, jm, jd)
}

/** مقایسهٔ دو تاریخ شمسی: -1 / 0 / 1 */
export function cmpJalali(a: string, b: string): number {
  const x = padJalali(a)
  const y = padJalali(b)
  return x < y ? -1 : x > y ? 1 : 0
}

/** اختلاف روز بین دو تاریخ شمسی (b − a) */
export function diffJalaliDays(a: string, b: string): number {
  return dayNo(b) - dayNo(a)
}

/** تاریخ شمسی امروز بر اساس منطقهٔ زمانی تهران */
export function todayJalali(): string {
  const fmt = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', {
    timeZone: 'Asia/Tehran',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  })
  const parts = fmt.formatToParts(new Date())
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '01'
  return `${get('year')}/${get('month')}/${get('day')}`
}

/** سالروز شمسی: k ماه بعد از تاریخ داده‌شده (روز اضافه به طول ماه جدید محدود می‌شود) */
export function addJalaliMonths(s: string, k: number): string {
  const { jy, jm, jd } = parseJalali(s)
  const total = jy * 12 + (jm - 1) + k
  const ny = div(total, 12)
  const nm = mod(total, 12) + 1
  const nd = Math.min(jd, jalaaliMonthLength(ny, nm))
  const p2 = (n: number) => String(n).padStart(2, '0')
  return `${ny}/${p2(nm)}/${p2(nd)}`
}

/** یک روز قبل از تاریخ شمسی */
function prevJalaliDay(s: string): string {
  const j = d2j(dayNo(s) - 1)
  const p2 = (n: number) => String(n).padStart(2, '0')
  return `${j.jy}/${p2(j.jm)}/${p2(j.jd)}`
}

// ─── انواع دادهٔ موتور ──────────────────────────────────────────────

export type CalcMethod = 'SIMPLE_MONTHLY' | 'MATURITY_LUMP' | 'COMPOUND'
export type PartialRule = 'IGNORE' | 'FULL_MONTH' | 'PRO_RATA'
export type PayType = 'INTEREST' | 'PRINCIPAL' | 'MIXED'

export interface AccountCore {
  principal: number
  startDate: string
  monthlyRate: number
  calcMethod: CalcMethod
  partialRule: PartialRule
  maturityDate: string | null
  status: 'ACTIVE' | 'CLOSED'
  closedAt: string | null
}

export interface PaymentCore {
  date: string
  interestPart: number
  principalPart: number
}

export interface PeriodRow {
  idx: number
  startDate: string
  endDate: string
  /** کل روزهای این دوره (سالروز تا سالروز) */
  fullDays: number
  /** روزهای احتساب‌شده برای سود */
  days: number
  opening: number
  interest: number
  capitalized: number
  principalPaid: number
  closing: number
  /** آیا این دوره قطعی‌شده و قابل ثبت در دفتر است؟ */
  finalized: boolean
}

export interface OngoingRow {
  idx: number
  startDate: string
  endDate: string
  daysElapsed: number
  daysTotal: number
  accruedSoFar: number
  note: string
}

export interface ProfitStats {
  monthsElapsed: number
  accrued: number
  capitalized: number
  paidInterest: number
  paidPrincipal: number
  currentPrincipal: number
  unpaidInterest: number
  totalDebt: number
  maturityReached: boolean
  daysToMaturity: number | null
  ongoing: OngoingRow | null
}

// ─── گرد کردن مالی (۲ رقم اعشار) ────────────────────────────────────

export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100
}

// ─── افق محاسبه و ساخت دوره‌ها ──────────────────────────────────────

/**
 * افق محاسبه: از امروز، سررسید و تاریخ بستن، زودترینِ مؤثر برمی‌گردد.
 * null یعنی حساب هنوز شروع نشده (تاریخ شروع در آینده است).
 */
function horizonOf(acc: AccountCore, today: string): { horizon: string; hardStop: boolean } | null {
  if (cmpJalali(acc.startDate, today) > 0) return null
  // نامزدهای افق: امروز (نرم) + سررسید و تاریخ بستن در گذشته/امروز (سخت)
  const candidates: { d: string; hard: boolean }[] = [{ d: today, hard: false }]
  if (acc.maturityDate && cmpJalali(acc.maturityDate, today) <= 0) {
    candidates.push({ d: acc.maturityDate, hard: true })
  }
  if (acc.status === 'CLOSED' && acc.closedAt && cmpJalali(acc.closedAt, today) <= 0) {
    candidates.push({ d: acc.closedAt, hard: true })
  }
  candidates.sort((a, b) =>
    cmpJalali(a.d, b.d) || (a.hard === b.hard ? 0 : a.hard ? -1 : 1),
  )
  return { horizon: candidates[0].d, hardStop: candidates[0].hard }
}

/**
 * محاسبهٔ خالص همهٔ دوره‌ها (نهایی + در جریان) از روی مشخصات حساب و پرداخت‌ها.
 * این تابع هیچ اثری در دیتابیس ندارد — فقط ریاضیاتِ قطعی.
 */
export function computePeriods(
  acc: AccountCore,
  payments: PaymentCore[],
  today: string,
): PeriodRow[] {
  const hz = horizonOf(acc, today)
  if (!hz) return []
  const { horizon, hardStop } = hz
  const rows: PeriodRow[] = []
  const inRange = (p: PaymentCore, from: string, to: string) =>
    cmpJalali(p.date, from) >= 0 && cmpJalali(p.date, to) <= 0
  const withinHorizon = (p: PaymentCore) => cmpJalali(p.date, horizon) <= 0

  let opening = acc.principal
  let idx = 0
  // سقف ایمنی حلقه (۶۰۰ دوره = ۵۰ سال)
  while (idx < 600) {
    idx += 1
    const ps = addJalaliMonths(acc.startDate, idx - 1)
    const peNext = addJalaliMonths(acc.startDate, idx)
    const pe = prevJalaliDay(peNext)
    // دوره باید قبل از افق شروع شده باشد؛ اگر افق دقیقاً اول همین دوره است
    // (مثلاً سررسید بر سالروز افتاده)، هیچ روزی از این دوره سپری نشده — پایان
    if (cmpJalali(ps, horizon) >= 0) break

    const complete = cmpJalali(peNext, horizon) <= 0
    const fullDays = diffJalaliDays(ps, peNext)
    let days = fullDays
    let factor = 1
    let finalized = true

    if (!complete) {
      if (hardStop) {
        // برش نهایی با سررسید/بستن — طبق قاعدهٔ انتخابی قطعی می‌شود
        if (acc.partialRule === 'IGNORE') break
        const daysElapsed = diffJalaliDays(ps, horizon) + 1
        if (acc.partialRule === 'PRO_RATA') {
          days = daysElapsed
          factor = daysElapsed / fullDays
        }
        // FULL_MONTH: همان سود کامل
      } else {
        // افق = امروز — دورهٔ جاری فقط با قاعدهٔ «ماه کامل» قطعی می‌شود
        if (acc.partialRule !== 'FULL_MONTH') {
          finalized = false
          const daysElapsed = Math.max(1, diffJalaliDays(ps, today) + 1)
          days = daysElapsed
          // نمایش برآوردی دورهٔ جاری: روزشمار / صفر برای «ماه ناقص محسوب نمی‌شود»
          factor = acc.partialRule === 'PRO_RATA' ? daysElapsed / fullDays : 0
        }
      }
    }

    const principalPaid = round2(
      payments
        .filter((p) => withinHorizon(p) && inRange(p, ps, pe))
        .reduce((s, p) => s + p.principalPart, 0),
    )

    const interest =
      opening > 0 ? round2((opening * acc.monthlyRate * factor) / 100) : 0
    const capitalized = acc.calcMethod === 'COMPOUND' ? interest : 0
    const closing = round2(
      acc.calcMethod === 'COMPOUND'
        ? opening + capitalized - principalPaid
        : opening - principalPaid,
    )

    rows.push({
      idx,
      startDate: ps,
      endDate: pe,
      fullDays,
      days,
      opening: round2(opening),
      interest,
      capitalized,
      principalPaid,
      closing,
      finalized,
    })

    opening = closing
    if (!complete) break // دورهٔ جاری/بریده‌شده = آخرین دوره
  }
  return rows
}

// ─── خلاصهٔ آماری حساب ──────────────────────────────────────────────

export function computeStats(
  acc: AccountCore,
  rows: PeriodRow[],
  payments: PaymentCore[],
  today: string,
): ProfitStats {
  const finalized = rows.filter((r) => r.finalized)
  const accrued = round2(finalized.reduce((s, r) => s + r.interest, 0))
  const capitalized = round2(finalized.reduce((s, r) => s + r.capitalized, 0))
  const paidInterest = round2(payments.reduce((s, p) => s + p.interestPart, 0))
  const paidPrincipal = round2(payments.reduce((s, p) => s + p.principalPart, 0))
  const currentPrincipal = Math.max(
    0,
    round2(acc.principal + capitalized - paidPrincipal),
  )
  const unpaidInterest = Math.max(
    0,
    round2(accrued - capitalized - paidInterest),
  )
  // بدهی کل = اصل اولیه − بازپرداخت اصل + کل سود ایجادشده − سود پرداخت‌شده
  const totalDebt = Math.max(
    0,
    round2(acc.principal - paidPrincipal + accrued - paidInterest),
  )
  const ongoingRow = rows.find((r) => !r.finalized)
  const ongoing: OngoingRow | null = ongoingRow
    ? {
        idx: ongoingRow.idx,
        startDate: ongoingRow.startDate,
        endDate: ongoingRow.endDate,
        daysElapsed: Math.max(0, diffJalaliDays(ongoingRow.startDate, today) + 1),
        daysTotal: ongoingRow.fullDays,
        accruedSoFar: ongoingRow.interest,
        note:
          acc.partialRule === 'IGNORE'
            ? 'ماه ناقص محسوب نمی‌شود'
            : acc.partialRule === 'FULL_MONTH'
              ? 'ماه شروع‌شده کامل محسوب می‌شود'
              : 'روزشمار — به نسبت روزهای سپری‌شده',
      }
    : null
  const maturityReached =
    acc.status === 'ACTIVE' &&
    !!acc.maturityDate &&
    cmpJalali(acc.maturityDate, today) <= 0
  const daysToMaturity = acc.maturityDate
    ? diffJalaliDays(today, acc.maturityDate)
    : null
  return {
    monthsElapsed: finalized.length,
    accrued,
    capitalized,
    paidInterest,
    paidPrincipal,
    currentPrincipal,
    unpaidInterest,
    totalDebt,
    maturityReached,
    daysToMaturity,
    ongoing,
  }
}

// ─── لایهٔ دیتابیس ──────────────────────────────────────────────────

function toCore(acc: {
  principal: number
  startDate: string
  monthlyRate: number
  calcMethod: string
  partialRule: string
  maturityDate: string | null
  status: string
  closedAt: string | null
}): AccountCore {
  return {
    principal: acc.principal,
    startDate: acc.startDate,
    monthlyRate: acc.monthlyRate,
    calcMethod: acc.calcMethod as CalcMethod,
    partialRule: acc.partialRule as PartialRule,
    maturityDate: acc.maturityDate,
    status: acc.status as 'ACTIVE' | 'CLOSED',
    closedAt: acc.closedAt,
  }
}

/**
 * همگام‌سازی بدون تخریب: دوره‌های قطعیِ تازه را می‌سازد و دوره‌های
 * بی‌اعتبار (مثلاً پس از بازگشایی یا تمدید سررسید) را حذف می‌کند.
 * اعداد دوره‌های موجود هرگز از این مسیر تغییر نمی‌کنند — تضمین قطعیت.
 */
export async function syncProfitAccount(accountId: string): Promise<void> {
  const acc = await db.profitAccount.findUnique({ where: { id: accountId } })
  if (!acc) return
  const payments = await db.profitPayment.findMany({
    where: { accountId },
    select: { date: true, interestPart: true, principalPart: true },
  })
  const rows = computePeriods(toCore(acc), payments, todayJalali())
  const finalized = rows.filter((r) => r.finalized)
  const existing = await db.profitPeriod.findMany({
    where: { accountId },
    select: { idx: true },
  })
  const existingSet = new Set(existing.map((e) => e.idx))
  const finalSet = new Set(finalized.map((r) => r.idx))
  const stale = [...existingSet].filter((i) => !finalSet.has(i))
  const missing = finalized.filter((r) => !existingSet.has(r.idx))
  if (missing.length === 0 && stale.length === 0) return
  await db.$transaction([
    ...missing.map((r) =>
      db.profitPeriod.create({
        data: {
          accountId,
          idx: r.idx,
          startDate: r.startDate,
          endDate: r.endDate,
          days: r.days,
          opening: r.opening,
          interest: r.interest,
          capitalized: r.capitalized,
          principalPaid: r.principalPaid,
          closing: r.closing,
        },
      }),
    ),
    ...stale.map((idx) =>
      db.profitPeriod.deleteMany({ where: { accountId, idx } }),
    ),
  ])
}

/**
 * بازسازی کامل دوره‌های قطعی از صفر — فقط پس از تغییر دادهٔ اثرگذار
 * (ویرایش مشخصات، ثبت/ویرایش/حذف پرداخت، بستن یا بازگشایی حساب).
 */
export async function rebuildProfitPeriods(accountId: string): Promise<void> {
  const acc = await db.profitAccount.findUnique({ where: { id: accountId } })
  if (!acc) return
  const payments = await db.profitPayment.findMany({
    where: { accountId },
    select: { date: true, interestPart: true, principalPart: true },
  })
  const rows = computePeriods(toCore(acc), payments, todayJalali())
  const finalized = rows.filter((r) => r.finalized)
  await db.$transaction([
    db.profitPeriod.deleteMany({ where: { accountId } }),
    db.profitPeriod.createMany({
      data: finalized.map((r) => ({
        accountId,
        idx: r.idx,
        startDate: r.startDate,
        endDate: r.endDate,
        days: r.days,
        opening: r.opening,
        interest: r.interest,
        capitalized: r.capitalized,
        principalPaid: r.principalPaid,
        closing: r.closing,
      })),
    }),
  ])
}

/** همگام‌سازی همهٔ حساب‌ها — برای داشبورد و گزارش‌ها */
export async function syncAllProfitAccounts(): Promise<void> {
  const ids = await db.profitAccount.findMany({ select: { id: true } })
  for (const { id } of ids) {
    await syncProfitAccount(id)
  }
}

/** مانده‌های لحظه‌ای حساب برای اعتبارسنجی پرداخت */
export function balancesOf(acc: AccountCore, payments: PaymentCore[], today: string) {
  const rows = computePeriods(acc, payments, today)
  const stats = computeStats(acc, rows, payments, today)
  return stats
}
