import { randomBytes } from 'node:crypto'
import { db } from '@/lib/db'
import { ALL_ROLES, ROLE_LABELS } from '@/lib/types'
import type { Role } from '@/lib/types'

/**
 * نقش‌های داینامیک — نقش‌های پایه (سیستمی) در RoleDef نگهداری می‌شوند و
 * ادمین می‌تواند نقش سفارشی «اضافه / تغییرنام / حذف» کند.
 *  - key: شناسه ثابت (در User.role و Permission.role ذخیره می‌شود) — هرگز عوض نمی‌شود
 *  - label: نام فارسی نمایشی — قابل ویرایش
 *  - isSystem: نقش‌های پایه حذف نمی‌شوند
 * کش ۱۵ ثانیه‌ای — هم‌الگوی کش ماتریس دسترسی‌ها.
 */

export interface RoleInfo {
  id: string
  key: string
  label: string
  isSystem: boolean
}

type RolesCache = { at: number; list: RoleInfo[] }
const g = globalThis as unknown as { __ajandRolesCache?: RolesCache }
const TTL_MS = 15_000

export function invalidateRoleCache() {
  g.__ajandRolesCache = undefined
}

/** فهرست همهٔ نقش‌ها (پایه + سفارشی) به ترتیب نمایش — با بازگشت امن به پایه‌ها */
export async function getRoleDefs(): Promise<RoleInfo[]> {
  const now = Date.now()
  if (g.__ajandRolesCache && now - g.__ajandRolesCache.at < TTL_MS) {
    return g.__ajandRolesCache.list
  }
  const rows = await db.roleDef.findMany({ orderBy: [{ order: 'asc' }, { createdAt: 'asc' }] })
  const list: RoleInfo[] = rows.map((r) => ({ id: r.id, key: r.key, label: r.label, isSystem: r.isSystem }))
  // اگر بک‌فیل هنوز اجرا نشده باشد، حداقل نقش‌های پایه را از کد برمی‌گردانیم
  const finalList = list.length > 0 ? list : BUILTIN_ROLE_INFO
  g.__ajandRolesCache = { at: now, list: finalList }
  return finalList
}

/** نقشهٔ برچسب فارسی همهٔ نقش‌ها — برای نمایش در سرور و DTOها */
export async function getRoleLabelMap(): Promise<Record<string, string>> {
  const defs = await getRoleDefs()
  const map: Record<string, string> = { ...ROLE_LABELS }
  for (const d of defs) map[d.key] = d.label
  return map
}

/** آیا این کلید یک نقش معتبر (پایه یا سفارشی) است؟ */
export async function isValidRole(key: string): Promise<boolean> {
  if (!key) return false
  const defs = await getRoleDefs()
  return defs.some((d) => d.key === key)
}

/** ساخت کلید یکتا برای نقش سفارشی — R-XXXXXX (حروف بی‌ابهام) */
function generateRoleKey(): string {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'
  const bytes = randomBytes(6)
  let s = ''
  for (const b of bytes) s += alphabet[b % alphabet.length]
  return `R-${s}`
}

/** افزودن نقش سفارشی — فقط با نام فارسی؛ کلید خودکار ساخته می‌شود */
export async function addCustomRole(label: string): Promise<RoleInfo> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const key = generateRoleKey()
    try {
      const row = await db.roleDef.create({
        data: { key, label, isSystem: false, order: 1000 },
      })
      invalidateRoleCache()
      return { id: row.id, key: row.key, label: row.label, isSystem: row.isSystem }
    } catch (e) {
      // تداخل کلید یکتا → کلید تازه بساز؛ خطای دیگر → پاس
      if (typeof e === 'object' && e !== null && 'code' in e && (e as { code?: string }).code === 'P2002') {
        if (await db.roleDef.findUnique({ where: { key } })) continue
        // تداخل روی label نیست چون unique فقط روی key است — خطای دیگر است
        throw e
      }
      throw e
    }
  }
  throw new Error('ساخت کلید یکتا برای نقش ممکن نشد — دوباره تلاش کنید')
}

/** پیدا کردن RoleDef با id یا key — سازگار با هر دو حالت */
async function resolveRole(idOrKey: string) {
  return (await db.roleDef.findUnique({ where: { id: idOrKey } }))
    ?? (await db.roleDef.findUnique({ where: { key: idOrKey } }))
}

/** تغییر نام نمایشی نقش (پایه یا سفارشی) — key ثابت می‌ماند */
export async function renameRole(idOrKey: string, label: string): Promise<void> {
  const row = await resolveRole(idOrKey)
  if (!row) throw new Error('نقش پیدا نشد')
  await db.roleDef.update({ where: { id: row.id }, data: { label } })
  invalidateRoleCache()
}

/**
 * حذف نقش سفارشی:
 *  - نقش‌های سیستمی حذف نمی‌شوند
 *  - اگر کاربری با این نقش وجود دارد، خطا با تعداد کاربران برمی‌گردد
 *  - ردیف‌های ماتریس دسترسی نقش هم پاک می‌شود
 */
export async function deleteRole(idOrKey: string): Promise<{ ok: true } | { ok: false; error: string }> {
  const row = await resolveRole(idOrKey)
  if (!row) return { ok: false, error: 'نقش پیدا نشد' }
  if (row.isSystem) return { ok: false, error: 'نقش‌های پایه قابل حذف نیستند' }
  const userCount = await db.user.count({ where: { role: row.key } })
  if (userCount > 0) {
    return { ok: false, error: `اول نقش ${userCount} کاربر این بخش را تغییر دهید` }
  }
  await db.$transaction([
    db.permission.deleteMany({ where: { role: row.key } }),
    db.roleDef.delete({ where: { id: row.id } }),
  ])
  invalidateRoleCache()
  return { ok: true }
}

// ─── نقش‌های پایه — هم‌سان با ALL_ROLES/ROLE_LABELS در types ─────────

export const BUILTIN_ROLE_INFO: RoleInfo[] = ALL_ROLES.map((key: Role) => ({
  id: key, // تا زمانی که بک‌فیل اجرا نشده، key جای id استفاده می‌شود
  key,
  label: ROLE_LABELS[key],
  isSystem: true,
}))
