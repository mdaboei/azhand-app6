import * as XLSX from 'xlsx'
import { NextResponse } from 'next/server'

/**
 * ابزار مشترک خروجی اکسل — سرور
 * یک آرایه از ردیف‌ها (کلید = عنوان ستون فارسی) را به فایل xlsx تبدیل می‌کند.
 */

export type ExcelRow = Record<string, string | number | null | undefined>

/** ساخت و برگرداندن پاسخ دانلود اکسل */
export function excelResponse(rows: ExcelRow[], filename: string, sheetName = 'Sheet1') {
  // اگر ردیفی نبود، یک ستون هشدار بگذار تا فایل خالی و گیج‌کننده نباشد
  const data: ExcelRow[] = rows.length > 0 ? rows : [{ 'موردی برای خروجی پیدا نشد': '' }]

  const ws = XLSX.utils.json_to_sheet(data)

  // عرض ستون‌ها بر اساس طول محتوا (حداقل ۱۰، حداکثر ۴۰)
  const headers = Object.keys(data[0] ?? {})
  ws['!cols'] = headers.map((h) => {
    const maxLen = Math.max(
      h.length,
      ...data.slice(0, 200).map((r) => String(r[h] ?? '').length),
    )
    return { wch: Math.min(40, Math.max(10, maxLen + 2)) }
  })

  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, sheetName)

  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer

  const asciiName = filename.replace(/[^\w.-]+/g, '_') || 'export.xlsx'
  return new NextResponse(new Uint8Array(buf), {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
      'Cache-Control': 'no-store',
    },
  })
}

/** تبدیل ارقام فارسی/عربی به انگلیسی — برای خواندن اکسل آپلودی */
export function toEnDigits(s: string): string {
  return s
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
}

/** تشخیص نوع آیتم ناشناخته از روی عنوان — اگر «کسور» بود کسورات، وگرنه مزایا */
export function guessKind(title: string): 'BENEFIT' | 'DEDUCTION' {
  return /کسور|کسر|مالیات|سهم بیمه|بیمه سهم|عواید|جریمه/.test(title) ? 'DEDUCTION' : 'BENEFIT'
}
