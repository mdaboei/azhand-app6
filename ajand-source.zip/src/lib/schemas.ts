import { z } from 'zod'
import { isValidJalaliDate } from '@/lib/persian'

// ─── اسکیمای اعتبارسنجی ورودی‌های API (zod) ─────────────────────────

const JALALI_DATE = /^\d{4}\/\d{1,2}\/\d{1,2}$/
const JALALI_PERIOD = /^\d{4}\/\d{1,2}$/

/** نقش — کلید نقش‌های پایه یا سفارشی (اعتبار کلید در API با دیتابیس چک می‌شود) */
export const roleSchema = z
  .string()
  .trim()
  .min(2, 'نقش نامعتبر است')
  .max(40, 'نقش نامعتبر است')

/** نام فارسی نقش — برای افزودن/تغییرنام در تب نقش‌ها */
export const roleLabelSchema = z.object({
  label: z.string().trim().min(2, 'نام نقش حداقل ۲ نویسه است').max(40, 'نام نقش حداکثر ۴۰ نویسه است'),
})

export const loginSchema = z.object({
  username: z.string().trim().min(2, 'نام کاربری خیلی کوتاه است').max(50),
  password: z.string().min(4, 'رمز عبور خیلی کوتاه است').max(100),
})

// ─── کاربران و پروژه ───────────────────────────────────────────────

export const createUserSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3, 'نام کاربری حداقل ۳ نویسه')
    .max(40)
    .regex(/^[a-zA-Z0-9._-]+$/, 'نام کاربری فقط حروف انگلیسی، عدد، نقطه و خط تیره'),
  fullName: z.string().trim().min(3, 'نام و نام خانوادگی را کامل وارد کنید').max(80),
  role: roleSchema,
  // سیاست رمز: حداقل ۸ نویسه، حداقل یک حرف و یک عدد
  password: z
    .string()
    .min(8, 'رمز عبور حداقل ۸ نویسه باشد')
    .max(100)
    .regex(/[a-zA-Zآ-ی]/, 'رمز باید حداقل یک حرف داشته باشد')
    .regex(/[0-9]/, 'رمز باید حداقل یک عدد داشته باشد')
    .optional(),
  // پروفایل پرسنلی (برای کارمند)
  nationalId: z.string().trim().max(20).optional().nullable(),
  phone: z.string().trim().max(20).optional().nullable(),
  position: z.string().trim().max(60).optional().nullable(),
  hireDate: z.string().regex(JALALI_DATE, 'تاریخ استخدام باید مثل 1404/05/01 باشد').optional().nullable(),
  baseSalary: z.coerce.number().min(0).optional().nullable(),
  projectId: z.string().min(1).optional().nullable(),
})

export const updateUserSchema = z.object({
  fullName: z.string().trim().min(3).max(80).optional(),
  isActive: z.boolean().optional(),
  role: roleSchema.optional(),
  password: z
    .string()
    .min(8, 'رمز عبور حداقل ۸ نویسه باشد')
    .max(100)
    .regex(/[a-zA-Zآ-ی]/, 'رمز باید حداقل یک حرف داشته باشد')
    .regex(/[0-9]/, 'رمز باید حداقل یک عدد داشته باشد')
    .optional(),
  nationalId: z.string().trim().max(20).optional().nullable(),
  phone: z.string().trim().max(20).optional().nullable(),
  position: z.string().trim().max(60).optional().nullable(),
  hireDate: z.string().regex(JALALI_DATE, 'تاریخ استخدام باید مثل 1404/05/01 باشد').optional().nullable(),
  baseSalary: z.coerce.number().min(0).optional().nullable(),
  projectId: z.string().min(1).optional().nullable(),
})

export const projectSchema = z.object({
  name: z.string().trim().min(2, 'نام پروژه خیلی کوتاه است').max(80),
  note: z.string().trim().max(300).optional().nullable(),
})

export const projectUpdateSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  note: z.string().trim().max(300).optional().nullable(),
  isActive: z.boolean().optional(),
})

// ─── اخبار (روابط عمومی) ───────────────────────────────────────────

export const newsPostSchema = z.object({
  title: z.string().trim().min(3, 'عنوان خیلی کوتاه است').max(150),
  body: z.string().trim().min(3, 'متن اطلاعیه خالی است').max(5000),
  isUrgent: z.boolean().optional().default(false),
  expiresAt: z.string().datetime().nullable().optional(),
  targetRole: roleSchema.nullable().optional(),
})

export const newsPostUpdateSchema = newsPostSchema.partial()

// ─── کارکرد / فیش / امتیاز (منابع انسانی) ──────────────────────────

export const workLogSchema = z.object({
  userId: z.string().min(1, 'کارمند را انتخاب کنید'),
  date: z.string().regex(JALALI_DATE, 'تاریخ باید شمسی و مثل 1404/08/15 باشد'),
  hours: z.coerce.number().min(0, 'ساعت نمی‌تواند منفی باشد').max(24),
  overtime: z.coerce.number().min(0).max(24).optional().default(0),
  note: z.string().trim().max(500).optional().nullable(),
})

export const workLogUpdateSchema = workLogSchema.omit({ userId: true }).partial()

// آیتم فیش حقوقی — یک ردیف مزایا یا کسورات
export const payslipItemSchema = z.object({
  title: z.string().trim().min(1, 'عنوان آیتم را وارد کنید').max(80),
  kind: z.enum(['BENEFIT', 'DEDUCTION']),
  amount: z.coerce.number().min(0, 'مبلغ نمی‌تواند منفی باشد').max(1e12),
})

export type PayslipItem = z.infer<typeof payslipItemSchema>

export const payslipSchema = z.object({
  userId: z.string().min(1, 'کارمند را انتخاب کنید'),
  period: z.string().regex(JALALI_PERIOD, 'دوره باید مثل 1404/08 باشد'),
  baseSalary: z.coerce.number().min(0, 'مبلغ نمی‌تواند منفی باشد'),
  items: z.array(payslipItemSchema).max(50).optional().default([]),
  note: z.string().trim().max(500).optional().nullable(),
})

export const payslipUpdateSchema = payslipSchema.omit({ userId: true }).partial()

// آیتم قابل تعریف فیش (مزایا و کسورات) — واحد منابع انسانی
export const payItemSchema = z.object({
  title: z.string().trim().min(2, 'عنوان آیتم را وارد کنید').max(80),
  kind: z.enum(['BENEFIT', 'DEDUCTION']),
  order: z.coerce.number().int().min(0).max(999).optional().default(0),
  isActive: z.boolean().optional().default(true),
})

export const payItemUpdateSchema = payItemSchema.partial()

export const scoreEntrySchema = z.object({
  userId: z.string().min(1, 'کارمند را انتخاب کنید'),
  period: z.string().regex(JALALI_PERIOD, 'دوره باید مثل 1404/08 باشد'),
  score: z.coerce.number().int().min(0, 'امتیاز بین ۰ تا ۱۰۰').max(100),
  note: z.string().trim().max(500).optional().nullable(),
})

export const scoreEntryUpdateSchema = scoreEntrySchema.omit({ userId: true }).partial()

// ─── واحد مالی ─────────────────────────────────────────────────────

export const bankAccountSchema = z.object({
  name: z.string().trim().min(2, 'نام بانک/حساب را وارد کنید').max(80),
  accountNumber: z.string().trim().max(40).optional().nullable(),
  balance: z.coerce.number().min(0, 'موجودی نمی‌تواند منفی باشد').optional().default(0),
  note: z.string().trim().max(300).optional().nullable(),
})

export const bankAccountUpdateSchema = bankAccountSchema.partial()

export const transactionSchema = z.object({
  kind: z.enum(['RECEIVE', 'PAY']),
  amount: z.coerce.number().positive('مبلغ باید بیشتر از صفر باشد'),
  date: z.string().regex(JALALI_DATE, 'تاریخ باید شمسی و مثل 1404/08/15 باشد'),
  title: z.string().trim().min(2, 'بابت چه بوده؟').max(150),
  bankAccountId: z.string().min(1).optional().nullable(),
  note: z.string().trim().max(300).optional().nullable(),
})

export const transactionUpdateSchema = transactionSchema.partial()

export const profitCalcMethods = ['SIMPLE_MONTHLY', 'MATURITY_LUMP', 'COMPOUND'] as const
export const profitPartialRules = ['IGNORE', 'FULL_MONTH', 'PRO_RATA'] as const

/** ایجاد حساب سوددار شخص */
export const profitAccountSchema = z.object({
  personName: z.string().trim().min(2, 'نام شخص را کامل وارد کنید').max(80),
  principal: z.coerce.number().positive('مبلغ اولیه باید بیشتر از صفر باشد').max(1e15),
  startDate: z.string().regex(JALALI_DATE, 'تاریخ شروع باید مثل 1404/08/15 باشد'),
  monthlyRate: z.coerce.number().min(0, 'نرخ سود نمی‌تواند منفی باشد').max(100, 'نرخ سود بین ۰ تا ۱۰۰ درصد'),
  calcMethod: z.enum(profitCalcMethods),
  partialRule: z.enum(profitPartialRules).optional().default('PRO_RATA'),
  maturityDate: z.string().regex(JALALI_DATE, 'تاریخ سررسید باید مثل 1405/08/15 باشد').optional().nullable(),
  contractNo: z.string().trim().max(60).optional().nullable(),
  note: z.string().trim().max(500).optional().nullable(),
})

/** ویرایش حساب — هر تغییر مشخصات، بازسازی کامل دوره‌ها را در پی دارد */
export const profitAccountUpdateSchema = profitAccountSchema.partial().extend({
  status: z.enum(['ACTIVE', 'CLOSED']).optional(),
})

/** ثبت پرداخت برای حساب سوددار */
export const profitPaymentSchema = z.object({
  payType: z.enum(['INTEREST', 'PRINCIPAL', 'MIXED']),
  date: z.string().regex(JALALI_DATE, 'تاریخ پرداخت باید مثل 1405/08/15 باشد'),
  amount: z.coerce.number().positive('مبلغ باید بیشتر از صفر باشد').max(1e15),
  /** فقط برای پرداخت ترکیبی: بخش سود */
  interestPart: z.coerce.number().min(0).optional(),
  note: z.string().trim().max(300).optional().nullable(),
})

export const profitPaymentUpdateSchema = profitPaymentSchema.partial()

/** بستن حساب (تسویه) با تاریخ شمسی */
export const profitCloseSchema = z.object({
  date: z.string().regex(JALALI_DATE, 'تاریخ بستن باید مثل 1405/08/15 باشد').optional(),
})

// ─── ماشین‌آلات و بیمه ─────────────────────────────────────────────

export const machineSchema = z.object({
  name: z.string().trim().min(2, 'نام ماشین را وارد کنید').max(80),
  deviceNumber: z.string().trim().min(1, 'شماره دستگاه را وارد کنید').max(40),
  model: z.string().trim().max(60).optional().nullable(),
  plateNumber: z.string().trim().max(30).optional().nullable(),
  ownerName: z.string().trim().max(80, 'نام صاحب خودرو طولانی است').optional().nullable(),
  chassisNumber: z.string().trim().max(50, 'شماره شاسی طولانی است').optional().nullable(),
  year: z.string().trim().max(10).optional().nullable(),
  status: z.enum(['ACTIVE', 'INACTIVE']).optional().default('ACTIVE'),
  note: z.string().trim().max(300).optional().nullable(),
})

export const machineUpdateSchema = machineSchema.partial()

// کارت سوخت ماشین — تحویل به کارمند/پروژه فقط مخصوص کارت سوخت است
export const fuelCardSchema = z.object({
  cardNumber: z.string().trim().min(1, 'شماره کارت سوخت را وارد کنید').max(60),
  holderId: z.string().trim().max(40).optional().nullable(),
  projectId: z.string().trim().max(40).optional().nullable(),
  assignedAt: z
    .string()
    .trim()
    .optional()
    .nullable()
    .refine((v) => !v || isValidJalaliDate(v), 'تاریخ تحویل باید مثل 1405/01/15 باشد'),
  note: z.string().trim().max(300).optional().nullable(),
})

export const insuranceTypeSchema = z.object({
  name: z.string().trim().min(2, 'نوع بیمه را وارد کنید').max(60),
  note: z.string().trim().max(300).optional().nullable(),
})

export const policySchema = z.object({
  machineId: z.string().min(1, 'ماشین را انتخاب کنید'),
  typeId: z.string().min(1, 'نوع بیمه را انتخاب کنید'),
  company: z.string().trim().min(2, 'بیمه‌گر را وارد کنید').max(80),
  policyNumber: z.string().trim().min(1, 'شماره بیمه‌نامه را وارد کنید').max(60),
  startDate: z.string().regex(JALALI_DATE, 'تاریخ شروع باید مثل 1404/08/01 باشد'),
  endDate: z.string().regex(JALALI_DATE, 'تاریخ پایان باید مثل 1405/08/01 باشد'),
  note: z.string().trim().max(500).optional().nullable(),
})

export const policyUpdateSchema = policySchema.partial().extend({
  status: z.enum(['ACTIVE', 'EXPIRED', 'CANCELED']).optional(),
})

// فقط الحاقیه — تمدید حذف شد؛ برای سررسید جدید، بیمه‌نامه جدید ثبت می‌شود
export const policyActionSchema = z.object({
  kind: z.literal('ENDORSEMENT'),
  date: z.string().regex(JALALI_DATE, 'تاریخ باید مثل 1404/08/15 باشد'),
  amount: z.coerce.number().min(0).optional().nullable(),
  note: z.string().trim().max(500).optional().nullable(),
})
