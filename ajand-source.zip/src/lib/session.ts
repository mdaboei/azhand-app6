import { SignJWT, jwtVerify } from 'jose'
import { cookies, headers } from 'next/headers'
import { randomBytes } from 'node:crypto'
import type { Role } from '@/lib/types'

export type { Role }

// ─── نشست کاربران (JWT در کوکی امن) ────────────────────────────────

export const SESSION_COOKIE = 'karlist_session'
const MAX_AGE = 60 * 60 * 24 * 7 // یک هفته

export interface SessionPayload {
  userId: string
  role: Role
  fullName: string
  username: string
}

/**
 * کلید امضای JWT از متغیر محیطی AUTH_SECRET خوانده می‌شود.
 * اگر کلید نبود یا کوتاه بود (مثلاً فایل .env ناخواسته بازنویسی شده):
 *  ۱) یک کلید تصادفی قوی (۶۴ نویسه hex) ساخته می‌شود؛
 *  ۲) تا جای ممکن در فایل .env ذخیره می‌شود تا پس از ری‌استارت هم ثابت بماند؛
 *  ۳) در حافظهٔ پروسه کش می‌شود تا همهٔ درخواست‌ها با یک کلید کار کنند.
 * نتیجه: ورود کاربران هرگز به‌خاطر نبودن کلید با خطای ۵۰۰ متوقف نمی‌شود.
 */
function generateSecret(): string {
  return randomBytes(32).toString('hex')
}

function persistSecretToEnvFile(secret: string) {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require('node:fs') as typeof import('node:fs')
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const path = require('node:path') as typeof import('node:path')
    const envPath = path.join(process.cwd(), '.env')
    if (fs.existsSync(envPath)) {
      const content = fs.readFileSync(envPath, 'utf8')
      if (!/^AUTH_SECRET=/m.test(content)) {
        fs.appendFileSync(envPath, `AUTH_SECRET=${secret}\n`, 'utf8')
        console.warn('[auth] AUTH_SECRET در فایل .env ذخیره شد (خودترمیمی).')
      }
    } else {
      fs.writeFileSync(envPath, `AUTH_SECRET=${secret}\n`, 'utf8')
      console.warn('[auth] فایل .env ساخته و AUTH_SECRET ذخیره شد (خودترمیمی).')
    }
  } catch {
    // فایل‌سیستم فقط‌خواندنی یا هر خطای دیگر → کلید فقط در حافظه می‌ماند
  }
}

function resolveSecret(): string {
  const secret = process.env.AUTH_SECRET
  if (secret && secret.length >= 32) return secret

  const globalRef = globalThis as unknown as {
    __ajandAuthSecret?: string
  }
  if (globalRef.__ajandAuthSecret) return globalRef.__ajandAuthSecret

  const generated = generateSecret()
  globalRef.__ajandAuthSecret = generated
  console.warn(
    '[auth] هشدار: AUTH_SECRET در .env نبود یا کوتاه است — یک کلید تصادفی ساخته شد. ' +
      'برای ثابت‌ماندن نشست‌ها بین ری‌استارت‌ها، کلید در .env ذخیره می‌شود (در صورت امکان نوشتن).',
  )
  persistSecretToEnvFile(generated)
  return generated
}

function secretKey() {
  return new TextEncoder().encode(resolveSecret())
}

export async function signSession(payload: SessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(secretKey())
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey())
    if (!payload.userId || !payload.role) return null
    return {
      userId: payload.userId as string,
      role: payload.role as Role,
      fullName: payload.fullName as string,
      username: payload.username as string,
    }
  } catch {
    return null
  }
}

/** خواندن نشست از کوکی — در سرور کامپوننت‌ها و Route Handlerها کار می‌کند */
export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token) return null
  return verifySessionToken(token)
}

/**
 * تنظیمات کوکی بر اساس پروتکل واقعی درخواست (نه فقط رنج IP):
 * - HTTPS (پیش‌نمایش/هاست، حتی داخل iframe): SameSite=None + Secure
 * - HTTP با هر هاستی (لوکال، 192.168.x شرکت، یا آی‌پی ثابت اینترنتی مثل
 *   5.202.172.189): مرورگر و WebView اندروید کوکیِ Secure را روی اتصال
 *   غیرامن «دور می‌ریزند» و SameSite=None هم بدون Secure رد می‌شود —
 *   یعنی کاربر «وارد شدید» می‌بیند ولی نشست ذخیره نمی‌شود!
 *   پس روی HTTP همیشه Lax بدون Secure (صفحه مستقیم از خود سرور لود
 *   می‌شود و کوکی first-party است؛ Lax کاملاً کافی است).
 */
async function cookieAttributes(maxAge: number) {
  const h = await headers()
  const proto = (h.get('x-forwarded-proto') ?? 'http').split(',')[0].trim()
  const isHttps = proto === 'https'
  return {
    httpOnly: true,
    sameSite: (isHttps ? 'none' : 'lax') as 'none' | 'lax',
    secure: isHttps,
    path: '/',
    maxAge,
  }
}

/** ست‌کردن کوکی نشست — فقط داخل Route Handler */
export async function setSessionCookie(payload: SessionPayload) {
  const store = await cookies()
  const token = await signSession(payload)
  store.set(SESSION_COOKIE, token, await cookieAttributes(MAX_AGE))
}

export async function clearSessionCookie() {
  const store = await cookies()
  store.set(SESSION_COOKIE, '', { ...(await cookieAttributes(0)), maxAge: 0 })
}
