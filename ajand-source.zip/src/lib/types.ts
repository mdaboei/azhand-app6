// ─── تایپ‌های مشترک کلاینت و برچسب‌های فارسی ────────────────────────

export type Role =
  | 'ADMIN'
  | 'FINANCE'
  | 'HR'
  | 'PR'
  | 'INSURANCE'
  | 'MACHINERY'
  | 'MANAGEMENT'
  | 'EMPLOYEE'

export const ROLE_LABELS: Record<Role, string> = {
  ADMIN: 'ادمین اصلی',
  FINANCE: 'واحد مالی',
  HR: 'منابع انسانی',
  PR: 'روابط عمومی',
  INSURANCE: 'امور بیمه',
  MACHINERY: 'ماشین‌آلات',
  MANAGEMENT: 'مدیریت',
  EMPLOYEE: 'کارمند',
}

/** همه نقش‌ها به ترتیب نمایش در فرم‌ها */
export const ALL_ROLES: Role[] = [
  'ADMIN',
  'FINANCE',
  'HR',
  'PR',
  'INSURANCE',
  'MACHINERY',
  'MANAGEMENT',
  'EMPLOYEE',
]

// ─── بخش‌ها (پنل‌ها) — واحد دسترسی ریزدانه هر کاربر ─────────────────

/** بخش‌های برنامه؛ بیمه داخل ماشین‌آلات ادغام شد و «گزارش پروژه‌ها» اضافه شد */
export type Panel =
  | 'ADMIN'
  | 'FINANCE'
  | 'HR'
  | 'PR'
  | 'MACHINERY'
  | 'MANAGEMENT'
  | 'EMPLOYEE'
  | 'REPORTS'

export const PANELS: Panel[] = [
  'ADMIN',
  'FINANCE',
  'HR',
  'PR',
  'MACHINERY',
  'MANAGEMENT',
  'EMPLOYEE',
  'REPORTS',
]

export const PANEL_LABELS: Record<Panel, string> = {
  ADMIN: 'پنل ادمین',
  FINANCE: 'پنل مالی',
  HR: 'پنل منابع انسانی',
  PR: 'پنل روابط عمومی',
  MACHINERY: 'ماشین‌آلات و بیمه',
  MANAGEMENT: 'پنل مدیریت',
  EMPLOYEE: 'پنل کارمند',
  REPORTS: 'گزارش پروژه‌ها',
}

/** توضیح کوتاه هر بخش برای منوی همبرگری */
export const PANEL_DESCRIPTIONS: Record<Panel, string> = {
  ADMIN: 'کاربران، پروژه‌ها و دسترسی‌ها',
  FINANCE: 'بانک‌ها، تراکنش‌ها و حساب‌های سود',
  HR: 'کارکرد، فیش حقوقی و امتیاز',
  PR: 'اخبار و اطلاعیه‌ها',
  MACHINERY: 'ناوگان، بیمه‌نامه‌ها و الحاقیه‌ها',
  MANAGEMENT: 'گزارش‌های کلی شرکت',
  EMPLOYEE: 'اطلاعات و فیش کارمند',
  REPORTS: 'پست‌های روزانه مدیران پروژه',
}

/** مسیر هر پنل */
export const PANEL_PATHS: Record<Panel, string> = {
  ADMIN: '/admin',
  FINANCE: '/finance',
  HR: '/hr',
  PR: '/pr',
  MACHINERY: '/machinery',
  MANAGEMENT: '/management',
  EMPLOYEE: '/employee',
  REPORTS: '/reports',
}

export interface UserDTO {
  id: string
  username: string
  fullName: string
  role: Role
  isActive: boolean
  // پروفایل پرسنلی
  nationalId: string | null
  phone: string | null
  position: string | null
  hireDate: string | null
  baseSalary: number | null
  projectId: string | null
  projectName: string | null
  createdAt: string
}

/** یک نقش (پایه یا سفارشی) — از سرور /api/roles می‌آید */
export interface RoleInfoDTO {
  id: string
  key: string
  label: string
  isSystem: boolean
  userCount: number
}

export interface ProjectDTO {
  id: string
  name: string
  note: string | null
  isActive: boolean
  employeeCount?: number
}

export interface NewsPostDTO {
  id: string
  title: string
  body: string
  isUrgent: boolean
  expiresAt: string | null
  targetRole: Role | null
  targetRoleLabel: string | null
  authorName: string
  createdAt: string
  hasImage: boolean
  likeCount: number
  commentCount: number
  likedByMe: boolean
}

export interface WorkLogDTO {
  id: string
  userId: string
  userName: string
  date: string
  hours: number
  overtime: number
  note: string | null
  createdAt: string
}

/** یک آیتم فیش حقوقی — مزایا یا کسورات */
export interface PayslipItemDTO {
  title: string
  kind: 'BENEFIT' | 'DEDUCTION'
  amount: number
}

export interface PayslipDTO {
  id: string
  userId: string
  userName: string
  period: string
  baseSalary: number
  items: PayslipItemDTO[]
  netPay: number
  note: string | null
  issuedByName: string
  createdAt: string
}

export interface ScoreEntryDTO {
  id: string
  userId: string
  userName: string
  period: string
  score: number
  note: string | null
  createdAt: string
}

// ─── مالی ──────────────────────────────────────────────────────────

export interface BankAccountDTO {
  id: string
  name: string
  accountNumber: string | null
  balance: number
  note: string | null
}

export type TransactionKind = 'RECEIVE' | 'PAY'

export interface TransactionDTO {
  id: string
  kind: TransactionKind
  amount: number
  date: string
  title: string
  bankAccountId: string | null
  bankAccountName: string | null
  note: string | null
  createdByName: string
  createdAt: string
}

export interface ProfitAccountDTO {
  id: string
  personName: string
  principal: number
  startDate: string
  monthlyRate: number
  calcMethod: ProfitCalcMethod
  partialRule: ProfitPartialRule
  maturityDate: string | null
  contractNo: string | null
  note: string | null
  status: 'ACTIVE' | 'CLOSED'
  closedAt: string | null
  createdAt: string
  /** خلاصهٔ محاسباتی — سرور محاسبه می‌کند */
  stats: ProfitStatsDTO
}

export type ProfitCalcMethod = 'SIMPLE_MONTHLY' | 'MATURITY_LUMP' | 'COMPOUND'
export type ProfitPartialRule = 'IGNORE' | 'FULL_MONTH' | 'PRO_RATA'
export type ProfitPayType = 'INTEREST' | 'PRINCIPAL' | 'MIXED'

export const PROFIT_METHOD_LABELS: Record<ProfitCalcMethod, string> = {
  SIMPLE_MONTHLY: 'سود ماهانه با اصل ثابت',
  MATURITY_LUMP: 'سود ساده تجمیعی در سررسید',
  COMPOUND: 'سود مرکب ماهانه',
}

export const PROFIT_METHOD_HINTS: Record<ProfitCalcMethod, string> = {
  SIMPLE_MONTHLY: 'سود هر ماه از اصل سرمایه محاسبه و قابل پرداخت است؛ سود پرداخت‌نشده معوق می‌ماند و به اصل اضافه نمی‌شود.',
  MATURITY_LUMP: 'سود ماه‌ها تجمیع می‌شود و در تاریخ سررسید تسویه می‌گردد؛ پرداخت زودتر از سررسید هم مجاز است.',
  COMPOUND: 'در پایان هر ماه، سود به اصل اضافه می‌شود و سود ماه بعد از اصل جدید محاسبه می‌گردد.',
}

export const PROFIT_RULE_LABELS: Record<ProfitPartialRule, string> = {
  IGNORE: 'ماه ناقص محسوب نمی‌شود',
  FULL_MONTH: 'ماه شروع‌شده کامل محسوب می‌شود',
  PRO_RATA: 'روزشمار (به نسبت روزهای ماه)',
}

export const PROFIT_PAYTYPE_LABELS: Record<ProfitPayType, string> = {
  INTEREST: 'بابت سود',
  PRINCIPAL: 'بابت اصل سرمایه',
  MIXED: 'ترکیبی (اصل و سود)',
}

/** یک دورهٔ ماهانهٔ قطعی‌شده در دفتر حساب */
export interface ProfitPeriodDTO {
  id: string
  idx: number
  startDate: string
  endDate: string
  days: number
  opening: number
  interest: number
  capitalized: number
  principalPaid: number
  closing: number
}

/** دورهٔ جاری (هنوز قطعی نشده) */
export interface ProfitOngoingDTO {
  idx: number
  startDate: string
  endDate: string
  daysElapsed: number
  daysTotal: number
  accruedSoFar: number
  note: string
}

export interface ProfitPaymentDTO {
  id: string
  date: string
  amount: number
  payType: ProfitPayType
  interestPart: number
  principalPart: number
  note: string | null
  createdAt: string
}

export interface ProfitLogDTO {
  id: string
  action: string
  detail: string
  createdAt: string
}

/** خلاصهٔ محاسباتی هر حساب — همهٔ مبالغ تومان */
export interface ProfitStatsDTO {
  /** تعداد دوره‌های قطعی‌شده (ماه‌های سپری‌شده) */
  monthsElapsed: number
  /** مجموع سود ایجادشده (قطعی‌شده) */
  accrued: number
  /** بخش مرکب‌شده به اصل (فقط روش مرکب) */
  capitalized: number
  /** مجموع سود پرداخت‌شده */
  paidInterest: number
  /** مجموع اصل بازپرداخت‌شده */
  paidPrincipal: number
  /** اصل سرمایهٔ فعلی (شامل سود مرکب‌شده در روش مرکب) */
  currentPrincipal: number
  /** سود معوق / پرداخت‌نشده */
  unpaidInterest: number
  /** مجموع بدهی فعلی شرکت به شخص */
  totalDebt: number
  /** آیا تاریخ سررسید رسیده است؟ */
  maturityReached: boolean
  /** روز تا سررسید (منفی = گذشته) */
  daysToMaturity: number | null
  /** دورهٔ جاری در جریان */
  ongoing: ProfitOngoingDTO | null
}

export interface ProfitAccountDetailDTO extends ProfitAccountDTO {
  periods: ProfitPeriodDTO[]
  payments: ProfitPaymentDTO[]
  logs: ProfitLogDTO[]
}

// ─── ماشین‌آلات و بیمه ─────────────────────────────────────────────

export interface MachineDTO {
  id: string
  name: string
  deviceNumber: string | null
  model: string | null
  plateNumber: string | null
  ownerName?: string | null
  chassisNumber?: string | null
  year: string | null
  status: 'ACTIVE' | 'INACTIVE'
  note: string | null
  activePolicyCount?: number
  attachmentsCount?: number
  fuelCard?: FuelCardSummaryDTO | null
}

/** خلاصه کارت سوخت روی کارت ماشین */
export interface FuelCardSummaryDTO {
  cardNumber: string
  assignedAt: string | null
  holderName: string | null
  projectName: string | null
}

export interface MachineAttachmentDTO {
  id: string
  machineId: string
  fileName: string
  mimeType: string
  size: number
  createdAt: string
}

/** کارت سوخت کامل (فرم + پیوست‌های رسید تحویل) */
export interface FuelCardDTO extends FuelCardSummaryDTO {
  id: string
  machineId: string
  holderId: string | null
  projectId: string | null
  note: string | null
  attachments: FuelCardAttachmentDTO[]
}

export interface FuelCardAttachmentDTO {
  id: string
  cardId: string
  fileName: string
  mimeType: string
  size: number
  createdAt: string
}

/** بیمه‌نامه‌ای که تا ۲ روز آینده منقضی می‌شود — برای نوتیف بالای صفحه */
export interface ExpiringPolicyDTO {
  id: string
  machineId: string
  machineName: string
  typeName: string
  company: string
  policyNumber: string
  endDate: string
  daysLeft: number
}

export interface InsuranceTypeDTO {
  id: string
  name: string
  note: string | null
}

export type PolicyStatus = 'ACTIVE' | 'EXPIRED' | 'CANCELED'

export interface PolicyDTO {
  id: string
  machineId: string
  machineName: string
  typeId: string
  typeName: string
  company: string
  policyNumber: string
  startDate: string
  endDate: string
  status: PolicyStatus
  note: string | null
  createdAt: string
}

export interface PolicyActionDTO {
  id: string
  policyId: string
  kind: 'RENEWAL' | 'ENDORSEMENT'
  date: string
  newEndDate: string | null
  amount: number | null
  note: string | null
  createdAt: string
}

export interface PolicyAttachmentDTO {
  id: string
  policyId: string
  fileName: string
  mimeType: string
  size: number
  createdAt: string
}

// ─── گزارش پروژه‌ها (پست مدیران پروژه) ─────────────────────────────

export interface ReportDTO {
  id: string
  authorId: string
  authorName: string
  authorRole: string
  /** برچسب فارسی نقش نویسنده — از تعریف نقش‌ها (نقش سفارشی هم درست می‌آید) */
  authorRoleLabel?: string
  authorPosition: string | null
  body: string
  isPublic: boolean
  createdAt: string
  photoIds: string[]
  likeCount: number
  superLikeCount: number
  commentCount: number
  likedByMe: boolean
  myLikeIsSuper: boolean
}

export interface ReportCommentDTO {
  id: string
  reportId: string
  userId: string
  userName: string
  body: string
  createdAt: string
}

export interface ReportAuthorProfile {
  id: string
  fullName: string
  role: string
  roleLabel: string
  position: string | null
  projectName: string | null
  postCount: number
}

export interface ReportFeedResponse {
  reports: ReportDTO[]
  author?: ReportAuthorProfile
}

/** مسیر خروج بعد از ورود، بر اساس نقش
 *  نقش‌های پایه مسیر مشخص دارند؛ نقش‌های سفارشی به صفحهٔ اصلی می‌روند
 *  (ورود/گارد مسیر دقیق‌تر را با اولین پنل مجاز کاربر می‌سازند).
 */
export function homeForRole(role: string): string {
  const map: Record<Role, string> = {
    ADMIN: '/admin',
    FINANCE: '/finance',
    HR: '/hr',
    PR: '/pr',
    INSURANCE: '/machinery', // پنل بیمه داخل ماشین‌آلات ادغام شد
    MACHINERY: '/machinery',
    MANAGEMENT: '/management',
    EMPLOYEE: '/employee',
  }
  return map[role as Role] ?? '/'
}
