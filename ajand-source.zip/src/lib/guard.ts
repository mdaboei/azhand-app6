import { redirect } from 'next/navigation'
import { getSession } from '@/lib/session'
import { homeForRole, PANEL_PATHS, type Panel, type Role } from '@/lib/types'
import { getUserPanelList, hasUserPanelAccess } from '@/lib/permissions'
import { getRoleLabelMap } from '@/lib/roles'
import { db } from '@/lib/db'

export type { Panel }

interface GuardResult {
  session: NonNullable<Awaited<ReturnType<typeof getSession>>>
  user: { id: string; fullName: string; role: string }
  /** برچسب فارسی نقش — از تعریف نقش‌ها (نقش سفارشی هم درست نمایش داده می‌شود) */
  roleLabel: string
  /** بخش‌های فعال این کاربر — برای منوی همبرگری پنل */
  panels: Panel[]
}

/**
 * گارد صفحات پنل بر اساس دسترسی ریزدانه هر کاربر:
 *  ۱) تخصیص اختصاصی کاربر (UserPanel)؛ اگر نبود پیش‌فرض نقش (ماتریس دسترسی‌ها)؛
 *  ۲) اگر وارد نشده → /login؛ اگر بخش مجاز نیست → اولین بخش مجازش؛
 *  ۳) اگر حسابش غیرفعال شده → /login.
 */
export async function requirePanelPage(panel: Panel): Promise<GuardResult> {
  const session = await getSession()
  if (!session) redirect('/login')

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, fullName: true, role: true, isActive: true },
  })
  if (!user || !user.isActive) redirect('/login')

  const role = user.role as Role
  const allowed = await hasUserPanelAccess(user.id, role, panel)
  if (!allowed) {
    // اولین بخشِ مجازِ این کاربر — اگر هیچ بخشی ندارد → صفحه اصلی (فید اطلاعیه‌ها)
    const panels = await getUserPanelList(user.id, role)
    redirect(panels[0] ? PANEL_PATHS[panels[0]] : '/')
  }

  const [panelsList, labels] = await Promise.all([
    getUserPanelList(user.id, role),
    getRoleLabelMap(),
  ])
  return { session, user, roleLabel: labels[user.role] ?? user.role, panels: panelsList }
}

/**
 * گارد نقش‌محور (برای صفحات چاپ و موارد خاص):
 * اجازه با نقش‌های تعیین‌شده یا با داشتن یکی از «بخش‌های» تعیین‌شده
 * (سیستم دو لایه — تخصیص per-user مقدم بر پیش‌فرض نقش).
 * اگر هیچ‌کدام نبود → به صفحه اصلی نقش کاربر هدایت می‌شود.
 */
export async function requireRolePage(roles: Role[], panels?: Panel[]): Promise<GuardResult> {
  const session = await getSession()
  if (!session) redirect('/login')

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, fullName: true, role: true, isActive: true },
  })
  if (!user || !user.isActive) redirect('/login')

  const role = user.role as Role
  let allowed = roles.includes(role)
  if (!allowed && panels && panels.length > 0) {
    for (const p of panels) {
      if (await hasUserPanelAccess(user.id, role, p)) {
        allowed = true
        break
      }
    }
  }
  if (!allowed) redirect(homeForRole(role))

  const [panelsList, labels] = await Promise.all([
    getUserPanelList(user.id, role),
    getRoleLabelMap(),
  ])
  return { session, user, roleLabel: labels[user.role] ?? user.role, panels: panelsList }
}
