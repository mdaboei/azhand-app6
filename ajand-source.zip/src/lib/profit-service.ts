// ─── سرویس حساب‌های سوددار — نگاشت مدل‌های دیتابیس به DTO مشترک ────

import { db } from '@/lib/db'
import {
  computePeriods,
  computeStats,
  syncAllProfitAccounts,
  syncProfitAccount,
  todayJalali,
  type AccountCore,
  type PaymentCore,
} from '@/lib/profit-engine'
import type {
  ProfitAccountDTO,
  ProfitAccountDetailDTO,
  ProfitCalcMethod,
  ProfitLogDTO,
  ProfitPartialRule,
  ProfitPayType,
  ProfitPaymentDTO,
  ProfitPeriodDTO,
  ProfitStatsDTO,
} from '@/lib/types'

type AccountRow = Awaited<ReturnType<typeof db.profitAccount.findFirst>>
type PaymentRow = Awaited<ReturnType<typeof db.profitPayment.findFirst>>

export function accountCoreOf(acc: NonNullable<AccountRow>): AccountCore {
  return {
    principal: acc.principal,
    startDate: acc.startDate,
    monthlyRate: acc.monthlyRate,
    calcMethod: acc.calcMethod as ProfitCalcMethod,
    partialRule: acc.partialRule as ProfitPartialRule,
    maturityDate: acc.maturityDate,
    status: acc.status as 'ACTIVE' | 'CLOSED',
    closedAt: acc.closedAt,
  }
}

export function paymentCoreOf(p: NonNullable<PaymentRow>): PaymentCore {
  return { date: p.date, interestPart: p.interestPart, principalPart: p.principalPart }
}

export function mapStats(acc: NonNullable<AccountRow>, payments: PaymentCore[]): ProfitStatsDTO {
  const today = todayJalali()
  const rows = computePeriods(accountCoreOf(acc), payments, today)
  return computeStats(accountCoreOf(acc), rows, payments, today)
}

export function mapAccountDTO(acc: NonNullable<AccountRow>, payments: PaymentCore[]): ProfitAccountDTO {
  return {
    id: acc.id,
    personName: acc.personName,
    principal: acc.principal,
    startDate: acc.startDate,
    monthlyRate: acc.monthlyRate,
    calcMethod: acc.calcMethod as ProfitCalcMethod,
    partialRule: acc.partialRule as ProfitPartialRule,
    maturityDate: acc.maturityDate,
    contractNo: acc.contractNo,
    note: acc.note,
    status: acc.status as 'ACTIVE' | 'CLOSED',
    closedAt: acc.closedAt,
    createdAt: acc.createdAt.toISOString(),
    stats: mapStats(acc, payments),
  }
}

/** لیست همهٔ حساب‌ها با خلاصهٔ محاسباتی — ابتدا دوره‌های قطعی همگام می‌شوند */
export async function listProfitAccountDTOs(): Promise<ProfitAccountDTO[]> {
  await syncProfitAccountAll()
  const accounts = await db.profitAccount.findMany({ orderBy: { createdAt: 'desc' } })
  const out: ProfitAccountDTO[] = []
  for (const acc of accounts) {
    const payments = await db.profitPayment.findMany({ where: { accountId: acc.id } })
    out.push(mapAccountDTO(acc, payments.map(paymentCoreOf)))
  }
  return out
}

/** همگام‌سازی همهٔ حساب‌ها (ایجاد دوره‌های قطعی تازه) */
export async function syncProfitAccountAll(): Promise<void> {
  await syncAllProfitAccounts()
}

/** جزئیات کامل یک حساب: دوره‌ها، پرداخت‌ها و تاریخچهٔ تغییرات */
export async function getProfitAccountDetail(id: string): Promise<ProfitAccountDetailDTO | null> {
  await syncProfitAccount(id)
  const acc = await db.profitAccount.findUnique({ where: { id } })
  if (!acc) return null
  const paymentsRaw = await db.profitPayment.findMany({
    where: { accountId: id },
    orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
  })
  const periodsRaw = await db.profitPeriod.findMany({
    where: { accountId: id },
    orderBy: { idx: 'asc' },
  })
  const logsRaw = await db.profitLog.findMany({
    where: { accountId: id },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })
  const payments = paymentsRaw.map(paymentCoreOf)
  const stats = mapStats(acc, payments)
  const periods: ProfitPeriodDTO[] = periodsRaw.map((p) => ({
    id: p.id,
    idx: p.idx,
    startDate: p.startDate,
    endDate: p.endDate,
    days: p.days,
    opening: p.opening,
    interest: p.interest,
    capitalized: p.capitalized,
    principalPaid: p.principalPaid,
    closing: p.closing,
  }))
  const paymentDTOs: ProfitPaymentDTO[] = paymentsRaw.map((p) => ({
    id: p.id,
    date: p.date,
    amount: p.amount,
    payType: p.payType as ProfitPayType,
    interestPart: p.interestPart,
    principalPart: p.principalPart,
    note: p.note,
    createdAt: p.createdAt.toISOString(),
  }))
  const logs: ProfitLogDTO[] = logsRaw.map((l) => ({
    id: l.id,
    action: l.action,
    detail: l.detail,
    createdAt: l.createdAt.toISOString(),
  }))
  return {
    ...mapAccountDTO(acc, payments),
    periods,
    payments: paymentDTOs,
    logs,
  }
}

/** ثبت رخداد در تاریخچهٔ حساب */
export async function addProfitLog(
  accountId: string,
  action: string,
  detail: string,
  userId?: string,
): Promise<void> {
  await db.profitLog.create({
    data: { accountId, action, detail, createdById: userId ?? null },
  })
}
