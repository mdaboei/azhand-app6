/**
 * محدودکننده نرخ درخواست (Rate Limit) در حافظه — مناسب تک‌سرور.
 *
 * جلوی حمله brute-force به صفحه ورود را می‌گیرد:
 * هر ترکیب IP + نام کاربری حداکثر MAX_ATTEMPTS تلاش در پنجره WINDOW_MS
 * امکان دارد؛ بعدش تا پایان پنجره قفل می‌شود.
 */

const MAX_ATTEMPTS = 5
const WINDOW_MS = 10 * 60 * 1000 // ۱۰ دقیقه

const buckets = new Map<string, { count: number; resetAt: number }>()

/** پاک‌سازی دوره‌ای رکوردهای منقضی تا حافظه رشد نکند */
function sweep() {
  const now = Date.now()
  for (const [key, entry] of buckets) {
    if (entry.resetAt <= now) buckets.delete(key)
  }
}

export interface RateLimitResult {
  ok: boolean
  /** تا اجازه تلاش بعدی چند ثانیه مانده (وقتی ok=false) */
  retryAfterSec: number
}

export function checkRateLimit(key: string): RateLimitResult {
  const now = Date.now()
  if (buckets.size > 5000) sweep()

  const entry = buckets.get(key)
  if (!entry || entry.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + WINDOW_MS })
    return { ok: true, retryAfterSec: 0 }
  }

  entry.count += 1
  if (entry.count > MAX_ATTEMPTS) {
    return { ok: false, retryAfterSec: Math.ceil((entry.resetAt - now) / 1000) }
  }
  return { ok: true, retryAfterSec: 0 }
}

/** بعد از ورود موفق، شمارنده همان کلید را پاک می‌کند */
export function resetRateLimit(key: string) {
  buckets.delete(key)
}

/** استخراج IP واقعی پشت پروکسی (Caddy/ nginx) */
export function clientIp(headers: Headers): string {
  return (
    headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    headers.get('x-real-ip') ||
    'unknown'
  )
}
