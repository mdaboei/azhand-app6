// ─── کمک‌تابع‌های فارسی: اعداد، پول و تاریخ شمسی ───────────────────

/** عدد با جداکننده هزارگان و رقم فارسی */
export function faNum(n: number | string): string {
  const value = typeof n === 'string' ? Number(n) : n
  if (!Number.isFinite(value)) return '—'
  return value.toLocaleString('fa-IR')
}

/** مبلغ به تومان */
export function faMoney(n: number | string): string {
  return `${faNum(n)} تومان`
}

/** رقم فارسی برای متن‌های کوچک */
export function faDigits(s: string | number): string {
  return String(s).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)])
}

const jalaliFmt = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', {
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
})

/** تاریخ امروز به شمسی — مثل "1404/08/15" */
export function jalaliToday(): string {
  try {
    const parts = jalaliFmt.formatToParts(new Date())
    const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '01'
    return `${get('year')}/${get('month')}/${get('day')}`
  } catch {
    return ''
  }
}

/** ماه جاری شمسی — مثل "1404/08" */
export function jalaliMonthNow(): string {
  return jalaliToday().slice(0, 7)
}

/** اعتبارسنجی تاریخ شمسی رشته‌ای مثل 1404/08/15 */
export function isValidJalaliDate(s: string): boolean {
  if (!/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(s)) return false
  const [, m, d] = s.split('/').map(Number)
  return m >= 1 && m <= 12 && d >= 1 && d <= 31
}

/** اعتبارسنجی دوره شمسی مثل 1404/08 */
export function isValidJalaliPeriod(s: string): boolean {
  if (!/^\d{4}\/\d{1,2}$/.test(s)) return false
  const m = Number(s.split('/')[1])
  return m >= 1 && m <= 12
}

/** صفرگذاری اجزای تاریخ شمسی برای مقایسه/مرتب‌سازی — "1405/8/1" → "1405/08/01" */
export function padJalali(s: string): string {
  if (!s) return ''
  const [y = '', m = '1', d = '1'] = s.split('/')
  return `${y}/${m.padStart(2, '0')}/${d.padStart(2, '0')}`
}

/** تبدیل ارقام فارسی/عربی به لاتین برای ورودی‌های عددی */
export function toEnDigits(s: string): string {
  return s
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
}

/**
 * قالب‌بندی زندهٔ تاریخ شمسی هنگام تایپ — جداکنندهٔ خودکار:
 * «1405» → «1405» ، «140508» → «1405/08» ، «14050830» → «1405/08/30»
 * ارقام فارسی هم پذیرفته می‌شود و هر کاراکتر غیرعددی حذف می‌شود.
 */
export function formatJalaliDateInput(raw: string): string {
  const digits = toEnDigits(raw).replace(/\D/g, '').slice(0, 8)
  return [
    digits.slice(0, 4),
    digits.slice(4, 6),
    digits.slice(6, 8),
  ]
    .filter(Boolean)
    .join('/')
}

/** قالب‌بندی زندهٔ دوره/ماه شمسی هنگام تایپ — «140508» → «1405/08» */
export function formatJalaliPeriodInput(raw: string): string {
  const digits = toEnDigits(raw).replace(/\D/g, '').slice(0, 6)
  return [
    digits.slice(0, 4),
    digits.slice(4, 6),
  ]
    .filter(Boolean)
    .join('/')
}

/** برچسب خوانا برای دوره، مثل "مهر ۱۴۰۴" */
const MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
]

export function periodLabel(period: string): string {
  try {
    const [y, m] = period.split('/')
    return `${MONTH_NAMES[Number(m) - 1]} ${faDigits(y)}`
  } catch {
    return period
  }
}

/** فاصله زمانی خوانا از الان برای «جدید» بودن خبر */
export function isRecent(dateIso: string, hours = 48): boolean {
  const t = new Date(dateIso).getTime()
  if (Number.isNaN(t)) return false
  return Date.now() - t < hours * 60 * 60 * 1000
}

/** تاریخ میلادی به فارسی خوانا برای نمایش رکوردها */
export function faDate(dateIso: string | Date): string {
  const d = typeof dateIso === 'string' ? new Date(dateIso) : dateIso
  if (Number.isNaN(d.getTime())) return '—'
  return d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' })
}

// ─── فاصله روز بین تاریخ‌های شمسی (هشدار انقضای بیمه و…) ──────────
// تبدیل دقیق تاریخ شمسی به «شماره روز ژولین» بر پایه الگوریتم jalaali؛
// اختلاف دو شماره = تعداد روزها بدون خطای تقویم.

function jDiv(a: number, b: number): number {
  return Math.trunc(a / b)
}

function jMod(a: number, b: number): number {
  return a - jDiv(a, b) * b
}

/** شماره روز ژولین معادل تاریخ میلادی */
function gregorianDayNumber(gy: number, gm: number, gd: number): number {
  return (
    jDiv((gy + jDiv(gm - 8, 6) + 100100) * 1461, 4) +
    jDiv(153 * jMod(gm + 9, 12) + 2, 5) +
    gd -
    1 -
    34840408 -
    jDiv((jDiv(gy, 100) + 1) * 3, 4) +
    752
  )
}

/** شماره روز ژولین تاریخ شمسی — مثل "1404/08/15" (تاریخ نامعتبر → NaN) */
export function jalaliDayNumber(s: string): number {
  const [yStr = '', mStr = '', dStr = ''] = s.split('/')
  const jy = Number(yStr)
  const jm = Number(mStr)
  const jd = Number(dStr)
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178]
  if (!jy || !jm || !jd || jy < breaks[0] || jy >= breaks[breaks.length - 1]) return NaN
  let leapJ = -14
  let jp = breaks[0]
  let jump = 0
  for (let i = 1; i < breaks.length; i += 1) {
    const jm2 = breaks[i]
    jump = jm2 - jp
    if (jy < jm2) break
    leapJ += jDiv(jump, 33) * 8 + jDiv(jMod(jump, 33), 4)
    jp = jm2
  }
  let n = jy - jp
  leapJ += jDiv(n, 33) * 8 + jDiv(jMod(n, 33) + 3, 4)
  if (jMod(jump, 33) === 4 && jump - n === 4) leapJ += 1
  const gy = jy + 621
  const leapG = jDiv(gy, 4) - jDiv((jDiv(gy, 100) + 1) * 3, 4) - 150
  const march = 20 + leapJ - leapG
  return gregorianDayNumber(gy, 3, march) + (jm - 1) * 31 - jDiv(jm, 7) * (jm - 7) + jd - 1
}

/**
 * فاصله روز تا تاریخ شمسی:
 * مثبت = چند روز تا آن تاریخ مانده، صفر = امروز، منفی = گذشته
 */
export function daysUntilJalali(s: string): number {
  const target = jalaliDayNumber(padJalali(s))
  if (Number.isNaN(target)) return NaN
  return target - jalaliDayNumber(jalaliToday())
}
