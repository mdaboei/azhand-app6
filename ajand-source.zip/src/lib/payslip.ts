import type { PayslipItem } from '@/lib/schemas'

/**
 * ابزارهای مشترک فیش حقوقی — محاسبهٔ خالص و خواندن آیتم‌ها از JSON دیتابیس
 */

/** خالص پرداختی = حقوق پایه + مجموع مزایا − مجموع کسورات */
export function netOf(base: number, items: PayslipItem[]): number {
  const benefits = items.filter((i) => i.kind === 'BENEFIT').reduce((s, i) => s + i.amount, 0)
  const deductions = items.filter((i) => i.kind === 'DEDUCTION').reduce((s, i) => s + i.amount, 0)
  return base + benefits - deductions
}

/** خواندن امن آیتم‌های ذخیره‌شده در ستون Json */
export function parseItems(raw: unknown): PayslipItem[] {
  if (!Array.isArray(raw)) return []
  const out: PayslipItem[] = []
  for (const it of raw) {
    if (!it || typeof it !== 'object') continue
    const r = it as Record<string, unknown>
    const title = typeof r.title === 'string' ? r.title : ''
    const kind = r.kind === 'DEDUCTION' ? 'DEDUCTION' : 'BENEFIT'
    const amount = typeof r.amount === 'number' && Number.isFinite(r.amount) ? r.amount : 0
    if (title && amount > 0) out.push({ title, kind, amount })
  }
  return out
}

/** یکسان‌سازی عنوان برای تطبیق آیتم‌های اکسل با تعریف‌ها (نیم‌فاصله/فاصله/ی و ک عربی) */
export function normalizeTitle(s: string): string {
  return s
    .replace(/[\u200c\u200f\u200e]/g, ' ')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u064B-\u0652]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}
