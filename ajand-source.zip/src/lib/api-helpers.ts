import { NextResponse } from 'next/server'
import { ZodError } from 'zod'
import { getSession, type Role, type SessionPayload } from '@/lib/session'
import { hasUserPanelAccess } from '@/lib/permissions'
import type { Panel } from '@/lib/types'

// ─── کمک‌تابع‌های مشترک API ─────────────────────────────────────────

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status })
}

export function fail(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status })
}

/**
 * گارد دسترسی: اگر نشست معتبر و نقش مجاز بود session برمی‌گرداند،
 * وگرنه پاسخ خطا (401/403) که باید مستقیم return شود.
 */
export async function requireSession(
  roles?: Role[],
): Promise<{ session: SessionPayload; res?: undefined } | { session?: undefined; res: NextResponse }> {
  const session = await getSession()
  if (!session) return { res: fail('ابتدا وارد شوید', 401) }
  if (roles && roles.length > 0 && !roles.includes(session.role)) {
    return { res: fail('شما به این بخش دسترسی ندارید', 403) }
  }
  return { session }
}

/**
 * گارد دسترسی بر اساس «بخش» (نه نقش):
 * کاربر باید تخصیص اختصاصی یا پیش‌فرض نقشش این بخش را داشته باشد.
 */
export async function requirePanelSession(
  panel: Panel,
): Promise<{ session: SessionPayload; res?: undefined } | { session?: undefined; res: NextResponse }> {
  const session = await getSession()
  if (!session) return { res: fail('ابتدا وارد شوید', 401) }
  if (session.role !== 'ADMIN') {
    const allowed = await hasUserPanelAccess(session.userId, session.role, panel)
    if (!allowed) return { res: fail('شما به این بخش دسترسی ندارید', 403) }
  }
  return { session }
}

/**
 * گارد دسترسی با چند بخش مجاز — اگر کاربر «هر یک» از این بخش‌ها را داشته باشد عبور می‌کند.
 * جایگزین گاردهای نقش‌محور قدیمی است تا تخصیص اختصاصی هر کاربر در APIها هم کار کند.
 */
export async function requireAnyPanel(
  ...panels: Panel[]
): Promise<{ session: SessionPayload; res?: undefined } | { session?: undefined; res: NextResponse }> {
  const session = await getSession()
  if (!session) return { res: fail('ابتدا وارد شوید', 401) }
  if (session.role === 'ADMIN') return { session }
  for (const panel of panels) {
    if (await hasUserPanelAccess(session.userId, session.role, panel)) return { session }
  }
  return { res: fail('شما به این بخش دسترسی ندارید', 403) }
}

/** تبدیل خطای zod به پیام فارسی قابل فهم */
export function zodMessage(err: ZodError): string {
  const issue = err.issues[0]
  if (!issue) return 'اطلاعات ارسالی نامعتبر است'
  const field = issue.path.join('.')
  return field ? `${field}: ${issue.message}` : issue.message
}

/** wrap خطاهای پیش‌بینی‌نشده سرور */
export function serverError(e: unknown) {
  console.error('[api]', e)
  return fail('خطای غیرمنتظره سرور — دوباره تلاش کنید', 500)
}
