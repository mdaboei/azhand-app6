import { NextResponse, type NextRequest } from 'next/server'
import { jwtVerify } from 'jose'

/**
 * دفاع لایه دوم (Defense in Depth) — طبق قرارداد جدید Next 16 (proxy):
 * قبل از رندر هر پنل، امضای JWT نشست لبه‌ای (Edge) بررسی می‌شود؛
 * توکن نامعتبر/منقضی → هدایت به /login.
 * بررسیِ کامل نقش و فعال‌بودن کاربر خودش در گارد سرورکامپوننت هر پنل
 * (src/lib/guard.ts) با اتصال به دیتابیس انجام می‌شود.
 *
 * نکته: از src/lib/session.ts ایمپورت نمی‌کنیم چون next/headers
 * در محیط Edge مجاز نیست؛ کلید از همان AUTH_SECRET خوانده می‌شود.
 * فیلتر مسیرها داخل تابع انجام می‌شود تا مستقل از semantics matcher باشد.
 */

const PANEL_PREFIXES = [
  '/admin',
  '/hr',
  '/finance',
  '/pr',
  '/insurance',
  '/machinery',
  '/management',
  '/employee',
]

function isPanelPath(pathname: string) {
  return PANEL_PREFIXES.some(
    (p) => pathname === p || pathname.startsWith(p + '/'),
  )
}

function secretKey() {
  const secret = process.env.AUTH_SECRET
  if (!secret || secret.length < 32) return null
  return new TextEncoder().encode(secret)
}

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl
  if (!isPanelPath(pathname)) return NextResponse.next()

  const token = req.cookies.get('karlist_session')?.value
  if (token) {
    const key = secretKey()
    if (!key) {
      // کلید امضا در Edge در دسترس نیست (مثلاً .env موقع بوت نبود).
      // رد شدن از لبه فقط بر اساس وجود کوکی؛ اعتبارسنجی رمزنگارانهٔ واقعی
      // در گارد سرورکامپوننت هر پنل (guard.ts) و همهٔ APIها انجام می‌شود.
      return NextResponse.next()
    }
    try {
      const { payload } = await jwtVerify(token, key)
      if (payload.userId && payload.role) return NextResponse.next()
    } catch {
      /* توکن نامعتبر است → پایین به /login می‌رود */
    }
  }

  const loginUrl = new URL('/login', req.url)
  const res = NextResponse.redirect(loginUrl)
  // کوکی معیوب را هم پاک کن
  res.cookies.set('karlist_session', '', { path: '/', maxAge: 0 })
  return res
}
