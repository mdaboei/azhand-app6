package com.example.karlist;

import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

/**
 * رفتار دکمه بازگشت گوشی — مثل یک برنامه واقعی:
 * تا وقتی وب‌ویو تاریخچه دارد (مثلاً داخل پنل هستیم)، بازگشت یعنی «یک صفحه عقب»،
 * فقط وقتی در اولین صفحه هستیم، برنامه بسته می‌شود.
 *
 * چرا لازم بود؟ Capacitor به‌صورت پیش‌فرض دکمه بازگشت را مدیریت نمی‌کند و
 * هر فشار دکمه بازگشت گوشی، کل برنامه را می‌بست.
 */
public class MainActivity extends BridgeActivity {

    @Override
    public void onBackPressed() {
        WebView webView = getBridge() != null ? getBridge().getWebView() : null;
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
