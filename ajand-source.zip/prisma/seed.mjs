// ─── Seed تمیز (نسخه ۳.۱۰ به بعد) ────────────────────────────────────
// هیچ داده نمونه‌ای ساخته نمی‌شود — فقط:
//   ۱) کاربر ادمین اولیه: admin / admin123  (بعد از ورود رمز را عوض کنید!)
//   ۲) نقش‌های سیستمی (جدول نقش‌ها) و دسترسی‌های پیش‌فرض پنل‌ها
// همه جدول‌ها قبل از ساخت، کامل پاک می‌شوند (شروع از صفر).
//
// اجرا: npm run db:seed   (یا خودکار: فقط بار اولی که دیتابیس ساخته می‌شود)

import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

const PW_ADMIN = 'admin123'

async function main() {
  console.log('⏳ پاک‌سازی کامل جدول‌ها (شروع از صفر)...')
  await db.insuranceAttachment.deleteMany()
  await db.insuranceAction.deleteMany()
  await db.insurancePolicy.deleteMany()
  await db.insuranceType.deleteMany()
  await db.machine.deleteMany()
  await db.reportComment.deleteMany()
  await db.reportLike.deleteMany()
  await db.reportPhoto.deleteMany()
  await db.projectReport.deleteMany()
  await db.newsComment.deleteMany()
  await db.newsLike.deleteMany()
  await db.newsPost.deleteMany()
  await db.userPanel.deleteMany()
  await db.transaction.deleteMany()
  await db.bankAccount.deleteMany()
  await db.profitAccount.deleteMany()
  await db.scoreEntry.deleteMany()
  await db.workLog.deleteMany()
  await db.payslip.deleteMany()
  await db.user.deleteMany()
  await db.project.deleteMany()

  console.log('⏳ ساخت کاربر ادمین...')
  await db.user.create({
    data: {
      username: 'admin',
      passwordHash: bcrypt.hashSync(PW_ADMIN, 10),
      fullName: 'مدیر سیستم',
      role: 'ADMIN',
    },
  })

  console.log('⏳ نقش‌های سیستمی...')
  const BUILTIN_ROLES = [
    { key: 'ADMIN', label: 'ادمین اصلی' },
    { key: 'FINANCE', label: 'واحد مالی' },
    { key: 'HR', label: 'منابع انسانی' },
    { key: 'PR', label: 'روابط عمومی' },
    { key: 'INSURANCE', label: 'امور بیمه' },
    { key: 'MACHINERY', label: 'ماشین‌آلات' },
    { key: 'MANAGEMENT', label: 'مدیریت' },
    { key: 'EMPLOYEE', label: 'کارمند' },
  ]
  await db.roleDef.deleteMany({ where: { isSystem: true } })
  await db.roleDef.createMany({
    data: BUILTIN_ROLES.map((r, i) => ({ ...r, isSystem: true, order: i + 1 })),
  })

  console.log('⏳ دسترسی‌های پیش‌فرض پنل‌ها (ماتریس نقش × پنل)...')
  // پنل INSURANCE داخل MACHINERY ادغام شده؛ REPORTS بخش «گزارش پروژه‌ها» است.
  const PANELS = ['ADMIN', 'FINANCE', 'HR', 'PR', 'MACHINERY', 'MANAGEMENT', 'EMPLOYEE', 'REPORTS']
  const DEFAULT_PANELS = {
    ADMIN: PANELS,
    FINANCE: ['FINANCE'],
    HR: ['HR'],
    PR: ['PR'],
    INSURANCE: ['MACHINERY'],
    MACHINERY: ['MACHINERY'],
    MANAGEMENT: ['MANAGEMENT', 'REPORTS'],
    EMPLOYEE: ['EMPLOYEE'],
  }
  const permCount = await db.permission.count()
  if (permCount === 0) {
    for (const [role, panels] of Object.entries(DEFAULT_PANELS)) {
      await db.permission.createMany({
        data: panels
          .filter((panel) => PANELS.includes(panel))
          .map((panel) => ({ role, panel })),
      })
    }
    console.log('   دسترسی‌های پیش‌فرض ساخته شد')
  }

  console.log('✅ تمام شد — سیستم تمیز و آماده است:')
  console.log(`   ادمین: admin / ${PW_ADMIN}`)
  console.log('   ⚠️ بعد از اولین ورود، رمز ادمین را از داخل پنل عوض کنید!')
}

main()
  .catch((e) => {
    console.error('❌', e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
