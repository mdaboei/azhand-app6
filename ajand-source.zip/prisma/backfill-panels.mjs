// ─── بک‌فیل یک‌بارِ دسترسی‌ها برای دیتابیس‌های قدیمی ──────────────────
// اجرا: npm run db:backfill  (در هر استارت سرور هم اجرا می‌شود — idempotent)
//  ۱) ردیف‌های پنل‌های حذف‌شده (مثل INSURANCE قدیمی) پاک می‌شوند؛
//  ۲) برای هر نقش که ردیف دسترسی دارد ولی پنل‌های تازه (مثل REPORTS) را
//     ندارد، پنل تازه مطابق پیش‌فرض امن اضافه می‌شود؛
//  ۳) نقش‌های پایه در جدول RoleDef ساخته می‌شوند (نقش‌های سفارشی ادمین دست‌نخورده می‌مانند).
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

const PANELS = ['ADMIN', 'FINANCE', 'HR', 'PR', 'MACHINERY', 'MANAGEMENT', 'EMPLOYEE', 'REPORTS']
const NEW_PANELS = { MANAGEMENT: ['REPORTS'] }

// نقش‌های پایه — هم‌سان با src/lib/types.ts
const BUILTIN_ROLES = [
  { key: 'ADMIN', label: 'ادمین اصلی' },
  { key: 'FINANCE', label: 'واحد مالی' },
  { key: 'HR', label: 'منابع انسانی' },
  { key: 'PR', label: 'روابط عمومی' },
  { key: 'INSURANCE', label: 'امور بیمه' },
  { key: 'MACHINERY', label: 'ماشین‌آلات' },
  { key: 'MANAGEMENT', label: 'مدیریت' },
  { key: 'EMPLOYEE', label: 'کارمند' },
]

async function main() {
  // ۱) حذف ردیف‌های پنل‌های نامعتبر
  const stale = await db.permission.deleteMany({
    where: { panel: { notIn: PANELS } },
  })
  if (stale.count > 0) console.log(`🧹 ${stale.count} ردیف پنل قدیمی حذف شد`)

  // ۲) افزودن پنل‌های تازه به نقش‌های دارای ردیف
  for (const [role, panels] of Object.entries(NEW_PANELS)) {
    const existing = await db.permission.findMany({ where: { role } })
    if (existing.length === 0) continue // نقش بدون ردیف → پیش‌فرض امن در کد اعمال می‌شود
    for (const panel of panels) {
      if (!existing.some((r) => r.panel === panel)) {
        await db.permission.create({ data: { role, panel } })
        console.log(`➕ پنل ${panel} به نقش ${role} اضافه شد`)
      }
    }
  }

  // ۳) نقش‌های پایه در جدول نقش‌ها (idempotent — سفارشی‌ها دست‌نخورده)
  //    توجه: برچسب نقش‌های پایه اگر ادمین عوض کرده باشد، برگردانده نمی‌شود
  let created = 0
  for (let i = 0; i < BUILTIN_ROLES.length; i++) {
    const { key, label } = BUILTIN_ROLES[i]
    const existing = await db.roleDef.findUnique({ where: { key } })
    if (existing) continue
    await db.roleDef.create({
      data: { key, label, isSystem: true, order: i + 1 },
    })
    created++
  }
  if (created > 0) console.log(`🎭 ${created} نقش پایه در جدول نقش‌ها ساخته شد`)

  console.log('✅ بک‌فیل دسترسی‌ها انجام شد')
}

main()
  .catch((e) => {
    console.error('❌', e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
