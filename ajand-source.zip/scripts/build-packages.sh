#!/bin/bash
# ─────────────────────────────────────────────────────────────
# ساخت بسته‌های تحویل «آژند اپ»
#   1) download/ajand-github.zip         → آپلود در گیت‌هاب + بیلد خودکار APK
#   2) download/ajand-windows-server.zip → سرور داخل شرکت (ویندوز)
# ─────────────────────────────────────────────────────────────
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

echo "[1/5] آماده‌سازی فایل‌های مشترک..."
SRC="$WORK/source"
mkdir -p "$SRC"

# فایل‌های ریشه
for f in .gitignore package.json tsconfig.json next.config.ts next-env.d.ts \
         postcss.config.mjs eslint.config.mjs components.json tailwind.config.ts \
         capacitor.config.ts; do
  [ -f "$ROOT/$f" ] && cp "$ROOT/$f" "$SRC/"
done

# پوشه‌ها (بدون zips داخل public)
mkdir -p "$SRC/src" "$SRC/public" "$SRC/prisma" "$SRC/cap-web" "$SRC/scripts"
cp -r "$ROOT/src/."        "$SRC/src/"
cp -r "$ROOT/prisma/."     "$SRC/prisma/"
cp -r "$ROOT/cap-web/."    "$SRC/cap-web/"
mkdir -p "$SRC/scripts" && cp -r "$ROOT/scripts/." "$SRC/scripts/"
# پوشه public (بدون zips داخل آن)
mkdir -p "$SRC/public"
(cd "$ROOT/public" && find . -type f ! -name '*.zip') | while read -r f; do
  mkdir -p "$SRC/public/$(dirname "$f")"
  cp "$ROOT/public/$f" "$SRC/public/$f"
done

# اندروید (بدون خروجی‌های بیلد)
cd "$ROOT"
rsync -a android/ "$SRC/android/" \
  --exclude 'build/' --exclude '.gradle/' --exclude 'local.properties' \
  2>/dev/null || { mkdir -p "$SRC/android"; (cd android && tar cf - \
  --exclude='build' --exclude='.gradle' --exclude='local.properties' .) \
  | (cd "$SRC/android" && tar xf -); }

echo "[2/5] ساخت ajand-source.zip..."
cd "$SRC"
rm -f "$WORK/ajand-source.zip"
zip -qr "$WORK/ajand-source.zip" .
echo "      $(unzip -l "$WORK/ajand-source.zip" | tail -1 | awk '{print $2}') فایل"

echo "[3/5] ساخت بسته گیت‌هاب..."
GH="$WORK/ajand-github"
mkdir -p "$GH/.github/workflows"
cp "$WORK/ajand-source.zip" "$GH/"
# ورک‌فلو با خط branches سالم
sed 's/^    branches:.*$/    branches: [main]/' \
  "$ROOT/.github/workflows/build-apk.yml" > "$GH/.github/workflows/build-apk.yml"
cp "$ROOT/scripts/deploy/README-github.md" "$GH/README.md" 2>/dev/null || true
cd "$WORK"
rm -f "$ROOT/download/ajand-github.zip"
zip -qr "$ROOT/download/ajand-github.zip" ajand-github

echo "[4/5] ساخت بسته سرور ویندوز..."
APP="$WORK/ajand-app"
cp -r "$SRC" "$APP"
# ⚠️ db و .env عمداً در زیپ قرار نمی‌گیرند:
#    - نصب اول: start-server.bat خودش db را می‌سازد و seed می‌کند و .env را با کلید تازه می‌سازد
#    - آپدیت: extract کردن زیپ جدید روی پوشه قبلی هرگز db و .env قدیمی را عوض نمی‌کند
#             (داده‌ها، رمزها و کلید امنیتی سر جایشان می‌مانند)
mkdir -p "$APP/db"
# شماره نسخه — باید با فوتر panel-shell و صفحه ورود هماهنگ بماند
APPVER=3.11
printf '%s\n' "$APPVER" > "$APP/VERSION"
cp "$ROOT/scripts/deploy/README-server.md" "$APP/README-server.md"
# bat با انتهای خط ویندوزی (CRLF)
sed 's/$/\r/' "$ROOT/scripts/deploy/start-server.bat" > "$APP/start-server.bat"
sed 's/$/\r/' "$ROOT/scripts/deploy/setup-network.bat" > "$APP/setup-network.bat"
sed 's/$/\r/' "$ROOT/scripts/deploy/reset-data.bat" > "$APP/reset-data.bat"
cd "$WORK"
rm -f "$ROOT/download/ajand-windows-server.zip"
zip -qr "$ROOT/download/ajand-windows-server.zip" ajand-app

echo "[5/5] کپی در public برای دانلود از پنل..."
cp "$ROOT/download/ajand-github.zip" "$ROOT/public/"
cp "$ROOT/download/ajand-windows-server.zip" "$ROOT/public/"

echo "✓ تمام شد:"
ls -la "$ROOT/download/"*.zip
