/**
 * اعمال لوگوی جدید شرکت (حرف A — ارسالی مدیر) روی همهٔ نقاط برند اپ:
 *
 *  ۱) public/icon-raw.png        — مستر مربعی سفید (ورودی resize-icons.js برای آیکون‌های وب)
 *  ۲) public/logo.png            — نسخهٔ پس‌زمینه‌شفاف (هدر و صفحهٔ ورود)
 *  ۳) cap-web/icon.png           — لوگوی splash پوستهٔ اندروید (۵۱۲)
 *  ۴) mipmap-های اندروید        — آیکون لانچر (legacy + round)
 *  ۵) ic_launcher_foreground    — لایهٔ جلوی adaptive icon (شفاف)
 *  ۶) drawable ها (splash.png)  — اسپلش بومی اندروید (کرم + لوگو وسط)
 *
 * اجرا:  node scripts/apply-logo.js
 */
const sharp = require('sharp')
const fs = require('node:fs')
const path = require('node:path')

const SRC = process.argv[2] || 'upload/logo - 2.png'
const ROOT = path.join(__dirname, '..')
const CREAM = { r: 239, g: 230, b: 222 } // #efe6de — رنگ برند

const MP = [
  ['mipmap-mdpi', 48, 108],
  ['mipmap-hdpi', 72, 162],
  ['mipmap-xhdpi', 96, 216],
  ['mipmap-xxhdpi', 144, 324],
  ['mipmap-xxxhdpi', 192, 432],
]

const SPLASH_DIRS = [
  'drawable', 'drawable-port-mdpi', 'drawable-port-hdpi', 'drawable-port-xhdpi',
  'drawable-port-xxhdpi', 'drawable-port-xxxhdpi', 'drawable-land-mdpi',
  'drawable-land-hdpi', 'drawable-land-xhdpi', 'drawable-land-xxhdpi',
  'drawable-land-xxxhdpi',
]

/** حذف پس‌زمینهٔ سفیدِ متصل به لبه‌ها (flood fill) — سفیدِ داخل حرف حفظ می‌شود */
function floodClearWhite(data, width, height) {
  const threshold = 235
  const isBg = (i) =>
    data[i] >= threshold && data[i + 1] >= threshold && data[i + 2] >= threshold
  const visited = new Uint8Array(width * height)
  const stack = []
  const push = (x, y) => {
    if (x < 0 || y < 0 || x >= width || y >= height) return
    const p = y * width + x
    if (visited[p]) return
    const i = p * 4
    if (!isBg(i)) return
    visited[p] = 1
    stack.push(p)
  }
  for (let x = 0; x < width; x++) {
    push(x, 0)
    push(x, height - 1)
  }
  for (let y = 0; y < height; y++) {
    push(0, y)
    push(width - 1, y)
  }
  while (stack.length) {
    const p = stack.pop()
    data[p * 4 + 3] = 0 // شفاف
    const x = p % width
    const y = Math.floor(p / width)
    push(x + 1, y)
    push(x - 1, y)
    push(x, y + 1)
    push(x, y - 1)
  }
}

async function makeMasters() {
  const trimmed = await sharp(SRC)
    .trim({ threshold: 25 })
    .toBuffer()
  const tmeta = await sharp(trimmed).metadata()
  const side = Math.max(tmeta.width, tmeta.height)
  const pad = Math.round(side * 0.07)

  // مستر مربعی سفید (آیکون‌های وب و لانچر legacy)
  await sharp(trimmed)
    .resize({ width: side, height: side, fit: 'contain', background: '#ffffff' })
    .extend({ top: pad, bottom: pad, left: pad, right: pad, background: '#ffffff' })
    .png()
    .toFile(path.join(ROOT, 'public/icon-raw.png'))

  // مستر شفاف (هدر / ورود / foreground اندروید)
  const { data, info } = await sharp(trimmed)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true })
  floodClearWhite(data, info.width, info.height)
  await sharp(data, { raw: { width: info.width, height: info.height, channels: 4 } })
    .png()
    .toFile(path.join(ROOT, 'public/logo.png'))

  return { transparent: await sharp(path.join(ROOT, 'public/logo.png')).toBuffer() }
}

async function roundMask(buf, size, radiusRatio) {
  const mask = Buffer.from(
    `<svg width="${size}" height="${size}"><rect width="${size}" height="${size}" rx="${Math.round(size * radiusRatio)}"/></svg>`,
  )
  return sharp(buf)
    .resize(size, size)
    .composite([{ input: mask, blend: 'dest-in' }])
    .png()
    .toBuffer()
}

async function circleMask(buf, size) {
  const mask = Buffer.from(
    `<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}"/></svg>`,
  )
  return sharp(buf)
    .resize(size, size)
    .composite([{ input: mask, blend: 'dest-in' }])
    .png()
    .toBuffer()
}

async function androidIcons({ transparent }) {
  const res = path.join(ROOT, 'android/app/src/main/res')
  for (const [dir, legacy, fg] of MP) {
    const out = path.join(res, dir)
    fs.mkdirSync(out, { recursive: true })
    // legacy — مربع گِرد و دایره (روی زمینهٔ سفید مستر)
    await roundMask(path.join(ROOT, 'public/icon-raw.png'), legacy, 0.22)
      .then((b) => sharp(b).toFile(path.join(out, 'ic_launcher.png')))
    await circleMask(path.join(ROOT, 'public/icon-raw.png'), legacy)
      .then((b) => sharp(b).toFile(path.join(out, 'ic_launcher_round.png')))
    // adaptive foreground — لوگوی شفاف در مرکز (۶۲٪ کانواس، خارج از ماسک لانچرها)
    const logoSize = Math.round(fg * 0.62)
    const m = Math.floor((fg - logoSize) / 2)
    await sharp(transparent)
      .resize(logoSize, logoSize, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .extend({
        top: m, bottom: fg - logoSize - m, left: m, right: fg - logoSize - m,
        background: { r: 0, g: 0, b: 0, alpha: 0 },
      })
      .png()
      .toFile(path.join(out, 'ic_launcher_foreground.png'))
    console.log('✓', dir, `(launcher ${legacy}px / foreground ${fg}px)`)
  }
}

async function splashes() {
  const res = path.join(ROOT, 'android/app/src/main/res')
  for (const dir of SPLASH_DIRS) {
    const file = path.join(res, dir, 'splash.png')
    if (!fs.existsSync(file)) continue
    const meta = await sharp(file).metadata()
    const w = meta.width
    const h = meta.height
    const logoW = Math.round(Math.min(w, h) * 0.28)
    // نسخهٔ شفاف لوگو — بدون قاب سفید، مستقیم روی زمینهٔ کرم برند
    const logo = await sharp(path.join(ROOT, 'public/logo.png'))
      .resize(logoW, logoW)
      .png()
      .toBuffer()
    await sharp({
      create: { width: w, height: h, channels: 4, background: CREAM },
    })
      .composite([{ input: logo, left: Math.round((w - logoW) / 2), top: Math.round((h - logoW) / 2) }])
      .png()
      .toFile(file)
    console.log('✓ splash', dir, `${w}x${h}`)
  }
}

async function main() {
  if (!fs.existsSync(path.join(ROOT, SRC))) {
    console.error('لوگو پیدا نشد:', SRC)
    process.exit(1)
  }
  const masters = await makeMasters()
  await sharp(path.join(ROOT, 'public/icon-raw.png'))
    .resize(512, 512)
    .png()
    .toFile(path.join(ROOT, 'cap-web/icon.png'))
  console.log('✓ cap-web/icon.png (512)')
  await androidIcons(masters)
  await splashes()
  console.log('تمام شد — لوگو روی همهٔ نقاط برند اعمال شد.')
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
