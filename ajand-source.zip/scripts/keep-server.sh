#!/bin/bash
# نگهبان سرور توسعه — اگر next dev پایین بیاید، دوباره بالا می‌آورد
cd /home/z/my-project
while true; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:3000/login 2>/dev/null)
  if [ "$code" != "200" ]; then
    pkill -f "next dev" 2>/dev/null
    pkill -f "next-server" 2>/dev/null
    sleep 1
    nohup bun run dev >> /tmp/dev-server.log 2>&1 &
  fi
  sleep 5
done
