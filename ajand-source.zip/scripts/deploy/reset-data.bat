@echo off
chcp 65001 >nul
title Ajand App - Reset Database
cd /d "%~dp0"

echo ============================================
echo        AJAND APP - Reset Database
echo ============================================
echo.
echo  [!] IN KAR HAMEYE DADAHAYE ZIR RA PAK MIKONAD:
echo      - Tamame karbaran va ramz-ha
echo      - Porsanl, tarakonesh-ha, bank, mashinalat,
echo        bime, karth suxt, akhbar va...
echo.
echo  Bedon-e in hesab dobare sakhte mishavad:
echo      admin / admin123
echo.
echo  MOHEM: Ghabl az edame, panjere siyah server
echo        (start-server.bat) ra BAND konid!
echo.
set /p ANS="Edame midahid? (Y = bale / N = na): "
if /i not "%ANS%"=="Y" goto :cancel

if exist "db\custom.db" del /f /q "db\custom.db"

if exist "db\custom.db" (
  echo.
  echo  [!] Database pak NASHOD.
  echo      Avval panjere siyah server ra bebandid,
  echo      bad dobare in file ra ejra konid.
  echo.
  pause
  goto :eof
)

echo.
echo  [OK] Database pak shod.
echo  Alan start-server.bat ejra mishavad —
echo  database jadid + karbar admin sakhte mishavad
echo  (bar-e avval chand daghighe tool mikesheh).
echo.
timeout /t 3 >nul
call start-server.bat
goto :eof

:cancel
echo.
echo  Cancel shod — hich chizi pak nashod.
pause
