@echo off
chcp 65001 >nul
title Ajand App - Network Setup

rem ─────────────────────────────────────────────────────────
rem  تنظیم یک‌باره شبکه برای دسترسی موبایل‌ها به سرور
rem  ۱) باز کردن پورت 3000 در فایروال ویندوز
rem  ۲) نمایش آی‌پی داخلی کامپیوتر (برای Port Forwarding مودم)
rem  این فایل فقط یک بار و با دسترسی Administrator اجرا شود.
rem ─────────────────────────────────────────────────────────

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Dar khast dastresi Administrator...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo ============================================
echo        Ajand App - Network Setup
echo ============================================
echo.

rem ─── باز کردن پورت 3000 در فایروال ویندوز ───
netsh advfirewall firewall delete rule name="Ajand App Server" >nul 2>nul
netsh advfirewall firewall add rule name="Ajand App Server" dir=in action=allow protocol=TCP localport=3000 >nul
if %errorlevel%==0 (
  echo [OK] Firewall: port 3000 baz shod.
) else (
  echo [!] Tanzim firewall anjam nashod!
)
echo.

echo IP-haye dakheli in computer — yeki az inha ra baraye
echo Port Forwarding dar modem estefade konid:
echo ------------------------------------------------------------
ipconfig | findstr /c:"IPv4"
echo ------------------------------------------------------------
echo.
echo Masalan agar IP shoma 192.168.1.50 bood, dar modem yek
echo Port Forwarding besazid:
echo.
echo    External Port : 3000
echo    Internal IP   : 192.168.1.50
echo    Internal Port : 3000
echo    Protocol      : TCP
echo.
echo Bad az in, az birone sherkat:  http://IP-Sabet:3000
echo.
echo IN PANEJERE RA BEBANDID — dastgah be hamin andaze kafist.
echo ============================================
echo.
pause
