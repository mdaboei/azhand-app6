@echo off
chcp 65001 >nul
title Ajand App Server
cd /d "%~dp0"

echo ============================================
echo            Ajand App - Server
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js nasb nist!
  echo     Lotfan ghablan Node.js LTS ra az nodejs.org nasb konid
  echo     va dobare in file ra baz konid.
  echo.
  pause
  exit /b 1
)

rem ─── اطمینان از وجود .env و کلید امنیتی ───
rem (در آپدیت: .env قدیمی سر جایش می‌ماند و عوض نمی‌شود)
if not exist ".env" (
  for /f %%a in ('powershell -NoProfile -Command "[guid]::NewGuid().ToString('N')+ [guid]::NewGuid().ToString('N')"') do set "SEC=%%a"
  > ".env" echo DATABASE_URL=file:../db/custom.db
  >> ".env" echo AUTH_SECRET=%SEC%
  echo [i] File .env sakte shod.
) else (
  findstr /b /c:"AUTH_SECRET=" ".env" >nul 2>nul
  if errorlevel 1 (
    for /f %%a in ('powershell -NoProfile -Command "[guid]::NewGuid().ToString('N')+ [guid]::NewGuid().ToString('N')"') do set "SEC=%%a"
    >> ".env" echo AUTH_SECRET=%SEC%
    echo [i] Kilid Amniati AUTH_SECRET be .env ezafe shod.
  )
)

rem ─── تشخیص آپدیت از طریق فایل VERSION ───
rem اگر شماره داخل VERSION با نسخه نصب‌شده فرق داشته باشد،
rem پکیج‌ها دوباره نصب و برنامه دوباره بیلد می‌شود (فقط یک بار).
set "NEWVER="
if exist "VERSION" for /f "usebackq delims=" %%v in ("VERSION") do set "NEWVER=%%v"

set NEEDINSTALL=0
if not exist "node_modules" set NEEDINSTALL=1
if exist "node_modules\ajand-ver" (
  set /p OLDIV=<"node_modules\ajand-ver"
) else (
  set "OLDIV="
)
if not "%NEWVER%"=="%OLDIV%" set NEEDINSTALL=1

set NEEDBUILD=0
if not exist ".next\BUILD_ID" set NEEDBUILD=1
if exist ".next\ajand-ver" (
  set /p OLDBV=<".next\ajand-ver"
) else (
  set "OLDBV="
)
if not "%NEWVER%"=="%OLDBV%" set NEEDBUILD=1

rem ─── پوشه db (نصب تازه) ───
if not exist "db" mkdir "db"

rem ─── نصب پکیج‌ها (فقط موقع نصب اول یا آپدیت) ───
if "%NEEDINSTALL%"=="1" (
  echo [1/4] Nasb paket-ha — mitune chand daghighe tool bekeshe...
  echo       (internet lazem ast)
  call npm install
  if errorlevel 1 goto :err
  if not "%NEWVER%"=="" (
    <nul set /p ="%NEWVER%" > "node_modules\ajand-ver"
  )
)

call npx prisma generate
if errorlevel 1 goto :err

rem ─── hamgamsazi schema (baraye update-ham zaroor ast — additive, bidata-loss) ───
set FRESHDB=0
if not exist "db\custom.db" set FRESHDB=1
call npx prisma db push --skip-generate
if errorlevel 1 goto :err

rem ─── backfill dastresi-haye jadid (idempotent) ───
call node prisma/backfill-panels.mjs

if "%FRESHDB%"=="1" (
  echo [2/4] Sakht database va karbaran avalie...
  call node prisma/seed.mjs
)

rem ─── بیلد برنامه (فقط موقع نصب اول یا آپدیت) ───
rem نسخه قدیمی .next نگه داشته می‌شود تا اگر بیلد شکست خورد برگردد
if "%NEEDBUILD%"=="1" (
  echo [3/4] Sakht version nahayi — mitune chand daghighe tool bekeshe...
  if exist ".next" ren ".next" ".next-old"
  call npm run build
  if errorlevel 1 goto :builderr
  if exist ".next-old" rmdir /s /q ".next-old"
  if not "%NEWVER%"=="" (
    <nul set /p ="%NEWVER%" > ".next\ajand-ver"
  )
)

echo.
echo ============================================
echo   Server roshan shod!
echo.
echo   In computer:   http://localhost:3000
echo.
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
  for /f "tokens=* delims= " %%b in ("%%a") do echo   Mobile ha:     http://%%b:3000
)
echo.
echo   IN PANEJERE RA NABANDID!
echo ============================================
echo.

:loop
call npm start
echo.
echo [!] Server khamosh shod. 5 sanie bad dobare roshan mishe...
timeout /t 5 >nul
goto :loop

:builderr
if exist ".next-old" (
  if exist ".next" rmdir /s /q ".next"
  ren ".next-old" ".next"
)
echo [!] Build shekast khod — nosxe ghabli bargardande shod.
goto :err

:err
echo.
echo [!] Yek marhale shekast khord. Internet ra check konid va dobare talash konid.
pause
