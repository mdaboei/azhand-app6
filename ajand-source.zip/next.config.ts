import type { NextConfig } from "next";

/**
 * هدرهای امنیتی سراسری:
 * - Content-Security-Policy محدود؛ بدون frame-ancestors تا پنل Preview
 *   سندباکس (که اپ را داخل iframe نشان می‌دهد) کار کند. بقیه محدودیت‌ها
 *   (script-src و ...) همان حفاظت اصلی را تامین می‌کنند.
 * - HSTS فقط روی HTTPS اثر دارد و روی شبکه داخلی HTTP نادیده گرفته می‌شود.
 * - poweredByHeader خاموش تا هدر X-Powered-By افشا نشود.
 */
const securityHeaders = [
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob:",
      "font-src 'self' data:",
      "connect-src 'self'",
      "base-uri 'self'",
      "form-action 'self'",
      "object-src 'none'",
    ].join('; '),
  },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'X-DNS-Prefetch-Control', value: 'off' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=()' },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains' },
]

const nextConfig: NextConfig = {
  // بدون standalone تا روی هر سیستم‌عاملی (ویندوز شرکت) با next start اجرا شود
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  poweredByHeader: false,
  // دامنه پیش‌نمایش سندباکس — برای لود شدن assetها در iframe پیش‌نمایش
  allowedDevOrigins: ['*.space-z.ai'],
  async headers() {
    return [
      { source: '/:path*', headers: securityHeaders },
    ]
  },
};

export default nextConfig;
